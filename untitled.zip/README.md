# PLACENZA AI: Intelligent Placement Readiness and Career Development Platform

> **Tagline:** *"Your Potential. Your Preparation. Your Placement."*  
> **Academic Scope:** Complete, secure, responsive, multi-user Java Full-Stack web application designed for strict college Capstone evaluation.

Please refer to `placenza/README.md` for complete Windows step-by-step installation instructions, MySQL setup, and execution steps.

All source files are organized cleanly in the `placenza/` directory:
- `placenza/pom.xml`: Maven configuration (Java 21, Spring Boot 3.3.4, Spring Security, Spring Data JPA, MySQL Connector/J)
- `placenza/src/main/java/com/placenza/`: All entities, repositories, services, controllers, security config, DTOs
- `placenza/src/main/resources/`: `application.properties`, `schema.sql`, `data.sql`, Thymeleaf templates, custom CSS & JS
- `placenza/src/test/java/com/placenza/`: Comprehensive test suite
- `docs/requirements-traceability.md`: Full requirements traceability matrix
