package com.placenza;

import com.placenza.dto.RegistrationDto;
import com.placenza.entity.Role;
import com.placenza.entity.User;
import com.placenza.exception.ValidationException;
import com.placenza.repository.UserRepository;
import com.placenza.service.UserService;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.test.context.TestPropertySource;
import org.springframework.transaction.annotation.Transactional;

import static org.junit.jupiter.api.Assertions.*;

@SpringBootTest
@TestPropertySource(locations = "classpath:application-test.properties")
@Transactional
class AuthServiceTest {

    @Autowired
    private UserService userService;

    @Autowired
    private UserRepository userRepository;

    @Autowired
    private PasswordEncoder passwordEncoder;

    private RegistrationDto createValidDto(String email) {
        RegistrationDto dto = new RegistrationDto();
        dto.setFullName("Archana Sudhakar");
        dto.setEmail(email);
        dto.setPassword("Secret@123!");
        dto.setConfirmPassword("Secret@123!");
        dto.setCollege("NIT Tiruchirappalli");
        dto.setDegree("B.Tech Computer Science");
        dto.setGraduationYear(2026);
        dto.setPreferredCareerRole("Java Full-Stack Developer");
        return dto;
    }

    @Test
    void testSuccessfulRegistration() {
        RegistrationDto dto = createValidDto("candidate.test@placenza.ai");
        User user = userService.register(dto);

        assertNotNull(user.getId());
        assertEquals("candidate.test@placenza.ai", user.getEmail());
        assertEquals(Role.ROLE_STUDENT, user.getRole());
        assertTrue(passwordEncoder.matches("Secret@123!", user.getPasswordHash()));
        assertNotNull(user.getProfile());
        assertEquals("NIT Tiruchirappalli", user.getProfile().getCollege());
    }

    @Test
    void testDuplicateEmailRejection() {
        RegistrationDto dto1 = createValidDto("duplicate@placenza.ai");
        userService.register(dto1);

        RegistrationDto dto2 = createValidDto("duplicate@placenza.ai");
        assertThrows(ValidationException.class, () -> userService.register(dto2));
    }

    @Test
    void testMismatchedPasswordRejection() {
        RegistrationDto dto = createValidDto("mismatch@placenza.ai");
        dto.setConfirmPassword("DifferentSecret@456!");
        assertThrows(ValidationException.class, () -> userService.register(dto));
    }
}
