package com.placenza;

import com.placenza.dto.DemoPaymentRequestDto;
import com.placenza.dto.RegistrationDto;
import com.placenza.dto.TransactionResponseDto;
import com.placenza.entity.TransactionStatus;
import com.placenza.entity.User;
import com.placenza.exception.ValidationException;
import com.placenza.service.PaymentService;
import com.placenza.service.UserService;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.TestPropertySource;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;

import static org.junit.jupiter.api.Assertions.*;

@SpringBootTest
@TestPropertySource(locations = "classpath:application-test.properties")
@Transactional
class PaymentServiceTest {

    @Autowired
    private PaymentService paymentService;

    @Autowired
    private UserService userService;

    private User createStudent(String email) {
        RegistrationDto dto = new RegistrationDto();
        dto.setFullName("Payment Tester");
        dto.setEmail(email);
        dto.setPassword("Secret@123!");
        dto.setConfirmPassword("Secret@123!");
        dto.setCollege("BITS");
        dto.setDegree("B.E.");
        dto.setGraduationYear(2026);
        dto.setPreferredCareerRole("Java Full-Stack Developer");
        return userService.register(dto);
    }

    @Test
    void testAuthoritativePricingEnforcement() {
        User user = createStudent("pay.auth@placenza.ai");

        DemoPaymentRequestDto req = new DemoPaymentRequestDto("MOCK_INTERVIEW_PRO", "Mock test session");
        TransactionResponseDto txn = paymentService.initiateDemoPurchase(user, req);

        // Price must match server catalog (499.00)
        assertEquals(new BigDecimal("499.00"), txn.getAmount());
        assertEquals("INR", txn.getCurrency());
        assertTrue(txn.isDemo(), "Transaction must be explicitly marked as DEMO");
        assertEquals(TransactionStatus.SUCCESSFUL, txn.getStatus());
        assertTrue(txn.getTransactionReference().startsWith("TXN-DEMO-"));
    }

    @Test
    void testUnknownOfferingRejection() {
        User user = createStudent("invalid.offering@placenza.ai");
        DemoPaymentRequestDto req = new DemoPaymentRequestDto("INVALID_OFFERING_KEY", "test");
        assertThrows(ValidationException.class, () -> paymentService.initiateDemoPurchase(user, req));
    }
}
