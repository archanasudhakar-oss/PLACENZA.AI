package com.placenza;

import com.placenza.dto.*;
import com.placenza.entity.*;
import com.placenza.repository.*;
import com.placenza.service.AssessmentService;
import com.placenza.service.UserService;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.TestPropertySource;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

import static org.junit.jupiter.api.Assertions.*;

@SpringBootTest
@TestPropertySource(locations = "classpath:application-test.properties")
@Transactional
class AssessmentServiceTest {

    @Autowired
    private AssessmentService assessmentService;

    @Autowired
    private UserService userService;

    @Autowired
    private CategoryRepository categoryRepository;

    @Autowired
    private QuestionRepository questionRepository;

    @Autowired
    private AssessmentRepository assessmentRepository;

    private User createStudent(String email) {
        RegistrationDto dto = new RegistrationDto();
        dto.setFullName("Candidate Exam");
        dto.setEmail(email);
        dto.setPassword("Secret@123!");
        dto.setConfirmPassword("Secret@123!");
        dto.setCollege("IIT Delhi");
        dto.setDegree("B.Tech");
        dto.setGraduationYear(2026);
        dto.setPreferredCareerRole("Java Full-Stack Developer");
        return userService.register(dto);
    }

    @Test
    void testExamPaperSecurityExcludesCorrectAnswers() {
        Category cat = categoryRepository.save(new Category("Security Test", "security-test", "desc", "bi-shield", 1));
        Question q = questionRepository.save(new Question(
                "What is JVM?", "Opt A", "Opt B", "Opt C", "Opt D",
                "A", "Explanation of JVM", cat, Difficulty.BEGINNER, 1
        ));
        Assessment exam = assessmentRepository.save(new Assessment("JVM Quiz", "desc", cat, 15, 60.0, 1));
        exam.setQuestions(List.of(q));
        assessmentRepository.save(exam);

        AssessmentDetailDto paper = assessmentService.getAssessmentForTaking(exam.getId());

        assertEquals(1, paper.getQuestions().size());
        AssessmentQuestionDto deliveredQuestion = paper.getQuestions().get(0);

        // Security check: Verify class has NO correctOption getter/field exposed to client
        assertEquals("What is JVM?", deliveredQuestion.getQuestionText());
        assertEquals("Opt A", deliveredQuestion.getOptionA());
    }

    @Test
    void testAssessmentScoringServerSide() {
        User user = createStudent("scorer@placenza.ai");

        Category cat = categoryRepository.save(new Category("Math Logic", "math-logic", "desc", "bi-calc", 1));
        Question q1 = questionRepository.save(new Question("2+2=?", "3", "4", "5", "6", "B", "2+2=4", cat, Difficulty.BEGINNER, 1));
        Question q2 = questionRepository.save(new Question("5*5=?", "20", "25", "30", "35", "B", "5*5=25", cat, Difficulty.BEGINNER, 1));

        Assessment exam = assessmentRepository.save(new Assessment("Arithmetic 101", "desc", cat, 10, 50.0, 2));
        exam.setQuestions(List.of(q1, q2));
        assessmentRepository.save(exam);

        // Candidate submits 1 correct (B) and 1 incorrect (A)
        AssessmentSubmissionDto submission = new AssessmentSubmissionDto(exam.getId(), List.of(
                new AnswerSubmissionDto(q1.getId(), "B"), // correct
                new AnswerSubmissionDto(q2.getId(), "A")  // wrong
        ));

        AssessmentResultDto result = assessmentService.submitAssessment(user, submission);

        assertEquals(2, result.getTotalQuestions());
        assertEquals(1, result.getCorrectAnswers());
        assertEquals(50.0, result.getScorePercentage());
        assertTrue(result.isPassed()); // 50% passing threshold met
        assertEquals(2, result.getAnswerReviews().size());
    }
}
