package com.placenza;

import com.placenza.dto.ReadinessScoreDto;
import com.placenza.dto.RegistrationDto;
import com.placenza.entity.*;
import com.placenza.repository.*;
import com.placenza.service.ReadinessScoreService;
import com.placenza.service.UserService;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.TestPropertySource;
import org.springframework.transaction.annotation.Transactional;

import static org.junit.jupiter.api.Assertions.*;

@SpringBootTest
@TestPropertySource(locations = "classpath:application-test.properties")
@Transactional
class ReadinessScoreServiceTest {

    @Autowired
    private ReadinessScoreService readinessScoreService;

    @Autowired
    private UserService userService;

    @Autowired
    private CategoryRepository categoryRepository;

    @Autowired
    private AssessmentRepository assessmentRepository;

    @Autowired
    private AssessmentAttemptRepository attemptRepository;

    @Test
    void testProvisionalStateForNewUser() {
        RegistrationDto dto = new RegistrationDto();
        dto.setFullName("Rohan Kumar");
        dto.setEmail("rohan.new@placenza.ai");
        dto.setPassword("Secret@123!");
        dto.setConfirmPassword("Secret@123!");
        dto.setCollege("IIT Madras");
        dto.setDegree("B.Tech CSE");
        dto.setGraduationYear(2026);
        dto.setPreferredCareerRole("Java Full-Stack Developer");

        User user = userService.register(dto);
        ReadinessScoreDto score = readinessScoreService.calculateReadiness(user.getId());

        assertTrue(score.isProvisional(), "Brand new student must have provisional readiness score");
        assertEquals("Provisional Baseline", score.getReadinessBand());
        assertNotNull(score.getProvisionalReason());
        assertTrue(score.getProvisionalReason().contains("Technical Skill Assessments"));
    }

    @Test
    void testReadinessScoreCalculationWeights() {
        RegistrationDto dto = new RegistrationDto();
        dto.setFullName("Priya Sharma");
        dto.setEmail("priya.weights@placenza.ai");
        dto.setPassword("Secret@123!");
        dto.setConfirmPassword("Secret@123!");
        dto.setCollege("BITS Pilani");
        dto.setDegree("B.E. Computer Science");
        dto.setGraduationYear(2026);
        dto.setPreferredCareerRole("Backend Software Engineer");

        User user = userService.register(dto);

        Category techCat = categoryRepository.save(new Category("Java Tech", "java-tech", "desc", "bi-cup", 1));
        Category aptCat = categoryRepository.save(new Category("Aptitude", "aptitude-test", "desc", "bi-calc", 2));

        Assessment techExam = assessmentRepository.save(new Assessment("Tech 101", "desc", techCat, 20, 60.0, 10));
        Assessment aptExam = assessmentRepository.save(new Assessment("Aptitude 101", "desc", aptCat, 20, 60.0, 10));

        // User scores 100% on Tech (40 pts) and 50% on Aptitude (10 pts)
        attemptRepository.save(new AssessmentAttempt(user, techExam, 5, 5, 100.0, true));
        attemptRepository.save(new AssessmentAttempt(user, aptExam, 4, 2, 50.0, false));

        ReadinessScoreDto score = readinessScoreService.calculateReadiness(user.getId());

        assertFalse(score.isProvisional(), "With both technical and aptitude assessments taken, score should not be provisional");
        assertEquals(40.0, score.getTechnicalComponent());
        assertEquals(10.0, score.getAptitudeComponent());
        assertTrue(score.getOverallScore() >= 50.0);
    }
}
