package com.placenza;

import com.placenza.dto.ChatResponseDto;
import com.placenza.service.ChatbotService;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class ChatbotServiceTest {

    private ChatbotService chatbotService;

    @BeforeEach
    void setUp() {
        chatbotService = new ChatbotService();
    }

    @Test
    void testChatbotMatchesJavaKeywords() {
        ChatResponseDto res = chatbotService.processMessage("Tell me about Java garbage collection and strings");
        assertNotNull(res);
        assertEquals("Java Fundamentals", res.getTopic());
        assertTrue(res.getReply().contains("JVM"));
        assertFalse(res.getSuggestions().isEmpty());
    }

    @Test
    void testChatbotMatchesOOPKeywords() {
        ChatResponseDto res = chatbotService.processMessage("What is polymorphism and inheritance in OOP?");
        assertNotNull(res);
        assertEquals("Object-Oriented Programming", res.getTopic());
        assertTrue(res.getReply().contains("Encapsulation"));
    }

    @Test
    void testChatbotMatchesReadinessScoreKeywords() {
        ChatResponseDto res = chatbotService.processMessage("How is my readiness score calculated?");
        assertNotNull(res);
        assertEquals("Placement Readiness Score", res.getTopic());
        assertTrue(res.getReply().contains("40%"));
    }

    @Test
    void testChatbotFallbackForUnrecognizedQueries() {
        ChatResponseDto res = chatbotService.processMessage("What is the weather in Antarctica today?");
        assertNotNull(res);
        assertEquals("Fallback Assistance", res.getTopic());
        assertTrue(res.getReply().contains("I don't have a specific rule-based article"));
        assertFalse(res.getSuggestions().isEmpty());
    }
}
