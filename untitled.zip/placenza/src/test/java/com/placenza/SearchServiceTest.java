package com.placenza;

import com.placenza.dto.SearchResultDto;
import com.placenza.entity.Category;
import com.placenza.repository.CategoryRepository;
import com.placenza.service.SearchService;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.TestPropertySource;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

import static org.junit.jupiter.api.Assertions.*;

@SpringBootTest
@TestPropertySource(locations = "classpath:application-test.properties")
@Transactional
class SearchServiceTest {

    @Autowired
    private SearchService searchService;

    @Autowired
    private CategoryRepository categoryRepository;

    @Test
    void testKeywordSearchMatchesCategory() {
        categoryRepository.save(new Category("Distributed Systems", "distributed-systems", "Microservices, consensus algorithms and Raft.", "bi-server", 99));

        List<SearchResultDto> results = searchService.executeSearch("Microservices", "CATEGORY", null);
        assertFalse(results.isEmpty());
        assertTrue(results.stream().anyMatch(r -> r.getTitle().equals("Distributed Systems")));
    }

    @Test
    void testBlankKeywordReturnsEmpty() {
        List<SearchResultDto> results = searchService.executeSearch("   ", null, null);
        assertTrue(results.isEmpty());
    }
}
