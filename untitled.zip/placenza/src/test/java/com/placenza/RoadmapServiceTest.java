package com.placenza;

import com.placenza.dto.RegistrationDto;
import com.placenza.dto.RoadmapTaskDto;
import com.placenza.entity.*;
import com.placenza.exception.UnauthorizedAccessException;
import com.placenza.repository.RoadmapTaskRepository;
import com.placenza.service.RoadmapService;
import com.placenza.service.UserService;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.TestPropertySource;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

import static org.junit.jupiter.api.Assertions.*;

@SpringBootTest
@TestPropertySource(locations = "classpath:application-test.properties")
@Transactional
class RoadmapServiceTest {

    @Autowired
    private RoadmapService roadmapService;

    @Autowired
    private UserService userService;

    @Autowired
    private RoadmapTaskRepository taskRepository;

    private User createStudent(String email) {
        RegistrationDto dto = new RegistrationDto();
        dto.setFullName("Student " + email);
        dto.setEmail(email);
        dto.setPassword("Secret@123!");
        dto.setConfirmPassword("Secret@123!");
        dto.setCollege("IIT Bombay");
        dto.setDegree("B.Tech");
        dto.setGraduationYear(2026);
        dto.setPreferredCareerRole("Java Full-Stack Developer");
        return userService.register(dto);
    }

    @Test
    void testRoadmapGenerationAndTaskRetrieval() {
        User user = createStudent("roadmap.test@placenza.ai");
        List<RoadmapTaskDto> tasks = roadmapService.getTasksForUser(user.getId());

        assertFalse(tasks.isEmpty(), "Roadmap should have tasks populated upon registration");
        assertTrue(tasks.size() >= 5);
    }

    @Test
    void testToggleTaskCompletion() {
        User user = createStudent("toggle.test@placenza.ai");
        List<RoadmapTaskDto> tasks = roadmapService.getTasksForUser(user.getId());
        Long firstTaskId = tasks.get(0).getId();

        RoadmapTask toggled = roadmapService.toggleTaskCompletion(firstTaskId, user.getId());
        assertEquals(TaskStatus.COMPLETED, toggled.getStatus());
        assertNotNull(toggled.getCompletedAt());

        // Toggle again to pending
        RoadmapTask toggledBack = roadmapService.toggleTaskCompletion(firstTaskId, user.getId());
        assertEquals(TaskStatus.PENDING, toggledBack.getStatus());
    }

    @Test
    void testOwnershipSecurityEnforcementOnRoadmapTasks() {
        User alice = createStudent("alice@placenza.ai");
        User bob = createStudent("bob@placenza.ai");

        List<RoadmapTaskDto> aliceTasks = roadmapService.getTasksForUser(alice.getId());
        Long aliceTaskId = aliceTasks.get(0).getId();

        // Bob attempts to modify Alice's task -> MUST throw UnauthorizedAccessException
        assertThrows(UnauthorizedAccessException.class, () ->
                roadmapService.toggleTaskCompletion(aliceTaskId, bob.getId())
        );
    }
}
