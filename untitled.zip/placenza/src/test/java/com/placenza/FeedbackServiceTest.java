package com.placenza;

import com.placenza.dto.FeedbackDto;
import com.placenza.dto.RegistrationDto;
import com.placenza.entity.Feedback;
import com.placenza.entity.User;
import com.placenza.exception.ValidationException;
import com.placenza.service.FeedbackService;
import com.placenza.service.UserService;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.TestPropertySource;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

import static org.junit.jupiter.api.Assertions.*;

@SpringBootTest
@TestPropertySource(locations = "classpath:application-test.properties")
@Transactional
class FeedbackServiceTest {

    @Autowired
    private FeedbackService feedbackService;

    @Autowired
    private UserService userService;

    private User createStudent(String email) {
        RegistrationDto dto = new RegistrationDto();
        dto.setFullName("Feedback Tester");
        dto.setEmail(email);
        dto.setPassword("Secret@123!");
        dto.setConfirmPassword("Secret@123!");
        dto.setCollege("IIT Roorkee");
        dto.setDegree("B.Tech");
        dto.setGraduationYear(2026);
        dto.setPreferredCareerRole("Java Full-Stack Developer");
        return userService.register(dto);
    }

    @Test
    void testValidFeedbackPersistence() {
        User user = createStudent("feedback.user@placenza.ai");
        FeedbackDto dto = new FeedbackDto(5, "Skill Assessments", "The Java assessments were extremely thorough and helpful!");

        Feedback saved = feedbackService.submitUserFeedback(user, dto);
        assertNotNull(saved.getId());
        assertEquals(5, saved.getRating());
        assertEquals(user.getId(), saved.getUser().getId());

        List<Feedback> userHistory = feedbackService.getUserFeedbacks(user.getId());
        assertEquals(1, userHistory.size());
    }

    @Test
    void testInvalidRatingBoundaryRejection() {
        User user = createStudent("invalid.rating@placenza.ai");

        FeedbackDto overRating = new FeedbackDto(6, "Assessments", "Great platform!");
        assertThrows(ValidationException.class, () -> feedbackService.submitUserFeedback(user, overRating));

        FeedbackDto underRating = new FeedbackDto(0, "Assessments", "Needs work.");
        assertThrows(ValidationException.class, () -> feedbackService.submitUserFeedback(user, underRating));
    }
}
