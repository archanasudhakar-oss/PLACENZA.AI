-- ==========================================================
-- PLACENZA AI - IDEMPOTENT SEED DATA
-- Pre-populates 12 required categories, assessments, and questions
-- ==========================================================

-- Insert 12 Standard Categories
INSERT INTO categories (id, name, slug, description, icon, display_order)
VALUES
(1, 'Java Programming', 'java-programming', 'Core Java, OOPs, Collections, Concurrency, JVM internals, Streams API, and Exception Handling.', 'bi-cup-hot', 1),
(2, 'Python Programming', 'python-programming', 'Python syntax, data structures, generators, decorators, OOP, and built-in modules.', 'bi-code-slash', 2),
(3, 'SQL', 'sql', 'Structured Query Language, complex joins, subqueries, indexing, window functions, and DDL/DML.', 'bi-database', 3),
(4, 'DBMS', 'dbms', 'Database Management Systems, ACID properties, normalization, indexing, transactions, and ER diagrams.', 'bi-hdd-network', 4),
(5, 'Data Structures and Algorithms', 'dsa', 'Arrays, Linked Lists, Stacks, Queues, Trees, Graphs, Sorting, Dynamic Programming, and Big-O analysis.', 'bi-diagram-3', 5),
(6, 'Computer Networks', 'computer-networks', 'OSI model, TCP/IP, DNS, HTTP/HTTPS, routing protocols, subnetting, sockets, and network security.', 'bi-globe', 6),
(7, 'Operating Systems', 'operating-systems', 'Process management, threads, CPU scheduling, deadlocks, virtual memory, paging, and system calls.', 'bi-cpu', 7),
(8, 'Aptitude', 'aptitude', 'Quantitative aptitude, logical reasoning, data interpretation, permutations, and time-and-work problems.', 'bi-calculator', 8),
(9, 'Communication Skills', 'communication-skills', 'Verbal ability, reading comprehension, professional email etiquette, and presentation skills.', 'bi-chat-dots', 9),
(10, 'HR Interviews', 'hr-interviews', 'Behavioral interview questions, STAR methodology, situational judgment, cultural fit, and negotiation.', 'bi-people', 10),
(11, 'Technical Interviews', 'technical-interviews', 'System design basics, architectural tradeoffs, coding problem walk-throughs, and debugging.', 'bi-terminal', 11),
(12, 'Resume Preparation', 'resume-preparation', 'Action-oriented bullet points, ATS optimization, project impact framing, and tech stack clarity.', 'bi-file-earmark-person', 12)
ON DUPLICATE KEY UPDATE name=VALUES(name), description=VALUES(description), icon=VALUES(icon);

-- Insert Core Skills
INSERT INTO skills (id, name, category_id, description, level_weight) VALUES
(1, 'Java Core & OOP', 1, 'Understanding of inheritance, polymorphism, encapsulation, and abstraction in Java.', 1.0),
(2, 'Java Collections & Streams', 1, 'Mastery of List, Set, Map, Collections utility, Stream operations and lambdas.', 1.0),
(3, 'SQL Joins & Grouping', 3, 'Inner, outer, left, right joins, aggregate functions and HAVING clauses.', 1.0),
(4, 'Database Normalization', 4, '1NF, 2NF, 3NF, BCNF, functional dependencies, and anomaly prevention.', 1.0),
(5, 'Arrays & Hashing', 5, 'Two pointers, sliding window, prefix sums, and hash map lookups.', 1.0),
(6, 'Trees & Graphs', 5, 'Binary search trees, traversals (BFS/DFS), Dijkstra, and topological sort.', 1.0),
(7, 'Process & Concurrency', 7, 'Multithreading, race conditions, semaphores, mutexes, and deadlocks.', 1.0),
(8, 'TCP/IP & Web Protocols', 6, 'Handshakes, status codes, REST architecture, and TLS encryption.', 1.0),
(9, 'Quantitative Reasoning', 8, 'Percentages, profit-loss, ratios, work-rate, and time-speed-distance.', 1.0),
(10, 'STAR Behavioral Framework', 10, 'Situation, Task, Action, Result structured responses.', 1.0)
ON DUPLICATE KEY UPDATE name=VALUES(name);

-- Insert Standard Assessments
INSERT INTO assessments (id, title, description, category_id, duration_minutes, passing_score, total_marks) VALUES
(1, 'Java Foundations & OOP Readiness', 'Comprehensive assessment covering Java language fundamentals, object-oriented principles, memory management, and Collections.', 1, 20, 60.0, 5),
(2, 'SQL & Relational DBMS Mastery', 'Assessment on queries, join logic, ACID transactions, normalization, and indexing strategies.', 3, 20, 60.0, 5),
(3, 'DSA: Problem Solving & Algorithms', 'Algorithmic efficiency, Big-O complexities, data structure selections, and graph traversals.', 5, 25, 60.0, 5),
(4, 'Quantitative & Logical Aptitude Test', 'Essential aptitude test covering numerical reasoning, time and work, and analytical deductions.', 8, 20, 60.0, 5)
ON DUPLICATE KEY UPDATE title=VALUES(title);

-- Insert MCQs for Assessment 1: Java (id: 1..5)
INSERT INTO questions (id, question_text, option_a, option_b, option_c, option_d, correct_option, explanation, category_id, difficulty, marks) VALUES
(1, 'Which of the following is true regarding String immutability in Java?', 'Strings can be modified in-place using the append() method', 'Every modification creates a new String object in memory or the String pool', 'Strings are mutable if defined with the final keyword', 'Strings share the same heap memory as char primitives without allocation', 'B', 'Strings in Java are immutable; any operation that modifies a String results in a new String object being created in memory.', 1, 'BEGINNER', 1),
(2, 'What is the default initial capacity and load factor of a standard Java HashMap?', '16 and 0.75', '32 and 0.50', '10 and 0.80', '64 and 1.0', 'A', 'Java HashMap has a default initial capacity of 16 and a default load factor of 0.75.', 1, 'INTERMEDIATE', 1),
(3, 'Which OOP principle is primarily demonstrated by method overloading in Java?', 'Runtime Polymorphism', 'Compile-time Polymorphism', 'Encapsulation', 'Multiple Inheritance', 'B', 'Method overloading (same method name, different parameter signatures) is resolved at compile time, demonstrating compile-time (static) polymorphism.', 1, 'BEGINNER', 1),
(4, 'What is the key difference between fail-fast and fail-safe iterators in Java Collections?', 'Fail-fast throws ConcurrentModificationException if modified during iteration', 'Fail-safe operates directly on the original collection and locks threads', 'Fail-fast is only available in Vector and Hashtable', 'Fail-safe iterators never allow read operations', 'A', 'Fail-fast iterators (like ArrayList Iterator) throw ConcurrentModificationException immediately if structural modification occurs during iteration. Fail-safe iterators (e.g., CopyOnWriteArrayList) operate on a clone.', 1, 'ADVANCED', 1),
(5, 'What happens if an exception is thrown inside a try block, but both catch and finally blocks contain return statements?', 'The return value in the catch block is returned and finally is ignored', 'The return value in the finally block overrides all previous returns', 'A compile-time error occurs due to unreachable code', 'The thread terminates abruptly with an unhandled exception', 'B', 'In Java, a return statement in the finally block will always execute and override any return statement or rethrown exception from try or catch blocks.', 1, 'INTERMEDIATE', 1)
ON DUPLICATE KEY UPDATE question_text=VALUES(question_text);

-- Insert MCQs for Assessment 2: SQL & DBMS (id: 6..10)
INSERT INTO questions (id, question_text, option_a, option_b, option_c, option_d, correct_option, explanation, category_id, difficulty, marks) VALUES
(6, 'Which normal form eliminates partial functional dependencies on candidate keys?', 'First Normal Form (1NF)', 'Second Normal Form (2NF)', 'Third Normal Form (3NF)', 'Boyce-Codd Normal Form (BCNF)', 'B', '2NF requires the relation to be in 1NF and ensures that no non-prime attribute is functionally dependent on any proper subset of any candidate key (eliminates partial dependency).', 4, 'INTERMEDIATE', 1),
(7, 'What is the outcome of a LEFT OUTER JOIN between Table A and Table B?', 'Only rows that have matching values in both tables', 'All rows from Table A, and matched rows from Table B (NULL for non-matching B rows)', 'All rows from Table B, and matched rows from Table A', 'Only rows that do not have matching values in either table', 'B', 'LEFT JOIN returns all rows from the left table (A), along with matched rows from the right table (B). If there is no match, NULL values appear for columns of Table B.', 3, 'BEGINNER', 1),
(8, 'In relational database indexing, why are B+ Trees favored over Binary Search Trees?', 'B+ Trees have fewer disk I/O operations due to high fanout and store data records only in leaf nodes', 'B+ Trees require zero memory for interior pointers', 'Binary Search Trees are not balanced', 'B+ Trees do not support range scans', 'A', 'B+ Trees have a high branching factor (fanout), keeping the tree shallow and reducing costly disk I/O. All data pointers are stored in contiguous, linked leaf nodes for efficient range scans.', 4, 'ADVANCED', 1),
(9, 'What is the purpose of the HAVING clause in SQL?', 'To filter individual rows before grouping occurs', 'To filter grouped rows resulting from a GROUP BY clause', 'To define foreign key constraints on runtime tables', 'To sort the result set in ascending order', 'B', 'The HAVING clause was added to SQL because the WHERE keyword cannot be used with aggregate functions. HAVING filters results after GROUP BY aggregation.', 3, 'BEGINNER', 1),
(10, 'Which ACID property guarantees that all database updates in a transaction are permanently saved even during power failure?', 'Atomicity', 'Consistency', 'Isolation', 'Durability', 'D', 'Durability ensures that once a transaction has been committed, it will remain committed even in the event of a system crash, power outage, or crash recovery.', 4, 'BEGINNER', 1)
ON DUPLICATE KEY UPDATE question_text=VALUES(question_text);

-- Insert MCQs for Assessment 3: DSA (id: 11..15)
INSERT INTO questions (id, question_text, option_a, option_b, option_c, option_d, correct_option, explanation, category_id, difficulty, marks) VALUES
(11, 'What is the worst-case time complexity of standard QuickSort when an unfortunate pivot is chosen consistently?', 'O(N log N)', 'O(N)', 'O(N^2)', 'O(log N)', 'C', 'When the chosen pivot is consistently the smallest or largest element (such as already sorted array with first element as pivot), QuickSort degrades to O(N^2).', 5, 'BEGINNER', 1),
(12, 'Which data structure is most appropriate for implementing Breadth-First Search (BFS) on a graph?', 'Stack', 'Queue', 'Priority Queue', 'Disjoint Set', 'B', 'BFS explores neighbors level-by-level using a First-In-First-Out (FIFO) Queue.', 5, 'BEGINNER', 1),
(13, 'What is the maximum number of nodes in a binary tree of height H (where root height is 1)?', '2^H - 1', '2^(H-1)', '2*H', 'H^2', 'A', 'A binary tree of height H has at most 1 + 2 + 4 + ... + 2^(H-1) = 2^H - 1 nodes.', 5, 'INTERMEDIATE', 1),
(14, 'Which algorithm finds the shortest path between all pairs of vertices in a weighted graph with possible negative edges (no negative cycles)?', 'Dijkstra Algorithm', 'Floyd-Warshall Algorithm', 'Prim Algorithm', 'Kruskal Algorithm', 'B', 'Floyd-Warshall is a dynamic programming algorithm that solves the all-pairs shortest path problem in O(V^3) time and handles negative weight edges.', 5, 'ADVANCED', 1),
(15, 'What is the space complexity of an in-place merge sort variation compared to standard array merge sort?', 'Standard uses O(N) auxiliary space; in-place achieves O(1) auxiliary space with increased time overhead', 'Standard uses O(1) space and in-place uses O(N) space', 'Both strictly require O(N^2) space', 'Both require zero stack space', 'A', 'Standard merge sort allocates an auxiliary array of size O(N). In-place variations achieve O(1) extra space at the cost of higher constant factor time or complex pointer shifting.', 5, 'ADVANCED', 1)
ON DUPLICATE KEY UPDATE question_text=VALUES(question_text);

-- Map Questions to Assessments
INSERT INTO assessment_questions (assessment_id, question_id) VALUES
(1, 1), (1, 2), (1, 3), (1, 4), (1, 5),
(2, 6), (2, 7), (2, 8), (2, 9), (2, 10),
(3, 11), (3, 12), (3, 13), (3, 14), (3, 15)
ON DUPLICATE KEY UPDATE assessment_id=VALUES(assessment_id);

-- Insert Comprehensive Interview Questions
INSERT INTO interview_questions (id, question_text, reference_answer, explanation, category_id, difficulty) VALUES
(1, 'How does the Garbage Collector work in Java, and what are Generational Hypotheses?', 
 'Java Garbage Collection uses Generational Heap management divided into Young Generation (Eden, S0, S1), Old (Tenured) Generation, and Metaspace. Most objects die young (weak generational hypothesis), so Minor GC collects Eden rapidly. Objects surviving multiple GC cycles are promoted to Tenured generation where Major/Full GC runs.',
 'Discuss JVM flags like -Xms, -Xmx, G1GC, and ZGC features when asked in senior interviews.', 1, 'INTERMEDIATE'),

(2, 'Explain the difference between HashMap, ConcurrentHashMap, and SynchronizedMap.',
 'HashMap is non-thread-safe. Collections.synchronizedMap wraps HashMap with a single mutex lock on the entire map, creating a bottleneck. ConcurrentHashMap uses bucket-level locking (CAS operations and synchronized nodes per bin) allowing multiple threads to read and write concurrently without locking the whole map.',
 'Emphasize that ConcurrentHashMap does not allow null keys or values, unlike HashMap.', 1, 'ADVANCED'),

(3, 'What are Database Indexes, and how do they impact INSERT/UPDATE performance?',
 'An index is an auxiliary data structure (typically a B+ Tree) that enables rapid retrieval of rows without scanning every block. While SELECT queries with indexed WHERE clauses speed up exponentially, INSERT and UPDATE queries incur extra overhead because the B+ Tree must be rebalanced, node-split, and rewritten.',
 'Always mention covering indexes, cardinality, and avoiding over-indexing write-heavy tables.', 3, 'INTERMEDIATE'),

(4, 'Explain Deadlock in Operating Systems and the four Coffman conditions.',
 'A deadlock occurs when a set of concurrent processes are permanently blocked because each holds a resource and waits for another resource held by another process. The 4 Coffman conditions are: Mutual Exclusion, Hold and Wait, No Preemption, and Circular Wait. Breaking any one condition prevents deadlocks.',
 'Be prepared to explain the Banker''s algorithm for deadlock avoidance.', 7, 'INTERMEDIATE'),

(5, 'How does DNS Resolution work when a user types a URL into a web browser?',
 '1. Browser checks local cache; 2. OS resolver checks hosts file and DNS client cache; 3. Query is sent to the Recursive DNS Resolver (ISP/8.8.8.8); 4. Recursive resolver queries Root Name Server (. ); 5. Root directs to TLD Server (.com); 6. TLD directs to Authoritative Name Server; 7. Authoritative server returns the A/AAAA IP record.',
 'Highlight TCP/UDP port 53 and TTL (Time-To-Live) caching mechanisms.', 6, 'BEGINNER'),

(6, 'Tell me about a challenging technical project and how you resolved an unexpected blocker (STAR method).',
 'Situation: In our final-year project, our database queries lagged to 4 seconds during load tests. Task: I was responsible for optimizing the backend API response to under 300ms. Action: Profiled slow queries using EXPLAIN ANALYZE, added composite indexes on foreign keys, and introduced Redis caching for hot user session data. Result: P99 latency dropped to 180ms, handling 1,500 simultaneous requests reliably.',
 'Use concise numbers, clear personal contributions (I, not we), and a measurable outcome.', 10, 'BEGINNER')
ON DUPLICATE KEY UPDATE question_text=VALUES(question_text);
