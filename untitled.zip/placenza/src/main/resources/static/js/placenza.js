/**
 * PLACENZA AI — VANILLA JAVASCRIPT CONTROLLER
 * Complies with strict constraint: vanilla JS, no prohibited frameworks.
 */

document.addEventListener('DOMContentLoaded', function () {
    initChatbot();
    initAssessmentTimer();
    initAnswerToggles();
    initToastAutoDismiss();
});

/* ==========================================================
   1. CHATBOT INTERFACE (Vanilla JS + REST Endpoint)
   ========================================================== */
function initChatbot() {
    const chatInput = document.getElementById('chatInput');
    const sendBtn = document.getElementById('chatSendBtn');
    const chatMessages = document.getElementById('chatMessages');
    const clearBtn = document.getElementById('chatClearBtn');

    if (!chatInput || !sendBtn || !chatMessages) return;

    function appendMessage(sender, text, topic) {
        const bubble = document.createElement('div');
        bubble.className = sender === 'user' ? 'chat-bubble-user' : 'chat-bubble-bot';
        
        let contentHtml = '';
        if (topic && sender === 'bot') {
            contentHtml += `<div class="badge bg-dark border border-secondary mb-1 text-cyan" style="font-size:0.75rem;">${escapeHtml(topic)}</div><br>`;
        }
        contentHtml += escapeHtml(text).replace(/\n/g, '<br>');
        
        bubble.innerHTML = contentHtml;
        chatMessages.appendChild(bubble);
        chatMessages.scrollTop = chatMessages.scrollHeight;
    }

    async function sendMessage(text) {
        const query = text || chatInput.value.trim();
        if (!query) return;

        appendMessage('user', query);
        if (!text) chatInput.value = '';

        // Add loading indicator
        const loadingIndicator = document.createElement('div');
        loadingIndicator.className = 'chat-bubble-bot text-secondary';
        loadingIndicator.id = 'chatLoadingIndicator';
        loadingIndicator.innerHTML = '<span class="spinner-border spinner-border-sm text-violet me-2"></span>Placenza Assistant is thinking...';
        chatMessages.appendChild(loadingIndicator);
        chatMessages.scrollTop = chatMessages.scrollHeight;

        try {
            const csrfToken = document.querySelector('meta[name="_csrf"]')?.getAttribute('content');
            const csrfHeader = document.querySelector('meta[name="_csrf_header"]')?.getAttribute('content');

            const headers = { 'Content-Type': 'application/json' };
            if (csrfToken && csrfHeader) {
                headers[csrfHeader] = csrfToken;
            }

            const res = await fetch('/api/chat', {
                method: 'POST',
                headers: headers,
                body: JSON.stringify({ message: query })
            });

            const indicator = document.getElementById('chatLoadingIndicator');
            if (indicator) indicator.remove();

            if (res.ok) {
                const data = await res.json();
                appendMessage('bot', data.reply, data.topic);

                // Render dynamic suggestions if provided
                if (data.suggestions && data.suggestions.length > 0) {
                    renderSuggestions(data.suggestions);
                }
            } else {
                appendMessage('bot', 'Sorry, I encountered an issue processing your question. Please try again.');
            }
        } catch (e) {
            const indicator = document.getElementById('chatLoadingIndicator');
            if (indicator) indicator.remove();
            appendMessage('bot', 'Connection error. Please ensure the server is running.');
        }
    }

    function renderSuggestions(suggestions) {
        const container = document.getElementById('chatSuggestionsContainer');
        if (!container) return;
        container.innerHTML = '';
        suggestions.forEach(s => {
            const btn = document.createElement('button');
            btn.className = 'btn btn-sm btn-placenza-outline me-2 mb-2';
            btn.textContent = s;
            btn.type = 'button';
            btn.onclick = () => sendMessage(s);
            container.appendChild(btn);
        });
    }

    sendBtn.addEventListener('click', () => sendMessage());
    chatInput.addEventListener('keydown', (e) => {
        if (e.key === 'Enter') {
            e.preventDefault();
            sendMessage();
        }
    });

    if (clearBtn) {
        clearBtn.addEventListener('click', async () => {
            const csrfToken = document.querySelector('meta[name="_csrf"]')?.getAttribute('content');
            const csrfHeader = document.querySelector('meta[name="_csrf_header"]')?.getAttribute('content');
            const headers = {};
            if (csrfToken && csrfHeader) headers[csrfHeader] = csrfToken;

            await fetch('/api/chat/clear', { method: 'POST', headers: headers });
            chatMessages.innerHTML = '<div class="chat-bubble-bot">Conversation cleared. What would you like to prepare for today?</div>';
        });
    }

    // Bind initial suggestion chips
    document.querySelectorAll('.suggestion-chip').forEach(chip => {
        chip.addEventListener('click', () => {
            sendMessage(chip.textContent.trim());
        });
    });
}

/* ==========================================================
   2. ASSESSMENT COUNTDOWN TIMER
   ========================================================== */
function initAssessmentTimer() {
    const timerElem = document.getElementById('assessmentCountdown');
    const examForm = document.getElementById('assessmentExamForm');
    if (!timerElem || !examForm) return;

    let durationMinutes = parseInt(timerElem.getAttribute('data-duration') || '20', 10);
    let totalSeconds = durationMinutes * 60;

    const interval = setInterval(() => {
        if (totalSeconds <= 0) {
            clearInterval(interval);
            timerElem.textContent = "00:00 - Time's Up!";
            alert("Time limit reached! Your assessment will now be submitted automatically.");
            examForm.submit();
            return;
        }

        totalSeconds--;
        const mins = Math.floor(totalSeconds / 60);
        const secs = totalSeconds % 60;
        timerElem.textContent = `${mins.toString().padStart(2, '0')}:${secs.toString().padStart(2, '0')}`;

        if (totalSeconds < 120) {
            timerElem.classList.add('text-danger');
        }
    }, 1000);
}

/* ==========================================================
   3. INTERVIEW ANSWER REVEAL TOGGLES
   ========================================================== */
function initAnswerToggles() {
    document.querySelectorAll('.btn-reveal-answer').forEach(btn => {
        btn.addEventListener('click', function () {
            const targetId = this.getAttribute('data-target');
            const targetElem = document.getElementById(targetId);
            if (!targetElem) return;

            if (targetElem.classList.contains('d-none')) {
                targetElem.classList.remove('d-none');
                this.innerHTML = '<i class="bi bi-eye-slash me-1"></i> Hide Reference Answer';
            } else {
                targetElem.classList.add('d-none');
                this.innerHTML = '<i class="bi bi-eye me-1"></i> Reveal Reference Answer';
            }
        });
    });
}

/* ==========================================================
   4. TOAST AUTO-DISMISS
   ========================================================== */
function initToastAutoDismiss() {
    const alerts = document.querySelectorAll('.alert-dismissible');
    alerts.forEach(alert => {
        setTimeout(() => {
            const bsAlert = bootstrap.Alert.getOrCreateInstance(alert);
            if (bsAlert) bsAlert.close();
        }, 6000);
    });
}

function escapeHtml(text) {
    if (!text) return '';
    const map = {
        '&': '&amp;',
        '<': '&lt;',
        '>': '&gt;',
        '"': '&quot;',
        "'": '&#039;'
    };
    return text.replace(/[&<>"']/g, function(m) { return map[m]; });
}
