package com.placenza.entity;

public enum Priority {
    LOW,
    MEDIUM,
    HIGH,
    URGENT
}
