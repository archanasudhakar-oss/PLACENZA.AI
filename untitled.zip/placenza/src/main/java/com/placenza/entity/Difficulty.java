package com.placenza.entity;

public enum Difficulty {
    BEGINNER,
    INTERMEDIATE,
    ADVANCED
}
