package com.placenza.entity;

import jakarta.persistence.*;
import jakarta.validation.constraints.NotBlank;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

@Entity
@Table(name = "roadmaps")
public class Roadmap {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @OneToOne(fetch = FetchType.LAZY, optional = false)
    @JoinColumn(name = "user_id", nullable = false, unique = true)
    private User user;

    @NotBlank
    @Column(name = "target_role", length = 120, nullable = false)
    private String targetRole;

    @Column(name = "overall_progress")
    private Double overallProgress = 0.0;

    @Column(name = "created_at", updatable = false)
    private LocalDateTime createdAt = LocalDateTime.now();

    @Column(name = "updated_at")
    private LocalDateTime updatedAt = LocalDateTime.now();

    @OneToMany(mappedBy = "roadmap", cascade = CascadeType.ALL, orphanRemoval = true)
    @OrderBy("sortOrder ASC, id ASC")
    private List<RoadmapTask> tasks = new ArrayList<>();

    public Roadmap() {}

    public Roadmap(User user, String targetRole) {
        this.user = user;
        this.targetRole = targetRole;
        this.overallProgress = 0.0;
        this.createdAt = LocalDateTime.now();
        this.updatedAt = LocalDateTime.now();
    }

    public void recalculateProgress() {
        if (tasks == null || tasks.isEmpty()) {
            this.overallProgress = 0.0;
            return;
        }
        long completed = tasks.stream().filter(t -> t.getStatus() == TaskStatus.COMPLETED).count();
        this.overallProgress = Math.round(((double) completed / tasks.size()) * 100.0 * 10.0) / 10.0;
        this.updatedAt = LocalDateTime.now();
    }

    // Getters and Setters
    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }

    public User getUser() { return user; }
    public void setUser(User user) { this.user = user; }

    public String getTargetRole() { return targetRole; }
    public void setTargetRole(String targetRole) { this.targetRole = targetRole; }

    public Double getOverallProgress() { return overallProgress != null ? overallProgress : 0.0; }
    public void setOverallProgress(Double overallProgress) { this.overallProgress = overallProgress; }

    public LocalDateTime getCreatedAt() { return createdAt; }
    public void setCreatedAt(LocalDateTime createdAt) { this.createdAt = createdAt; }

    public LocalDateTime getUpdatedAt() { return updatedAt; }
    public void setUpdatedAt(LocalDateTime updatedAt) { this.updatedAt = updatedAt; }

    public List<RoadmapTask> getTasks() { return tasks; }
    public void setTasks(List<RoadmapTask> tasks) { this.tasks = tasks; }
}
