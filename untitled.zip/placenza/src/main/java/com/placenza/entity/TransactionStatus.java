package com.placenza.entity;

public enum TransactionStatus {
    INITIATED,
    PENDING,
    SUCCESSFUL,
    FAILED,
    CANCELLED
}
