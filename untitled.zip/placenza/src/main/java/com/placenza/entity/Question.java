package com.placenza.entity;

import jakarta.persistence.*;
import jakarta.validation.constraints.NotBlank;

@Entity
@Table(name = "questions")
public class Question {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @NotBlank(message = "Question text is required")
    @Column(name = "question_text", columnDefinition = "TEXT", nullable = false)
    private String questionText;

    @NotBlank
    @Column(name = "option_a", length = 500, nullable = false)
    private String optionA;

    @NotBlank
    @Column(name = "option_b", length = 500, nullable = false)
    private String optionB;

    @NotBlank
    @Column(name = "option_c", length = 500, nullable = false)
    private String optionC;

    @NotBlank
    @Column(name = "option_d", length = 500, nullable = false)
    private String optionD;

    @NotBlank
    @Column(name = "correct_option", length = 5, nullable = false)
    private String correctOption; // Stored securely on server only

    @Column(columnDefinition = "TEXT")
    private String explanation;

    @ManyToOne(fetch = FetchType.LAZY, optional = false)
    @JoinColumn(name = "category_id", nullable = false)
    private Category category;

    @Enumerated(EnumType.STRING)
    @Column(nullable = false, length = 30)
    private Difficulty difficulty = Difficulty.INTERMEDIATE;

    @Column(name = "marks")
    private Integer marks = 1;

    public Question() {}

    public Question(String questionText, String optionA, String optionB, String optionC, String optionD,
                    String correctOption, String explanation, Category category, Difficulty difficulty, Integer marks) {
        this.questionText = questionText;
        this.optionA = optionA;
        this.optionB = optionB;
        this.optionC = optionC;
        this.optionD = optionD;
        this.correctOption = correctOption;
        this.explanation = explanation;
        this.category = category;
        this.difficulty = difficulty != null ? difficulty : Difficulty.INTERMEDIATE;
        this.marks = marks != null ? marks : 1;
    }

    // Getters and Setters
    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }

    public String getQuestionText() { return questionText; }
    public void setQuestionText(String questionText) { this.questionText = questionText; }

    public String getOptionA() { return optionA; }
    public void setOptionA(String optionA) { this.optionA = optionA; }

    public String getOptionB() { return optionB; }
    public void setOptionB(String optionB) { this.optionB = optionB; }

    public String getOptionC() { return optionC; }
    public void setOptionC(String optionC) { this.optionC = optionC; }

    public String getOptionD() { return optionD; }
    public void setOptionD(String optionD) { this.optionD = optionD; }

    public String getCorrectOption() { return correctOption; }
    public void setCorrectOption(String correctOption) { this.correctOption = correctOption; }

    public String getExplanation() { return explanation; }
    public void setExplanation(String explanation) { this.explanation = explanation; }

    public Category getCategory() { return category; }
    public void setCategory(Category category) { this.category = category; }

    public Difficulty getDifficulty() { return difficulty; }
    public void setDifficulty(Difficulty difficulty) { this.difficulty = difficulty; }

    public Integer getMarks() { return marks; }
    public void setMarks(Integer marks) { this.marks = marks; }
}
