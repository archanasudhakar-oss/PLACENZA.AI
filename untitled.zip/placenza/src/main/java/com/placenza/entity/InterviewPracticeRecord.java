package com.placenza.entity;

import jakarta.persistence.*;
import java.time.LocalDateTime;

@Entity
@Table(name = "interview_practice_records")
public class InterviewPracticeRecord {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @ManyToOne(fetch = FetchType.LAZY, optional = false)
    @JoinColumn(name = "user_id", nullable = false)
    private User user;

    @ManyToOne(fetch = FetchType.LAZY, optional = false)
    @JoinColumn(name = "interview_question_id", nullable = false)
    private InterviewQuestion interviewQuestion;

    @Column(name = "practiced_at", updatable = false)
    private LocalDateTime practicedAt = LocalDateTime.now();

    @Column(columnDefinition = "TEXT")
    private String notes;

    @Column(name = "self_rating")
    private Integer selfRating = 5;

    public InterviewPracticeRecord() {}

    public InterviewPracticeRecord(User user, InterviewQuestion interviewQuestion, String notes, Integer selfRating) {
        this.user = user;
        this.interviewQuestion = interviewQuestion;
        this.notes = notes;
        this.selfRating = selfRating != null ? selfRating : 5;
        this.practicedAt = LocalDateTime.now();
    }

    // Getters and Setters
    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }

    public User getUser() { return user; }
    public void setUser(User user) { this.user = user; }

    public InterviewQuestion getInterviewQuestion() { return interviewQuestion; }
    public void setInterviewQuestion(InterviewQuestion interviewQuestion) { this.interviewQuestion = interviewQuestion; }

    public LocalDateTime getPracticedAt() { return practicedAt; }
    public void setPracticedAt(LocalDateTime practicedAt) { this.practicedAt = practicedAt; }

    public String getNotes() { return notes; }
    public void setNotes(String notes) { this.notes = notes; }

    public Integer getSelfRating() { return selfRating; }
    public void setSelfRating(Integer selfRating) { this.selfRating = selfRating; }
}
