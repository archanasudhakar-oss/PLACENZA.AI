package com.placenza.entity;

import jakarta.persistence.*;
import java.time.LocalDateTime;

@Entity
@Table(name = "user_profiles")
public class UserProfile {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @OneToOne(fetch = FetchType.LAZY, optional = false)
    @JoinColumn(name = "user_id", nullable = false, unique = true)
    private User user;

    @Column(length = 180)
    private String college;

    @Column(length = 100)
    private String degree;

    @Column(name = "graduation_year")
    private Integer graduationYear;

    @Column(name = "career_role", length = 120)
    private String careerRole;

    @Column(length = 30)
    private String phone;

    @Column(columnDefinition = "TEXT")
    private String bio;

    @Column(name = "target_companies", length = 255)
    private String targetCompanies;

    @Column(name = "readiness_score")
    private Double readinessScore = 0.0;

    @Column(name = "is_provisional")
    private boolean isProvisional = true;

    @Column(name = "updated_at")
    private LocalDateTime updatedAt = LocalDateTime.now();

    public UserProfile() {}

    public UserProfile(User user) {
        this.user = user;
        this.readinessScore = 0.0;
        this.isProvisional = true;
        this.updatedAt = LocalDateTime.now();
    }

    @PrePersist
    @PreUpdate
    protected void onSave() {
        this.updatedAt = LocalDateTime.now();
    }

    public int getProfileCompletionPercentage() {
        int fields = 0;
        int filled = 0;
        fields++; if (college != null && !college.isBlank()) filled++;
        fields++; if (degree != null && !degree.isBlank()) filled++;
        fields++; if (graduationYear != null && graduationYear > 0) filled++;
        fields++; if (careerRole != null && !careerRole.isBlank()) filled++;
        fields++; if (bio != null && !bio.isBlank()) filled++;
        fields++; if (targetCompanies != null && !targetCompanies.isBlank()) filled++;
        return fields > 0 ? (filled * 100) / fields : 0;
    }

    // Getters and Setters
    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }

    public User getUser() { return user; }
    public void setUser(User user) { this.user = user; }

    public String getCollege() { return college; }
    public void setCollege(String college) { this.college = college; }

    public String getDegree() { return degree; }
    public void setDegree(String degree) { this.degree = degree; }

    public Integer getGraduationYear() { return graduationYear; }
    public void setGraduationYear(Integer graduationYear) { this.graduationYear = graduationYear; }

    public String getCareerRole() { return careerRole; }
    public void setCareerRole(String careerRole) { this.careerRole = careerRole; }

    public String getPhone() { return phone; }
    public void setPhone(String phone) { this.phone = phone; }

    public String getBio() { return bio; }
    public void setBio(String bio) { this.bio = bio; }

    public String getTargetCompanies() { return targetCompanies; }
    public void setTargetCompanies(String targetCompanies) { this.targetCompanies = targetCompanies; }

    public Double getReadinessScore() { return readinessScore != null ? readinessScore : 0.0; }
    public void setReadinessScore(Double readinessScore) { this.readinessScore = readinessScore; }

    public boolean isProvisional() { return isProvisional; }
    public void setProvisional(boolean provisional) { isProvisional = provisional; }

    public LocalDateTime getUpdatedAt() { return updatedAt; }
    public void setUpdatedAt(LocalDateTime updatedAt) { this.updatedAt = updatedAt; }
}
