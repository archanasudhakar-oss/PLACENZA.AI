package com.placenza.entity;

public enum Role {
    ROLE_STUDENT,
    ROLE_ADMIN,
    ROLE_GUEST
}
