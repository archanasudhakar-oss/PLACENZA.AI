package com.placenza.entity;

import jakarta.persistence.*;
import jakarta.validation.constraints.NotBlank;
import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

@Entity
@Table(name = "purchases")
public class Purchase {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @NotBlank
    @Column(name = "purchase_reference", length = 64, nullable = false, unique = true)
    private String purchaseReference;

    @ManyToOne(fetch = FetchType.LAZY, optional = false)
    @JoinColumn(name = "user_id", nullable = false)
    private User user;

    @NotBlank
    @Column(name = "service_offering", length = 120, nullable = false)
    private String serviceOffering;

    @Column(nullable = false, precision = 10, scale = 2)
    private BigDecimal amount;

    @Column(length = 10)
    private String currency = "INR";

    @Enumerated(EnumType.STRING)
    @Column(length = 30)
    private TransactionStatus status = TransactionStatus.INITIATED;

    @Column(name = "payment_mode", length = 30)
    private String paymentMode = "DEMO_SIMULATION";

    @Column(name = "created_at", updatable = false)
    private LocalDateTime createdAt = LocalDateTime.now();

    @OneToMany(mappedBy = "purchase", cascade = CascadeType.ALL, orphanRemoval = true)
    private List<PaymentTransaction> transactions = new ArrayList<>();

    public Purchase() {}

    public Purchase(String purchaseReference, User user, String serviceOffering, BigDecimal amount, String currency, String paymentMode) {
        this.purchaseReference = purchaseReference;
        this.user = user;
        this.serviceOffering = serviceOffering;
        this.amount = amount;
        this.currency = currency != null ? currency : "INR";
        this.paymentMode = paymentMode != null ? paymentMode : "DEMO_SIMULATION";
        this.status = TransactionStatus.INITIATED;
        this.createdAt = LocalDateTime.now();
    }

    // Getters and Setters
    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }

    public String getPurchaseReference() { return purchaseReference; }
    public void setPurchaseReference(String purchaseReference) { this.purchaseReference = purchaseReference; }

    public User getUser() { return user; }
    public void setUser(User user) { this.user = user; }

    public String getServiceOffering() { return serviceOffering; }
    public void setServiceOffering(String serviceOffering) { this.serviceOffering = serviceOffering; }

    public BigDecimal getAmount() { return amount; }
    public void setAmount(BigDecimal amount) { this.amount = amount; }

    public String getCurrency() { return currency; }
    public void setCurrency(String currency) { this.currency = currency; }

    public TransactionStatus getStatus() { return status; }
    public void setStatus(TransactionStatus status) { this.status = status; }

    public String getPaymentMode() { return paymentMode; }
    public void setPaymentMode(String paymentMode) { this.paymentMode = paymentMode; }

    public LocalDateTime getCreatedAt() { return createdAt; }
    public void setCreatedAt(LocalDateTime createdAt) { this.createdAt = createdAt; }

    public List<PaymentTransaction> getTransactions() { return transactions; }
    public void setTransactions(List<PaymentTransaction> transactions) { this.transactions = transactions; }
}
