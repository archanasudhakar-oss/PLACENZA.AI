package com.placenza.entity;

import jakarta.persistence.*;
import jakarta.validation.constraints.NotBlank;
import java.time.LocalDateTime;

@Entity
@Table(name = "roadmap_tasks")
public class RoadmapTask {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @ManyToOne(fetch = FetchType.LAZY, optional = false)
    @JoinColumn(name = "roadmap_id", nullable = false)
    private Roadmap roadmap;

    @NotBlank(message = "Task title is required")
    @Column(nullable = false, length = 180)
    private String title;

    @Column(columnDefinition = "TEXT")
    private String description;

    @Column(name = "related_skill", length = 100)
    private String relatedSkill;

    @Enumerated(EnumType.STRING)
    @Column(length = 30)
    private Priority priority = Priority.MEDIUM;

    @Column(name = "estimated_hours")
    private Integer estimatedHours = 4;

    @Enumerated(EnumType.STRING)
    @Column(length = 30)
    private TaskStatus status = TaskStatus.PENDING;

    @Column(name = "sort_order")
    private Integer sortOrder = 0;

    @Column(name = "completed_at")
    private LocalDateTime completedAt;

    public RoadmapTask() {}

    public RoadmapTask(Roadmap roadmap, String title, String description, String relatedSkill, Priority priority, Integer estimatedHours, Integer sortOrder) {
        this.roadmap = roadmap;
        this.title = title;
        this.description = description;
        this.relatedSkill = relatedSkill;
        this.priority = priority != null ? priority : Priority.MEDIUM;
        this.estimatedHours = estimatedHours != null ? estimatedHours : 4;
        this.sortOrder = sortOrder != null ? sortOrder : 0;
        this.status = TaskStatus.PENDING;
    }

    public void markCompleted() {
        this.status = TaskStatus.COMPLETED;
        this.completedAt = LocalDateTime.now();
    }

    public void markPending() {
        this.status = TaskStatus.PENDING;
        this.completedAt = null;
    }

    // Getters and Setters
    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }

    public Roadmap getRoadmap() { return roadmap; }
    public void setRoadmap(Roadmap roadmap) { this.roadmap = roadmap; }

    public String getTitle() { return title; }
    public void setTitle(String title) { this.title = title; }

    public String getDescription() { return description; }
    public void setDescription(String description) { this.description = description; }

    public String getRelatedSkill() { return relatedSkill; }
    public void setRelatedSkill(String relatedSkill) { this.relatedSkill = relatedSkill; }

    public Priority getPriority() { return priority; }
    public void setPriority(Priority priority) { this.priority = priority; }

    public Integer getEstimatedHours() { return estimatedHours; }
    public void setEstimatedHours(Integer estimatedHours) { this.estimatedHours = estimatedHours; }

    public TaskStatus getStatus() { return status; }
    public void setStatus(TaskStatus status) { this.status = status; }

    public Integer getSortOrder() { return sortOrder; }
    public void setSortOrder(Integer sortOrder) { this.sortOrder = sortOrder; }

    public LocalDateTime getCompletedAt() { return completedAt; }
    public void setCompletedAt(LocalDateTime completedAt) { this.completedAt = completedAt; }
}
