package com.placenza.repository;

import com.placenza.entity.Purchase;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

@Repository
public interface PurchaseRepository extends JpaRepository<Purchase, Long> {
    List<Purchase> findByUserIdOrderByCreatedAtDesc(Long userId);
    Optional<Purchase> findByPurchaseReference(String purchaseReference);
    Page<Purchase> findAllByOrderByCreatedAtDesc(Pageable pageable);
}
