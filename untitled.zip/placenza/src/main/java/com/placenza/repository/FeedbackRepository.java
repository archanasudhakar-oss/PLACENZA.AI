package com.placenza.repository;

import com.placenza.entity.Feedback;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface FeedbackRepository extends JpaRepository<Feedback, Long> {
    List<Feedback> findByUserIdOrderBySubmittedAtDesc(Long userId);
    Page<Feedback> findAllByOrderBySubmittedAtDesc(Pageable pageable);

    @Query("SELECT AVG(f.rating) FROM Feedback f")
    Double calculateAverageRating();

    long countByRating(int rating);
}
