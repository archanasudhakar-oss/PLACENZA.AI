package com.placenza.repository;

import com.placenza.entity.PaymentTransaction;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

@Repository
public interface PaymentTransactionRepository extends JpaRepository<PaymentTransaction, Long> {
    Optional<PaymentTransaction> findByTransactionReference(String transactionReference);
    Page<PaymentTransaction> findAllByOrderByCreatedAtDesc(Pageable pageable);
    List<PaymentTransaction> findByPurchaseUserIdOrderByCreatedAtDesc(Long userId);
}
