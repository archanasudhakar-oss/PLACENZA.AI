package com.placenza.repository;

import com.placenza.entity.ActivityRecord;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface ActivityRecordRepository extends JpaRepository<ActivityRecord, Long> {
    List<ActivityRecord> findByUserIdOrderByCreatedAtDesc(Long userId);
    List<ActivityRecord> findByUserIdOrderByCreatedAtDesc(Long userId, Pageable pageable);
}
