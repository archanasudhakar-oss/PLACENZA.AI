package com.placenza.repository;

import com.placenza.entity.AssessmentAttempt;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface AssessmentAttemptRepository extends JpaRepository<AssessmentAttempt, Long> {
    List<AssessmentAttempt> findByUserIdOrderByCompletedAtDesc(Long userId);
    long countByUserId(Long userId);
    List<AssessmentAttempt> findByUserIdAndAssessmentId(Long userId, Long assessmentId);

    @Query("SELECT AVG(a.scorePercentage) FROM AssessmentAttempt a WHERE a.user.id = :userId")
    Double getAverageScoreByUserId(@Param("userId") Long userId);
}
