package com.placenza.repository;

import com.placenza.entity.Difficulty;
import com.placenza.entity.InterviewQuestion;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface InterviewQuestionRepository extends JpaRepository<InterviewQuestion, Long> {
    List<InterviewQuestion> findByCategoryId(Long categoryId);
    List<InterviewQuestion> findByDifficulty(Difficulty difficulty);
    List<InterviewQuestion> findByCategoryIdAndDifficulty(Long categoryId, Difficulty difficulty);

    @Query("SELECT q FROM InterviewQuestion q WHERE LOWER(q.questionText) LIKE LOWER(CONCAT('%', :keyword, '%')) OR LOWER(q.referenceAnswer) LIKE LOWER(CONCAT('%', :keyword, '%'))")
    Page<InterviewQuestion> searchInterviewQuestions(@Param("keyword") String keyword, Pageable pageable);
}
