package com.placenza.repository;

import com.placenza.entity.InterviewPracticeRecord;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

@Repository
public interface InterviewPracticeRecordRepository extends JpaRepository<InterviewPracticeRecord, Long> {
    List<InterviewPracticeRecord> findByUserIdOrderByPracticedAtDesc(Long userId);
    long countByUserId(Long userId);
    Optional<InterviewPracticeRecord> findByUserIdAndInterviewQuestionId(Long userId, Long interviewQuestionId);
    boolean existsByUserIdAndInterviewQuestionId(Long userId, Long interviewQuestionId);
}
