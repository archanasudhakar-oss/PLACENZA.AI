package com.placenza.repository;

import com.placenza.entity.RoadmapTask;
import com.placenza.entity.TaskStatus;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface RoadmapTaskRepository extends JpaRepository<RoadmapTask, Long> {
    List<RoadmapTask> findByRoadmapIdOrderBySortOrderAsc(Long roadmapId);
    List<RoadmapTask> findByRoadmapIdAndStatus(Long roadmapId, TaskStatus status);
    long countByRoadmapIdAndStatus(Long roadmapId, TaskStatus status);

    @Query("SELECT t FROM RoadmapTask t WHERE t.roadmap.user.id = :userId AND (LOWER(t.title) LIKE LOWER(CONCAT('%', :keyword, '%')) OR LOWER(t.description) LIKE LOWER(CONCAT('%', :keyword, '%')) OR LOWER(t.relatedSkill) LIKE LOWER(CONCAT('%', :keyword, '%')))")
    Page<RoadmapTask> searchUserRoadmapTasks(@Param("userId") Long userId, @Param("keyword") String keyword, Pageable pageable);
}
