package com.placenza.dto;

import com.placenza.entity.Priority;
import com.placenza.entity.TaskStatus;
import java.time.LocalDateTime;

public class RoadmapTaskDto {

    private Long id;
    private String title;
    private String description;
    private String relatedSkill;
    private Priority priority;
    private Integer estimatedHours;
    private TaskStatus status;
    private Integer sortOrder;
    private LocalDateTime completedAt;

    public RoadmapTaskDto() {}

    public RoadmapTaskDto(Long id, String title, String description, String relatedSkill, Priority priority, Integer estimatedHours, TaskStatus status, Integer sortOrder, LocalDateTime completedAt) {
        this.id = id;
        this.title = title;
        this.description = description;
        this.relatedSkill = relatedSkill;
        this.priority = priority;
        this.estimatedHours = estimatedHours;
        this.status = status;
        this.sortOrder = sortOrder;
        this.completedAt = completedAt;
    }

    // Getters and Setters
    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }

    public String getTitle() { return title; }
    public void setTitle(String title) { this.title = title; }

    public String getDescription() { return description; }
    public void setDescription(String description) { this.description = description; }

    public String getRelatedSkill() { return relatedSkill; }
    public void setRelatedSkill(String relatedSkill) { this.relatedSkill = relatedSkill; }

    public Priority getPriority() { return priority; }
    public void setPriority(Priority priority) { this.priority = priority; }

    public Integer getEstimatedHours() { return estimatedHours; }
    public void setEstimatedHours(Integer estimatedHours) { this.estimatedHours = estimatedHours; }

    public TaskStatus getStatus() { return status; }
    public void setStatus(TaskStatus status) { this.status = status; }

    public Integer getSortOrder() { return sortOrder; }
    public void setSortOrder(Integer sortOrder) { this.sortOrder = sortOrder; }

    public LocalDateTime getCompletedAt() { return completedAt; }
    public void setCompletedAt(LocalDateTime completedAt) { this.completedAt = completedAt; }
}
