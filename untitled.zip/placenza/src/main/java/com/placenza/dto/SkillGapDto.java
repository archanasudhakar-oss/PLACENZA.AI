package com.placenza.dto;

public class SkillGapDto {

    private String skillName;
    private String categoryName;
    private String status; // "Strong", "Developing", "Needs Improvement", "Not Assessed"
    private Double scorePercentage;
    private String recommendation;
    private String badgeClass;

    public SkillGapDto() {}

    public SkillGapDto(String skillName, String categoryName, String status, Double scorePercentage, String recommendation, String badgeClass) {
        this.skillName = skillName;
        this.categoryName = categoryName;
        this.status = status;
        this.scorePercentage = scorePercentage;
        this.recommendation = recommendation;
        this.badgeClass = badgeClass;
    }

    // Getters and Setters
    public String getSkillName() { return skillName; }
    public void setSkillName(String skillName) { this.skillName = skillName; }

    public String getCategoryName() { return categoryName; }
    public void setCategoryName(String categoryName) { this.categoryName = categoryName; }

    public String getStatus() { return status; }
    public void setStatus(String status) { this.status = status; }

    public Double getScorePercentage() { return scorePercentage; }
    public void setScorePercentage(Double scorePercentage) { this.scorePercentage = scorePercentage; }

    public String getRecommendation() { return recommendation; }
    public void setRecommendation(String recommendation) { this.recommendation = recommendation; }

    public String getBadgeClass() { return badgeClass; }
    public void setBadgeClass(String badgeClass) { this.badgeClass = badgeClass; }
}
