package com.placenza.dto;

import jakarta.validation.constraints.NotBlank;

public class DemoPaymentRequestDto {

    @NotBlank(message = "Service offering is required")
    private String offeringKey; // e.g. "MOCK_INTERVIEW_PRO", "DSA_ADVANCED_PACK", "PREMIUM_CAREER_ROADMAP"

    private String notes;

    public DemoPaymentRequestDto() {}

    public DemoPaymentRequestDto(String offeringKey, String notes) {
        this.offeringKey = offeringKey;
        this.notes = notes;
    }

    public String getOfferingKey() { return offeringKey; }
    public void setOfferingKey(String offeringKey) { this.offeringKey = offeringKey; }

    public String getNotes() { return notes; }
    public void setNotes(String notes) { this.notes = notes; }
}
