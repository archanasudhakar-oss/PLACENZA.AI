package com.placenza.dto;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

public class ChatResponseDto {

    private String reply;
    private String topic;
    private List<String> suggestions = new ArrayList<>();
    private LocalDateTime timestamp = LocalDateTime.now();

    public ChatResponseDto() {}

    public ChatResponseDto(String reply, String topic, List<String> suggestions) {
        this.reply = reply;
        this.topic = topic;
        this.suggestions = suggestions != null ? suggestions : new ArrayList<>();
        this.timestamp = LocalDateTime.now();
    }

    public String getReply() { return reply; }
    public void setReply(String reply) { this.reply = reply; }

    public String getTopic() { return topic; }
    public void setTopic(String topic) { this.topic = topic; }

    public List<String> getSuggestions() { return suggestions; }
    public void setSuggestions(List<String> suggestions) { this.suggestions = suggestions; }

    public LocalDateTime getTimestamp() { return timestamp; }
    public void setTimestamp(LocalDateTime timestamp) { this.timestamp = timestamp; }
}
