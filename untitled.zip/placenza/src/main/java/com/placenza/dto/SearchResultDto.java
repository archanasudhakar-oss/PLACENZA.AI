package com.placenza.dto;

public class SearchResultDto {

    private String type; // "CATEGORY", "ASSESSMENT", "INTERVIEW", "ROADMAP"
    private Long id;
    private String title;
    private String description;
    private String categoryName;
    private String difficulty;
    private String url;

    public SearchResultDto() {}

    public SearchResultDto(String type, Long id, String title, String description, String categoryName, String difficulty, String url) {
        this.type = type;
        this.id = id;
        this.title = title;
        this.description = description;
        this.categoryName = categoryName;
        this.difficulty = difficulty;
        this.url = url;
    }

    // Getters and Setters
    public String getType() { return type; }
    public void setType(String type) { this.type = type; }

    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }

    public String getTitle() { return title; }
    public void setTitle(String title) { this.title = title; }

    public String getDescription() { return description; }
    public void setDescription(String description) { this.description = description; }

    public String getCategoryName() { return categoryName; }
    public void setCategoryName(String categoryName) { this.categoryName = categoryName; }

    public String getDifficulty() { return difficulty; }
    public void setDifficulty(String difficulty) { this.difficulty = difficulty; }

    public String getUrl() { return url; }
    public void setUrl(String url) { this.url = url; }
}
