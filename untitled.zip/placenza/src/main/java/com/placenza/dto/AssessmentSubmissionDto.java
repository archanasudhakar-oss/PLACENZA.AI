package com.placenza.dto;

import jakarta.validation.constraints.NotNull;
import java.util.ArrayList;
import java.util.List;

public class AssessmentSubmissionDto {

    @NotNull
    private Long assessmentId;

    private List<AnswerSubmissionDto> answers = new ArrayList<>();

    public AssessmentSubmissionDto() {}

    public AssessmentSubmissionDto(Long assessmentId, List<AnswerSubmissionDto> answers) {
        this.assessmentId = assessmentId;
        this.answers = answers;
    }

    public Long getAssessmentId() { return assessmentId; }
    public void setAssessmentId(Long assessmentId) { this.assessmentId = assessmentId; }

    public List<AnswerSubmissionDto> getAnswers() { return answers; }
    public void setAnswers(List<AnswerSubmissionDto> answers) { this.answers = answers; }
}
