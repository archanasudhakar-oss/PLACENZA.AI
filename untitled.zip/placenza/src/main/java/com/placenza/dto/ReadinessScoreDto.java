package com.placenza.dto;

import java.util.ArrayList;
import java.util.List;

/**
 * Transparent Placement Readiness Score breakdown:
 * - Technical assessments: 40%
 * - Aptitude: 20%
 * - Interview practice: 20%
 * - Roadmap completion: 10%
 * - Profile and career preparation: 10%
 */
public class ReadinessScoreDto {

    private double overallScore;
    private boolean provisional;
    private String provisionalReason;

    private double technicalComponent; // out of 40
    private double aptitudeComponent;  // out of 20
    private double interviewComponent; // out of 20
    private double roadmapComponent;   // out of 10
    private double profileComponent;   // out of 10

    // Raw 0-100 values
    private double technicalScoreRaw;
    private double aptitudeScoreRaw;
    private double interviewScoreRaw;
    private double roadmapScoreRaw;
    private double profileScoreRaw;

    private String readinessBand; // "Placement Ready", "Advancing Well", "Developing", "Early Stage"
    private String summaryText;
    private List<String> contributingFactors = new ArrayList<>();

    public ReadinessScoreDto() {}

    // Getters and Setters
    public double getOverallScore() { return overallScore; }
    public void setOverallScore(double overallScore) { this.overallScore = overallScore; }

    public boolean isProvisional() { return provisional; }
    public void setProvisional(boolean provisional) { this.provisional = provisional; }

    public String getProvisionalReason() { return provisionalReason; }
    public void setProvisionalReason(String provisionalReason) { this.provisionalReason = provisionalReason; }

    public double getTechnicalComponent() { return technicalComponent; }
    public void setTechnicalComponent(double technicalComponent) { this.technicalComponent = technicalComponent; }

    public double getAptitudeComponent() { return aptitudeComponent; }
    public void setAptitudeComponent(double aptitudeComponent) { this.aptitudeComponent = aptitudeComponent; }

    public double getInterviewComponent() { return interviewComponent; }
    public void setInterviewComponent(double interviewComponent) { this.interviewComponent = interviewComponent; }

    public double getRoadmapComponent() { return roadmapComponent; }
    public void setRoadmapComponent(double roadmapComponent) { this.roadmapComponent = roadmapComponent; }

    public double getProfileComponent() { return profileComponent; }
    public void setProfileComponent(double profileComponent) { this.profileComponent = profileComponent; }

    public double getTechnicalScoreRaw() { return technicalScoreRaw; }
    public void setTechnicalScoreRaw(double technicalScoreRaw) { this.technicalScoreRaw = technicalScoreRaw; }

    public double getAptitudeScoreRaw() { return aptitudeScoreRaw; }
    public void setAptitudeScoreRaw(double aptitudeScoreRaw) { this.aptitudeScoreRaw = aptitudeScoreRaw; }

    public double getInterviewScoreRaw() { return interviewScoreRaw; }
    public void setInterviewScoreRaw(double interviewScoreRaw) { this.interviewScoreRaw = interviewScoreRaw; }

    public double getRoadmapScoreRaw() { return roadmapScoreRaw; }
    public void setRoadmapScoreRaw(double roadmapScoreRaw) { this.roadmapScoreRaw = roadmapScoreRaw; }

    public double getProfileScoreRaw() { return profileScoreRaw; }
    public void setProfileScoreRaw(double profileScoreRaw) { this.profileScoreRaw = profileScoreRaw; }

    public String getReadinessBand() { return readinessBand; }
    public void setReadinessBand(String readinessBand) { this.readinessBand = readinessBand; }

    public String getSummaryText() { return summaryText; }
    public void setSummaryText(String summaryText) { this.summaryText = summaryText; }

    public List<String> getContributingFactors() { return contributingFactors; }
    public void setContributingFactors(List<String> contributingFactors) { this.contributingFactors = contributingFactors; }
}
