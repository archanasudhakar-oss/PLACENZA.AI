package com.placenza.dto;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

public class AssessmentResultDto {

    private Long attemptId;
    private Long assessmentId;
    private String assessmentTitle;
    private String categoryName;
    private int totalQuestions;
    private int correctAnswers;
    private double scorePercentage;
    private boolean passed;
    private LocalDateTime completedAt;
    private List<AnswerReviewDto> answerReviews = new ArrayList<>();
    private List<String> recommendations = new ArrayList<>();

    public AssessmentResultDto() {}

    // Getters and Setters
    public Long getAttemptId() { return attemptId; }
    public void setAttemptId(Long attemptId) { this.attemptId = attemptId; }

    public Long getAssessmentId() { return assessmentId; }
    public void setAssessmentId(Long assessmentId) { this.assessmentId = assessmentId; }

    public String getAssessmentTitle() { return assessmentTitle; }
    public void setAssessmentTitle(String assessmentTitle) { this.assessmentTitle = assessmentTitle; }

    public String getCategoryName() { return categoryName; }
    public void setCategoryName(String categoryName) { this.categoryName = categoryName; }

    public int getTotalQuestions() { return totalQuestions; }
    public void setTotalQuestions(int totalQuestions) { this.totalQuestions = totalQuestions; }

    public int getCorrectAnswers() { return correctAnswers; }
    public void setCorrectAnswers(int correctAnswers) { this.correctAnswers = correctAnswers; }

    public double getScorePercentage() { return scorePercentage; }
    public void setScorePercentage(double scorePercentage) { this.scorePercentage = scorePercentage; }

    public boolean isPassed() { return passed; }
    public void setPassed(boolean passed) { this.passed = passed; }

    public LocalDateTime getCompletedAt() { return completedAt; }
    public void setCompletedAt(LocalDateTime completedAt) { this.completedAt = completedAt; }

    public List<AnswerReviewDto> getAnswerReviews() { return answerReviews; }
    public void setAnswerReviews(List<AnswerReviewDto> answerReviews) { this.answerReviews = answerReviews; }

    public List<String> getRecommendations() { return recommendations; }
    public void setRecommendations(List<String> recommendations) { this.recommendations = recommendations; }
}
