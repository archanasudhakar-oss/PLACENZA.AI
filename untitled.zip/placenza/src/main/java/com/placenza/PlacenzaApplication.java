package com.placenza;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.domain.EntityScan;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;
import org.springframework.scheduling.annotation.EnableScheduling;

/**
 * PLACENZA AI: Intelligent Placement Readiness and Career Development Platform.
 * Main Spring Boot Application Bootstrapper.
 *
 * "Your Potential. Your Preparation. Your Placement."
 */
@SpringBootApplication
@EntityScan(basePackages = "com.placenza.entity")
@EnableJpaRepositories(basePackages = "com.placenza.repository")
@EnableScheduling
public class PlacenzaApplication {

    public static void main(String[] args) {
        SpringApplication.run(PlacenzaApplication.class, args);
    }
}
