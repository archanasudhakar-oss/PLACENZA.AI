package com.placenza.security;

import com.placenza.entity.Role;
import com.placenza.entity.User;
import com.placenza.exception.UnauthorizedAccessException;
import com.placenza.repository.UserRepository;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Component;

import java.util.Optional;

@Component
public class SecurityUtil {

    private final UserRepository userRepository;

    public SecurityUtil(UserRepository userRepository) {
        this.userRepository = userRepository;
    }

    public Optional<User> getCurrentUserOptional() {
        Authentication auth = SecurityContextHolder.getContext().getAuthentication();
        if (auth == null || !auth.isAuthenticated() || "anonymousUser".equals(auth.getPrincipal())) {
            return Optional.empty();
        }
        String email = auth.getName();
        return userRepository.findByEmail(email);
    }

    public User getCurrentAuthenticatedUser() {
        return getCurrentUserOptional().orElseThrow(() ->
                new UnauthorizedAccessException("You must be logged in to access this resource"));
    }

    public void verifyUserOwnership(Long resourceOwnerUserId) {
        User current = getCurrentAuthenticatedUser();
        if (current.getRole() == Role.ROLE_ADMIN) {
            return; // Admins are permitted to view or manage resources
        }
        if (!current.getId().equals(resourceOwnerUserId)) {
            throw new UnauthorizedAccessException("You do not have permission to access or modify this resource");
        }
    }

    public boolean isAdmin() {
        return getCurrentUserOptional()
                .map(user -> user.getRole() == Role.ROLE_ADMIN)
                .orElse(false);
    }
}
