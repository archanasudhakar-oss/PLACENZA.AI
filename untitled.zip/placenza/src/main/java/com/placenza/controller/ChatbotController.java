package com.placenza.controller;

import com.placenza.dto.ChatMessageDto;
import com.placenza.dto.ChatResponseDto;
import com.placenza.entity.User;
import com.placenza.security.SecurityUtil;
import com.placenza.service.ChatbotService;
import jakarta.servlet.http.HttpSession;
import jakarta.validation.Valid;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import java.util.ArrayList;
import java.util.List;

@Controller
public class ChatbotController {

    private final ChatbotService chatbotService;
    private final SecurityUtil securityUtil;

    public ChatbotController(ChatbotService chatbotService, SecurityUtil securityUtil) {
        this.chatbotService = chatbotService;
        this.securityUtil = securityUtil;
    }

    public record SessionMessage(String sender, String text, String topic, String time) {}

    @GetMapping("/chatbot")
    public String showChatPage(Model model, HttpSession session) {
        User user = securityUtil.getCurrentAuthenticatedUser();

        @SuppressWarnings("unchecked")
        List<SessionMessage> history = (List<SessionMessage>) session.getAttribute("CHAT_HISTORY");
        if (history == null) {
            history = new ArrayList<>();
            history.add(new SessionMessage(
                    "bot",
                    "Hello " + user.getFullName() + "! I am the Placenza AI Placement Assistant. Ask me about Java, OOP, SQL, DBMS, DSA, Aptitude, HR interviews, or your placement readiness score.",
                    "Welcome",
                    "Just now"
            ));
            session.setAttribute("CHAT_HISTORY", history);
        }

        model.addAttribute("chatHistory", history);
        model.addAttribute("user", user);
        return "chatbot/chat";
    }

    @PostMapping("/api/chat")
    @ResponseBody
    public ResponseEntity<ChatResponseDto> processChat(@Valid @RequestBody ChatMessageDto request, HttpSession session) {
        ChatResponseDto response = chatbotService.processMessage(request.getMessage());

        @SuppressWarnings("unchecked")
        List<SessionMessage> history = (List<SessionMessage>) session.getAttribute("CHAT_HISTORY");
        if (history == null) {
            history = new ArrayList<>();
        }
        history.add(new SessionMessage("user", request.getMessage(), "User Query", "Now"));
        history.add(new SessionMessage("bot", response.getReply(), response.getTopic(), "Now"));
        session.setAttribute("CHAT_HISTORY", history);

        return ResponseEntity.ok(response);
    }

    @PostMapping("/api/chat/clear")
    @ResponseBody
    public ResponseEntity<Void> clearHistory(HttpSession session) {
        session.removeAttribute("CHAT_HISTORY");
        return ResponseEntity.ok().build();
    }
}
