package com.placenza.controller;

import com.placenza.dto.SearchResultDto;
import com.placenza.entity.User;
import com.placenza.security.SecurityUtil;
import com.placenza.service.SearchService;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;

import java.util.List;

@Controller
public class SearchController {

    private final SearchService searchService;
    private final SecurityUtil securityUtil;

    public SearchController(SearchService searchService, SecurityUtil securityUtil) {
        this.searchService = searchService;
        this.securityUtil = securityUtil;
    }

    @GetMapping("/search")
    public String search(@RequestParam(value = "q", required = false) String query,
                         @RequestParam(value = "type", required = false) String type,
                         Model model) {
        User user = securityUtil.getCurrentUserOptional().orElse(null);
        Long userId = (user != null) ? user.getId() : null;

        List<SearchResultDto> results = searchService.executeSearch(query, type, userId);

        model.addAttribute("query", query);
        model.addAttribute("selectedType", type);
        model.addAttribute("results", results);
        model.addAttribute("user", user);

        return "search/results";
    }
}
