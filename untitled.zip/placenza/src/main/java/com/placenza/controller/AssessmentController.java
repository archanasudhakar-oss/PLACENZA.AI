package com.placenza.controller;

import com.placenza.dto.AnswerSubmissionDto;
import com.placenza.dto.AssessmentDetailDto;
import com.placenza.dto.AssessmentResultDto;
import com.placenza.dto.AssessmentSubmissionDto;
import com.placenza.entity.Assessment;
import com.placenza.entity.AssessmentAttempt;
import com.placenza.entity.User;
import com.placenza.security.SecurityUtil;
import com.placenza.service.AssessmentService;
import jakarta.servlet.http.HttpServletRequest;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import java.util.ArrayList;
import java.util.List;

@Controller
@RequestMapping("/assessments")
public class AssessmentController {

    private final AssessmentService assessmentService;
    private final SecurityUtil securityUtil;

    public AssessmentController(AssessmentService assessmentService, SecurityUtil securityUtil) {
        this.assessmentService = assessmentService;
        this.securityUtil = securityUtil;
    }

    @GetMapping
    public String listAssessments(Model model) {
        User user = securityUtil.getCurrentAuthenticatedUser();
        List<Assessment> assessments = assessmentService.getAllAssessments();
        List<AssessmentAttempt> userAttempts = assessmentService.getUserAttempts(user.getId());

        model.addAttribute("assessments", assessments);
        model.addAttribute("userAttempts", userAttempts);
        model.addAttribute("user", user);
        return "assessment/list";
    }

    @GetMapping("/{id}/take")
    public String takeAssessment(@PathVariable Long id, Model model) {
        User user = securityUtil.getCurrentAuthenticatedUser();
        AssessmentDetailDto detail = assessmentService.getAssessmentForTaking(id);
        model.addAttribute("assessment", detail);
        model.addAttribute("user", user);
        return "assessment/take";
    }

    @PostMapping("/{id}/submit")
    public String submitAssessment(@PathVariable Long id,
                                   HttpServletRequest request,
                                   RedirectAttributes redirectAttributes) {
        User user = securityUtil.getCurrentAuthenticatedUser();
        Assessment assessment = assessmentService.getAssessmentById(id);

        List<AnswerSubmissionDto> answers = new ArrayList<>();
        for (var q : assessment.getQuestions()) {
            String paramName = "question_" + q.getId();
            String selected = request.getParameter(paramName);
            answers.add(new AnswerSubmissionDto(q.getId(), selected));
        }

        AssessmentSubmissionDto submission = new AssessmentSubmissionDto(id, answers);
        AssessmentResultDto result = assessmentService.submitAssessment(user, submission);

        redirectAttributes.addFlashAttribute("result", result);
        return "redirect:/assessments/attempts/" + result.getAttemptId();
    }

    @GetMapping("/attempts/{attemptId}")
    public String viewAttemptResult(@PathVariable Long attemptId, Model model) {
        User user = securityUtil.getCurrentAuthenticatedUser();
        AssessmentResultDto result = assessmentService.getAttemptReview(attemptId, user.getId());
        model.addAttribute("result", result);
        model.addAttribute("user", user);
        return "assessment/result";
    }
}
