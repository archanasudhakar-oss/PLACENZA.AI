package com.placenza.controller.api;

import com.placenza.dto.ApiResponseDto;
import com.placenza.dto.FeedbackDto;
import com.placenza.entity.Feedback;
import com.placenza.entity.User;
import com.placenza.security.SecurityUtil;
import com.placenza.service.FeedbackService;
import jakarta.validation.Valid;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/v1/feedback")
public class ApiFeedbackController {

    private final FeedbackService feedbackService;
    private final SecurityUtil securityUtil;

    public ApiFeedbackController(FeedbackService feedbackService, SecurityUtil securityUtil) {
        this.feedbackService = feedbackService;
        this.securityUtil = securityUtil;
    }

    @PostMapping
    public ResponseEntity<ApiResponseDto<Feedback>> submit(@Valid @RequestBody FeedbackDto dto) {
        User user = securityUtil.getCurrentUserOptional().orElse(null);
        Feedback saved = (user != null)
                ? feedbackService.submitUserFeedback(user, dto)
                : feedbackService.submitGuestFeedback(dto);
        return ResponseEntity.ok(ApiResponseDto.ok("Feedback submitted", saved));
    }

    @GetMapping("/my")
    public ResponseEntity<ApiResponseDto<List<Feedback>>> getMyFeedback() {
        User user = securityUtil.getCurrentAuthenticatedUser();
        return ResponseEntity.ok(ApiResponseDto.ok("User feedback retrieved", feedbackService.getUserFeedbacks(user.getId())));
    }
}
