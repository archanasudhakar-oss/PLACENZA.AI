package com.placenza.controller.api;

import com.placenza.dto.ApiResponseDto;
import com.placenza.dto.RoadmapTaskDto;
import com.placenza.entity.RoadmapTask;
import com.placenza.entity.User;
import com.placenza.security.SecurityUtil;
import com.placenza.service.RoadmapService;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/v1/roadmap")
public class ApiRoadmapController {

    private final RoadmapService roadmapService;
    private final SecurityUtil securityUtil;

    public ApiRoadmapController(RoadmapService roadmapService, SecurityUtil securityUtil) {
        this.roadmapService = roadmapService;
        this.securityUtil = securityUtil;
    }

    @GetMapping("/tasks")
    public ResponseEntity<ApiResponseDto<List<RoadmapTaskDto>>> getTasks() {
        User user = securityUtil.getCurrentAuthenticatedUser();
        return ResponseEntity.ok(ApiResponseDto.ok("Roadmap tasks retrieved", roadmapService.getTasksForUser(user.getId())));
    }

    @PostMapping("/tasks/{id}/toggle")
    public ResponseEntity<ApiResponseDto<RoadmapTask>> toggleTask(@PathVariable Long id) {
        User user = securityUtil.getCurrentAuthenticatedUser();
        RoadmapTask task = roadmapService.toggleTaskCompletion(id, user.getId());
        return ResponseEntity.ok(ApiResponseDto.ok("Task status toggled", task));
    }
}
