package com.placenza.controller;

import com.placenza.dto.ReadinessScoreDto;
import com.placenza.dto.SkillGapDto;
import com.placenza.dto.UserProfileDto;
import com.placenza.entity.*;
import com.placenza.repository.AssessmentAttemptRepository;
import com.placenza.repository.CategoryRepository;
import com.placenza.repository.UserRepository;
import com.placenza.security.SecurityUtil;
import com.placenza.service.*;
import jakarta.validation.Valid;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import java.util.List;

@Controller
public class DashboardController {

    private final SecurityUtil securityUtil;
    private final UserService userService;
    private final ReadinessScoreService readinessScoreService;
    private final SkillGapAnalysisService skillGapService;
    private final RoadmapService roadmapService;
    private final AssessmentService assessmentService;
    private final InterviewPracticeService interviewService;
    private final FeedbackService feedbackService;
    private final UserRepository userRepository;
    private final AssessmentAttemptRepository attemptRepository;
    private final CategoryRepository categoryRepository;

    public DashboardController(SecurityUtil securityUtil,
                               UserService userService,
                               ReadinessScoreService readinessScoreService,
                               SkillGapAnalysisService skillGapService,
                               RoadmapService roadmapService,
                               AssessmentService assessmentService,
                               InterviewPracticeService interviewService,
                               FeedbackService feedbackService,
                               UserRepository userRepository,
                               AssessmentAttemptRepository attemptRepository,
                               CategoryRepository categoryRepository) {
        this.securityUtil = securityUtil;
        this.userService = userService;
        this.readinessScoreService = readinessScoreService;
        this.skillGapService = skillGapService;
        this.roadmapService = roadmapService;
        this.assessmentService = assessmentService;
        this.interviewService = interviewService;
        this.feedbackService = feedbackService;
        this.userRepository = userRepository;
        this.attemptRepository = attemptRepository;
        this.categoryRepository = categoryRepository;
    }

    @GetMapping("/dashboard")
    public String studentDashboard(Model model) {
        User user = securityUtil.getCurrentAuthenticatedUser();
        if (user.getRole() == Role.ROLE_ADMIN) {
            return "redirect:/admin/dashboard";
        }

        UserProfileDto profileDto = userService.getUserProfileDto(user.getId());
        ReadinessScoreDto readinessDto = readinessScoreService.calculateReadiness(user.getId());
        List<SkillGapDto> skillGaps = skillGapService.analyzeUserSkillGaps(user.getId());
        Roadmap roadmap = roadmapService.getOrCreateRoadmap(user, profileDto.getCareerRole());
        List<AssessmentAttempt> recentAttempts = assessmentService.getUserAttempts(user.getId());
        List<InterviewPracticeRecord> recentPractice = interviewService.getUserPracticeHistory(user.getId());

        model.addAttribute("user", user);
        model.addAttribute("profile", profileDto);
        model.addAttribute("readiness", readinessDto);
        model.addAttribute("skillGaps", skillGaps);
        model.addAttribute("roadmap", roadmap);
        model.addAttribute("recentAttempts", recentAttempts);
        model.addAttribute("recentPractice", recentPractice);

        return "dashboard/student";
    }

    @GetMapping("/admin/dashboard")
    public String adminDashboard(Model model) {
        User admin = securityUtil.getCurrentAuthenticatedUser();
        if (admin.getRole() != Role.ROLE_ADMIN) {
            return "redirect:/dashboard";
        }

        long totalUsers = userRepository.count();
        long studentCount = userRepository.countByRole(Role.ROLE_STUDENT);
        long adminCount = userRepository.countByRole(Role.ROLE_ADMIN);
        long totalAttempts = attemptRepository.count();
        long totalCategories = categoryRepository.count();

        model.addAttribute("admin", admin);
        model.addAttribute("totalUsers", totalUsers);
        model.addAttribute("studentCount", studentCount);
        model.addAttribute("adminCount", adminCount);
        model.addAttribute("totalAttempts", totalAttempts);
        model.addAttribute("totalCategories", totalCategories);
        model.addAttribute("feedbackSummary", feedbackService.getFeedbackSummary());

        return "dashboard/admin";
    }

    @GetMapping("/profile")
    public String showProfile(Model model) {
        User user = securityUtil.getCurrentAuthenticatedUser();
        UserProfileDto dto = userService.getUserProfileDto(user.getId());
        model.addAttribute("profileDto", dto);
        model.addAttribute("user", user);
        return "dashboard/profile";
    }

    @PostMapping("/profile")
    public String updateProfile(@Valid @ModelAttribute("profileDto") UserProfileDto profileDto,
                                BindingResult bindingResult,
                                Model model,
                                RedirectAttributes redirectAttributes) {
        User user = securityUtil.getCurrentAuthenticatedUser();
        if (bindingResult.hasErrors()) {
            model.addAttribute("user", user);
            return "dashboard/profile";
        }

        userService.updateProfile(user.getId(), profileDto);
        readinessScoreService.recalculateUserReadiness(user);

        redirectAttributes.addFlashAttribute("successMessage", "Profile updated successfully.");
        return "redirect:/profile";
    }
}
