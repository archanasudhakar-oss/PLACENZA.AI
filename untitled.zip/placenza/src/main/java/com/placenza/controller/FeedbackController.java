package com.placenza.controller;

import com.placenza.dto.FeedbackDto;
import com.placenza.entity.Feedback;
import com.placenza.entity.User;
import com.placenza.security.SecurityUtil;
import com.placenza.service.FeedbackService;
import jakarta.validation.Valid;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import java.util.List;

@Controller
public class FeedbackController {

    private final FeedbackService feedbackService;
    private final SecurityUtil securityUtil;

    public FeedbackController(FeedbackService feedbackService, SecurityUtil securityUtil) {
        this.feedbackService = feedbackService;
        this.securityUtil = securityUtil;
    }

    @GetMapping("/feedback")
    public String showFeedbackPage(Model model) {
        User user = securityUtil.getCurrentAuthenticatedUser();
        List<Feedback> userFeedbacks = feedbackService.getUserFeedbacks(user.getId());

        model.addAttribute("feedbackDto", new FeedbackDto());
        model.addAttribute("userFeedbacks", userFeedbacks);
        model.addAttribute("user", user);

        return "feedback/form";
    }

    @PostMapping("/feedback")
    public String submitFeedback(@Valid @ModelAttribute("feedbackDto") FeedbackDto dto,
                                 BindingResult bindingResult,
                                 Model model,
                                 RedirectAttributes redirectAttributes) {
        User user = securityUtil.getCurrentAuthenticatedUser();
        if (bindingResult.hasErrors()) {
            model.addAttribute("userFeedbacks", feedbackService.getUserFeedbacks(user.getId()));
            model.addAttribute("user", user);
            return "feedback/form";
        }

        feedbackService.submitUserFeedback(user, dto);
        redirectAttributes.addFlashAttribute("successMessage", "Thank you! Your feedback and rating have been recorded.");
        return "redirect:/feedback";
    }

    @PostMapping("/feedback/guest")
    public String submitGuestFeedback(@Valid @ModelAttribute("feedbackDto") FeedbackDto dto,
                                      BindingResult bindingResult,
                                      RedirectAttributes redirectAttributes) {
        if (bindingResult.hasErrors()) {
            redirectAttributes.addFlashAttribute("errorMessage", "Please provide a valid rating and comment.");
            return "redirect:/#contact";
        }

        feedbackService.submitGuestFeedback(dto);
        redirectAttributes.addFlashAttribute("successMessage", "Thank you for your valuable feedback!");
        return "redirect:/#contact";
    }
}
