package com.placenza.controller.api;

import com.placenza.dto.ApiResponseDto;
import com.placenza.dto.AssessmentDetailDto;
import com.placenza.dto.AssessmentResultDto;
import com.placenza.dto.AssessmentSubmissionDto;
import com.placenza.entity.Assessment;
import com.placenza.entity.User;
import com.placenza.security.SecurityUtil;
import com.placenza.service.AssessmentService;
import jakarta.validation.Valid;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/v1/assessments")
public class ApiAssessmentController {

    private final AssessmentService assessmentService;
    private final SecurityUtil securityUtil;

    public ApiAssessmentController(AssessmentService assessmentService, SecurityUtil securityUtil) {
        this.assessmentService = assessmentService;
        this.securityUtil = securityUtil;
    }

    @GetMapping
    public ResponseEntity<ApiResponseDto<List<Assessment>>> getAll() {
        return ResponseEntity.ok(ApiResponseDto.ok("Assessments retrieved", assessmentService.getAllAssessments()));
    }

    @GetMapping("/{id}")
    public ResponseEntity<ApiResponseDto<AssessmentDetailDto>> getForTaking(@PathVariable Long id) {
        return ResponseEntity.ok(ApiResponseDto.ok("Assessment question paper retrieved", assessmentService.getAssessmentForTaking(id)));
    }

    @PostMapping("/{id}/submit")
    public ResponseEntity<ApiResponseDto<AssessmentResultDto>> submit(@PathVariable Long id,
                                                                      @Valid @RequestBody AssessmentSubmissionDto submission) {
        User user = securityUtil.getCurrentAuthenticatedUser();
        submission.setAssessmentId(id);
        AssessmentResultDto result = assessmentService.submitAssessment(user, submission);
        return ResponseEntity.ok(ApiResponseDto.ok("Assessment evaluated successfully", result));
    }
}
