package com.placenza.controller.api;

import com.placenza.dto.ApiResponseDto;
import com.placenza.dto.DemoPaymentRequestDto;
import com.placenza.dto.TransactionResponseDto;
import com.placenza.entity.User;
import com.placenza.security.SecurityUtil;
import com.placenza.service.PaymentService;
import jakarta.validation.Valid;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/v1/payments")
public class ApiPaymentController {

    private final PaymentService paymentService;
    private final SecurityUtil securityUtil;

    public ApiPaymentController(PaymentService paymentService, SecurityUtil securityUtil) {
        this.paymentService = paymentService;
        this.securityUtil = securityUtil;
    }

    @GetMapping("/catalog")
    public ResponseEntity<ApiResponseDto<List<PaymentService.ServiceOffering>>> getCatalog() {
        return ResponseEntity.ok(ApiResponseDto.ok("Service catalog", paymentService.getServiceCatalog()));
    }

    @PostMapping("/demo-purchase")
    public ResponseEntity<ApiResponseDto<TransactionResponseDto>> makeDemoPurchase(@Valid @RequestBody DemoPaymentRequestDto request) {
        User user = securityUtil.getCurrentAuthenticatedUser();
        TransactionResponseDto result = paymentService.initiateDemoPurchase(user, request);
        return ResponseEntity.ok(ApiResponseDto.ok("Demo payment executed", result));
    }
}
