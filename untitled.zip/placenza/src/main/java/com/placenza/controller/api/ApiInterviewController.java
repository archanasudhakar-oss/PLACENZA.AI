package com.placenza.controller.api;

import com.placenza.dto.ApiResponseDto;
import com.placenza.entity.Difficulty;
import com.placenza.entity.InterviewPracticeRecord;
import com.placenza.entity.InterviewQuestion;
import com.placenza.entity.User;
import com.placenza.security.SecurityUtil;
import com.placenza.service.InterviewPracticeService;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/v1/interviews")
public class ApiInterviewController {

    private final InterviewPracticeService interviewService;
    private final SecurityUtil securityUtil;

    public ApiInterviewController(InterviewPracticeService interviewService, SecurityUtil securityUtil) {
        this.interviewService = interviewService;
        this.securityUtil = securityUtil;
    }

    @GetMapping
    public ResponseEntity<ApiResponseDto<List<InterviewQuestion>>> getQuestions(@RequestParam(required = false) Long categoryId,
                                                                                @RequestParam(required = false) Difficulty difficulty) {
        return ResponseEntity.ok(ApiResponseDto.ok("Questions retrieved", interviewService.getQuestions(categoryId, difficulty)));
    }

    @PostMapping("/{id}/practiced")
    public ResponseEntity<ApiResponseDto<InterviewPracticeRecord>> recordPractice(@PathVariable Long id,
                                                                                  @RequestParam(required = false) String notes,
                                                                                  @RequestParam(defaultValue = "5") Integer selfRating) {
        User user = securityUtil.getCurrentAuthenticatedUser();
        InterviewPracticeRecord record = interviewService.recordPractice(user, id, notes, selfRating);
        return ResponseEntity.ok(ApiResponseDto.ok("Question practice logged", record));
    }
}
