package com.placenza.controller;

import com.placenza.entity.Category;
import com.placenza.entity.Feedback;
import com.placenza.entity.User;
import com.placenza.repository.UserRepository;
import com.placenza.security.SecurityUtil;
import com.placenza.service.CategoryService;
import com.placenza.service.FeedbackService;
import org.springframework.data.domain.Page;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import java.util.List;

@Controller
@RequestMapping("/admin")
public class AdminController {

    private final UserRepository userRepository;
    private final CategoryService categoryService;
    private final FeedbackService feedbackService;
    private final SecurityUtil securityUtil;

    public AdminController(UserRepository userRepository,
                           CategoryService categoryService,
                           FeedbackService feedbackService,
                           SecurityUtil securityUtil) {
        this.userRepository = userRepository;
        this.categoryService = categoryService;
        this.feedbackService = feedbackService;
        this.securityUtil = securityUtil;
    }

    @GetMapping("/users")
    public String manageUsers(Model model) {
        User admin = securityUtil.getCurrentAuthenticatedUser();
        List<User> users = userRepository.findAll();
        model.addAttribute("users", users);
        model.addAttribute("admin", admin);
        return "admin/users";
    }

    @GetMapping("/categories")
    public String manageCategories(Model model) {
        User admin = securityUtil.getCurrentAuthenticatedUser();
        List<Category> categories = categoryService.getAllCategories();
        model.addAttribute("categories", categories);
        model.addAttribute("newCategory", new Category());
        model.addAttribute("admin", admin);
        return "admin/categories";
    }

    @PostMapping("/categories")
    public String createCategory(@ModelAttribute Category category, RedirectAttributes redirectAttributes) {
        categoryService.createCategory(category);
        redirectAttributes.addFlashAttribute("successMessage", "Category created successfully.");
        return "redirect:/admin/categories";
    }

    @PostMapping("/categories/{id}/update")
    public String updateCategory(@PathVariable Long id, @ModelAttribute Category category, RedirectAttributes redirectAttributes) {
        categoryService.updateCategory(id, category);
        redirectAttributes.addFlashAttribute("successMessage", "Category updated successfully.");
        return "redirect:/admin/categories";
    }

    @PostMapping("/categories/{id}/delete")
    public String deleteCategory(@PathVariable Long id, RedirectAttributes redirectAttributes) {
        try {
            categoryService.deleteCategory(id);
            redirectAttributes.addFlashAttribute("successMessage", "Category deleted successfully.");
        } catch (Exception ex) {
            redirectAttributes.addFlashAttribute("errorMessage", ex.getMessage());
        }
        return "redirect:/admin/categories";
    }

    @GetMapping("/feedback")
    public String reviewFeedback(@RequestParam(defaultValue = "0") int page,
                                 @RequestParam(defaultValue = "15") int size,
                                 Model model) {
        User admin = securityUtil.getCurrentAuthenticatedUser();
        Page<Feedback> feedbacks = feedbackService.getAllFeedbacks(page, size);

        model.addAttribute("feedbacks", feedbacks);
        model.addAttribute("summary", feedbackService.getFeedbackSummary());
        model.addAttribute("admin", admin);
        return "admin/feedback";
    }
}
