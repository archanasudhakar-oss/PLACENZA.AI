package com.placenza.controller;

import com.placenza.dto.OtpVerifyDto;
import com.placenza.dto.RegistrationDto;
import com.placenza.entity.User;
import com.placenza.exception.ValidationException;
import com.placenza.security.SecurityUtil;
import com.placenza.service.OtpService;
import com.placenza.service.UserService;
import jakarta.servlet.http.HttpSession;
import jakarta.validation.Valid;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

@Controller
public class AuthController {

    private final UserService userService;
    private final OtpService otpService;
    private final SecurityUtil securityUtil;

    public AuthController(UserService userService, OtpService otpService, SecurityUtil securityUtil) {
        this.userService = userService;
        this.otpService = otpService;
        this.securityUtil = securityUtil;
    }

    @GetMapping("/login")
    public String login(@RequestParam(value = "error", required = false) String error,
                        @RequestParam(value = "logout", required = false) String logout,
                        @RequestParam(value = "registered", required = false) String registered,
                        Model model) {
        if (securityUtil.getCurrentUserOptional().isPresent()) {
            return "redirect:/dashboard";
        }
        if (error != null) {
            model.addAttribute("errorMessage", "Invalid email or password. Please try again.");
        }
        if (logout != null) {
            model.addAttribute("successMessage", "You have been logged out securely.");
        }
        if (registered != null) {
            model.addAttribute("successMessage", "Account created successfully! Please sign in with your credentials.");
        }
        return "auth/login";
    }

    @GetMapping("/register")
    public String showRegistrationForm(Model model) {
        if (securityUtil.getCurrentUserOptional().isPresent()) {
            return "redirect:/dashboard";
        }
        model.addAttribute("registrationDto", new RegistrationDto());
        return "auth/register";
    }

    @PostMapping("/register")
    public String processRegistration(@Valid @ModelAttribute("registrationDto") RegistrationDto registrationDto,
                                      BindingResult bindingResult,
                                      Model model,
                                      RedirectAttributes redirectAttributes) {
        if (bindingResult.hasErrors()) {
            return "auth/register";
        }

        try {
            userService.register(registrationDto);
            redirectAttributes.addFlashAttribute("successMessage", "Registration completed successfully! You can now log in.");
            return "redirect:/login?registered=true";
        } catch (ValidationException ex) {
            model.addAttribute("errorMessage", ex.getMessage());
            return "auth/register";
        } catch (Exception ex) {
            model.addAttribute("errorMessage", "An error occurred while creating your account. Please try again.");
            return "auth/register";
        }
    }

    @GetMapping("/verify-otp")
    public String showOtpForm(Model model, HttpSession session) {
        String pendingEmail = (String) session.getAttribute("PENDING_2FA_EMAIL");
        if (pendingEmail == null) {
            return "redirect:/login";
        }
        model.addAttribute("otpVerifyDto", new OtpVerifyDto());
        model.addAttribute("email", pendingEmail);
        return "auth/verify-otp";
    }

    @PostMapping("/verify-otp")
    public String processOtp(@Valid @ModelAttribute("otpVerifyDto") OtpVerifyDto otpDto,
                             BindingResult bindingResult,
                             HttpSession session,
                             Model model,
                             RedirectAttributes redirectAttributes) {
        if (bindingResult.hasErrors()) {
            return "auth/verify-otp";
        }

        String pendingEmail = (String) session.getAttribute("PENDING_2FA_EMAIL");
        if (pendingEmail == null) {
            return "redirect:/login";
        }

        User user = userService.findByEmail(pendingEmail);
        boolean verified = otpService.verifyOtp(user, otpDto.getCode());

        if (verified) {
            session.removeAttribute("PENDING_2FA_EMAIL");
            session.setAttribute("2FA_VERIFIED", true);
            redirectAttributes.addFlashAttribute("successMessage", "Two-step verification completed.");
            return "redirect:/dashboard";
        } else {
            model.addAttribute("errorMessage", "Invalid or expired verification code. Please check server logs or retry.");
            model.addAttribute("email", pendingEmail);
            return "auth/verify-otp";
        }
    }
}
