package com.placenza.controller;

import com.placenza.entity.Category;
import com.placenza.security.SecurityUtil;
import com.placenza.service.CategoryService;
import com.placenza.service.PaymentService;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;

import java.util.List;

@Controller
public class HomeController {

    private final CategoryService categoryService;
    private final PaymentService paymentService;
    private final SecurityUtil securityUtil;

    public HomeController(CategoryService categoryService, PaymentService paymentService, SecurityUtil securityUtil) {
        this.categoryService = categoryService;
        this.paymentService = paymentService;
        this.securityUtil = securityUtil;
    }

    @GetMapping("/")
    public String index(Model model) {
        model.addAttribute("categories", categoryService.getAllCategories());
        model.addAttribute("currentUser", securityUtil.getCurrentUserOptional().orElse(null));
        return "index";
    }

    @GetMapping("/about")
    public String about(Model model) {
        model.addAttribute("currentUser", securityUtil.getCurrentUserOptional().orElse(null));
        return "about";
    }

    @GetMapping("/features")
    public String features(Model model) {
        model.addAttribute("categories", categoryService.getAllCategories());
        model.addAttribute("currentUser", securityUtil.getCurrentUserOptional().orElse(null));
        return "features";
    }

    @GetMapping("/categories")
    public String categories(Model model) {
        model.addAttribute("categories", categoryService.getAllCategories());
        model.addAttribute("currentUser", securityUtil.getCurrentUserOptional().orElse(null));
        return "categories";
    }

    @GetMapping("/categories/{slug}")
    public String categoryDetail(@PathVariable String slug, Model model) {
        Category category = categoryService.getCategoryBySlug(slug);
        model.addAttribute("category", category);
        model.addAttribute("currentUser", securityUtil.getCurrentUserOptional().orElse(null));
        return "category-detail";
    }

    @GetMapping("/pricing")
    public String pricing(Model model) {
        model.addAttribute("catalog", paymentService.getServiceCatalog());
        model.addAttribute("currentUser", securityUtil.getCurrentUserOptional().orElse(null));
        return "payment/catalog";
    }

    @GetMapping("/faq")
    public String faq(Model model) {
        model.addAttribute("currentUser", securityUtil.getCurrentUserOptional().orElse(null));
        return "faq";
    }
}
