package com.placenza.controller;

import com.placenza.dto.RoadmapTaskDto;
import com.placenza.entity.Roadmap;
import com.placenza.entity.User;
import com.placenza.security.SecurityUtil;
import com.placenza.service.RoadmapService;
import com.placenza.service.UserService;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import java.util.List;

@Controller
@RequestMapping("/roadmap")
public class RoadmapController {

    private final RoadmapService roadmapService;
    private final UserService userService;
    private final SecurityUtil securityUtil;

    public RoadmapController(RoadmapService roadmapService, UserService userService, SecurityUtil securityUtil) {
        this.roadmapService = roadmapService;
        this.userService = userService;
        this.securityUtil = securityUtil;
    }

    @GetMapping
    public String viewRoadmap(Model model) {
        User user = securityUtil.getCurrentAuthenticatedUser();
        var profile = userService.getUserProfileDto(user.getId());
        Roadmap roadmap = roadmapService.getOrCreateRoadmap(user, profile.getCareerRole());
        List<RoadmapTaskDto> tasks = roadmapService.getTasksForUser(user.getId());

        model.addAttribute("roadmap", roadmap);
        model.addAttribute("tasks", tasks);
        model.addAttribute("user", user);
        return "roadmap/view";
    }

    @PostMapping("/tasks/{id}/toggle")
    public String toggleTask(@PathVariable Long id, RedirectAttributes redirectAttributes) {
        User user = securityUtil.getCurrentAuthenticatedUser();
        roadmapService.toggleTaskCompletion(id, user.getId());
        redirectAttributes.addFlashAttribute("successMessage", "Task status updated successfully.");
        return "redirect:/roadmap";
    }

    @PostMapping("/regenerate")
    public String regenerateRoadmap(RedirectAttributes redirectAttributes) {
        User user = securityUtil.getCurrentAuthenticatedUser();
        var profile = userService.getUserProfileDto(user.getId());
        roadmapService.generateRoadmapForUser(user, profile.getCareerRole());
        redirectAttributes.addFlashAttribute("successMessage", "Roadmap refreshed with latest skill gap priorities.");
        return "redirect:/roadmap";
    }
}
