package com.placenza.controller;

import com.placenza.dto.DemoPaymentRequestDto;
import com.placenza.dto.TransactionResponseDto;
import com.placenza.entity.PaymentTransaction;
import com.placenza.entity.Purchase;
import com.placenza.entity.User;
import com.placenza.security.SecurityUtil;
import com.placenza.service.PaymentService;
import jakarta.validation.Valid;
import org.springframework.data.domain.Page;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import java.util.List;

@Controller
@RequestMapping("/payments")
public class PaymentController {

    private final PaymentService paymentService;
    private final SecurityUtil securityUtil;

    public PaymentController(PaymentService paymentService, SecurityUtil securityUtil) {
        this.paymentService = paymentService;
        this.securityUtil = securityUtil;
    }

    @GetMapping("/catalog")
    public String showCatalog(Model model) {
        User user = securityUtil.getCurrentAuthenticatedUser();
        model.addAttribute("catalog", paymentService.getServiceCatalog());
        model.addAttribute("user", user);
        return "payment/catalog";
    }

    @PostMapping("/create-demo")
    public String createDemoTransaction(@Valid @ModelAttribute DemoPaymentRequestDto request,
                                        RedirectAttributes redirectAttributes) {
        User user = securityUtil.getCurrentAuthenticatedUser();
        TransactionResponseDto result = paymentService.initiateDemoPurchase(user, request);

        redirectAttributes.addFlashAttribute("successMessage",
                "Demo transaction successful! Reference: " + result.getTransactionReference() + " [SIMULATED]");
        return "redirect:/payments/history";
    }

    @GetMapping("/history")
    public String showPurchaseHistory(Model model) {
        User user = securityUtil.getCurrentAuthenticatedUser();
        List<Purchase> purchases = paymentService.getUserPurchases(user.getId());

        model.addAttribute("purchases", purchases);
        model.addAttribute("user", user);
        return "payment/history";
    }

    @GetMapping("/admin/transactions")
    public String adminTransactions(@RequestParam(defaultValue = "0") int page,
                                    @RequestParam(defaultValue = "15") int size,
                                    Model model) {
        securityUtil.verifyUserOwnership(-1L); // Admin check
        Page<PaymentTransaction> transactions = paymentService.getAllTransactions(page, size);

        model.addAttribute("transactions", transactions);
        model.addAttribute("user", securityUtil.getCurrentAuthenticatedUser());
        return "payment/admin-transactions";
    }
}
