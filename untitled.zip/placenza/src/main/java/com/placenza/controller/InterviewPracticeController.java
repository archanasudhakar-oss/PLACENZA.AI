package com.placenza.controller;

import com.placenza.entity.Difficulty;
import com.placenza.entity.InterviewPracticeRecord;
import com.placenza.entity.InterviewQuestion;
import com.placenza.entity.User;
import com.placenza.security.SecurityUtil;
import com.placenza.service.CategoryService;
import com.placenza.service.InterviewPracticeService;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import java.util.List;

@Controller
@RequestMapping("/interviews")
public class InterviewPracticeController {

    private final InterviewPracticeService interviewService;
    private final CategoryService categoryService;
    private final SecurityUtil securityUtil;

    public InterviewPracticeController(InterviewPracticeService interviewService,
                                       CategoryService categoryService,
                                       SecurityUtil securityUtil) {
        this.interviewService = interviewService;
        this.categoryService = categoryService;
        this.securityUtil = securityUtil;
    }

    @GetMapping("/practice")
    public String practice(@RequestParam(required = false) Long category,
                           @RequestParam(required = false) Difficulty difficulty,
                           Model model) {
        User user = securityUtil.getCurrentAuthenticatedUser();
        List<InterviewQuestion> questions = interviewService.getQuestions(category, difficulty);
        List<InterviewPracticeRecord> history = interviewService.getUserPracticeHistory(user.getId());

        model.addAttribute("questions", questions);
        model.addAttribute("categories", categoryService.getAllCategories());
        model.addAttribute("selectedCategory", category);
        model.addAttribute("selectedDifficulty", difficulty);
        model.addAttribute("history", history);
        model.addAttribute("user", user);

        return "interview/practice";
    }

    @PostMapping("/{id}/practiced")
    public String markPracticed(@PathVariable Long id,
                                @RequestParam(required = false) String notes,
                                @RequestParam(defaultValue = "5") Integer selfRating,
                                RedirectAttributes redirectAttributes) {
        User user = securityUtil.getCurrentAuthenticatedUser();
        interviewService.recordPractice(user, id, notes, selfRating);
        redirectAttributes.addFlashAttribute("successMessage", "Question marked as practised! Placement readiness score updated.");
        return "redirect:/interviews/practice";
    }

    @GetMapping("/history")
    public String history(Model model) {
        User user = securityUtil.getCurrentAuthenticatedUser();
        List<InterviewPracticeRecord> history = interviewService.getUserPracticeHistory(user.getId());
        model.addAttribute("history", history);
        model.addAttribute("user", user);
        return "interview/history";
    }
}
