package com.placenza.service;

import com.placenza.entity.*;
import com.placenza.repository.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.CommandLineRunner;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Service
public class DataInitializerService implements CommandLineRunner {

    private static final Logger log = LoggerFactory.getLogger(DataInitializerService.class);

    private final UserRepository userRepository;
    private final UserProfileRepository profileRepository;
    private final CategoryRepository categoryRepository;
    private final SkillRepository skillRepository;
    private final AssessmentRepository assessmentRepository;
    private final QuestionRepository questionRepository;
    private final InterviewQuestionRepository interviewRepository;
    private final PasswordEncoder passwordEncoder;

    @Value("${placenza.admin.bootstrap.enabled:true}")
    private boolean adminBootstrapEnabled;

    @Value("${placenza.admin.bootstrap.email:admin@placenza.ai}")
    private String adminEmail;

    @Value("${placenza.admin.bootstrap.password:Admin@Placenza2026!}")
    private String adminPassword;

    @Value("${placenza.admin.bootstrap.name:Placenza System Admin}")
    private String adminName;

    public DataInitializerService(UserRepository userRepository,
                                  UserProfileRepository profileRepository,
                                  CategoryRepository categoryRepository,
                                  SkillRepository skillRepository,
                                  AssessmentRepository assessmentRepository,
                                  QuestionRepository questionRepository,
                                  InterviewQuestionRepository interviewRepository,
                                  PasswordEncoder passwordEncoder) {
        this.userRepository = userRepository;
        this.profileRepository = profileRepository;
        this.categoryRepository = categoryRepository;
        this.skillRepository = skillRepository;
        this.assessmentRepository = assessmentRepository;
        this.questionRepository = questionRepository;
        this.interviewRepository = interviewRepository;
        this.passwordEncoder = passwordEncoder;
    }

    @Override
    @Transactional
    public void run(String... args) {
        bootstrapAdminUser();
        bootstrapCategories();
        bootstrapInterviewQuestions();
    }

    private void bootstrapAdminUser() {
        if (!adminBootstrapEnabled) {
            return;
        }

        if (userRepository.findByEmail(adminEmail).isEmpty()) {
            User admin = new User();
            admin.setEmail(adminEmail);
            admin.setFullName(adminName);
            admin.setPasswordHash(passwordEncoder.encode(adminPassword));
            admin.setRole(Role.ROLE_ADMIN);
            admin.setEnabled(true);
            admin.setTwoFactorEnabled(false); // Admin direct access for dev bootstrap
            User saved = userRepository.save(admin);

            UserProfile profile = new UserProfile(saved);
            profile.setCollege("Placenza Platform HQ");
            profile.setDegree("System Administration");
            profile.setGraduationYear(2026);
            profile.setCareerRole("Platform Administrator");
            profile.setReadinessScore(100.0);
            profile.setProvisional(false);
            profileRepository.save(profile);

            log.info("Bootstrapped Administrator account: {}", adminEmail);
        }
    }

    private void bootstrapCategories() {
        if (categoryRepository.count() > 0) {
            return;
        }

        List<Category> defaultCategories = List.of(
                new Category("Java Programming", "java-programming", "Core Java, OOPs, Collections, Concurrency, JVM internals, Streams API, and Exception Handling.", "bi-cup-hot", 1),
                new Category("Python Programming", "python-programming", "Python syntax, data structures, generators, decorators, OOP, and built-in modules.", "bi-code-slash", 2),
                new Category("SQL", "sql", "Structured Query Language, complex joins, subqueries, indexing, window functions, and DDL/DML.", "bi-database", 3),
                new Category("DBMS", "dbms", "Database Management Systems, ACID properties, normalization, indexing, transactions, and ER diagrams.", "bi-hdd-network", 4),
                new Category("Data Structures and Algorithms", "dsa", "Arrays, Linked Lists, Stacks, Queues, Trees, Graphs, Sorting, Dynamic Programming, and Big-O analysis.", "bi-diagram-3", 5),
                new Category("Computer Networks", "computer-networks", "OSI model, TCP/IP, DNS, HTTP/HTTPS, routing protocols, subnetting, sockets, and network security.", "bi-globe", 6),
                new Category("Operating Systems", "operating-systems", "Process management, threads, CPU scheduling, deadlocks, virtual memory, paging, and system calls.", "bi-cpu", 7),
                new Category("Aptitude", "aptitude", "Quantitative aptitude, logical reasoning, data interpretation, permutations, and time-and-work problems.", "bi-calculator", 8),
                new Category("Communication Skills", "communication-skills", "Verbal ability, reading comprehension, professional email etiquette, and presentation skills.", "bi-chat-dots", 9),
                new Category("HR Interviews", "hr-interviews", "Behavioral interview questions, STAR methodology, situational judgment, cultural fit, and negotiation.", "bi-people", 10),
                new Category("Technical Interviews", "technical-interviews", "System design basics, architectural tradeoffs, coding problem walk-throughs, and debugging.", "bi-terminal", 11),
                new Category("Resume Preparation", "resume-preparation", "Action-oriented bullet points, ATS optimization, project impact framing, and tech stack clarity.", "bi-file-earmark-person", 12)
        );

        categoryRepository.saveAll(defaultCategories);
        log.info("Initialized 12 standard Placenza skill categories.");
    }

    private void bootstrapInterviewQuestions() {
        if (interviewRepository.count() > 0) {
            return;
        }

        Category javaCat = categoryRepository.findBySlug("java-programming").orElse(null);
        Category sqlCat = categoryRepository.findBySlug("sql").orElse(null);
        Category osCat = categoryRepository.findBySlug("operating-systems").orElse(null);
        Category hrCat = categoryRepository.findBySlug("hr-interviews").orElse(null);

        if (javaCat != null) {
            interviewRepository.save(new InterviewQuestion(
                    "How does the Garbage Collector work in Java, and what are Generational Hypotheses?",
                    "Java GC divides the heap into Young Generation (Eden, S0, S1) and Old Generation. Young objects die quickly; surviving objects get promoted to Tenured generation after multiple GC passes.",
                    "Highlight G1GC, ZGC and weak generational hypothesis.",
                    javaCat, Difficulty.INTERMEDIATE
            ));
            interviewRepository.save(new InterviewQuestion(
                    "Explain HashMap internal working and how collisions are resolved in Java 8+.",
                    "HashMap uses an array of Node buckets. Java 8 converts linked list buckets into balanced red-black trees when length exceeds 8 (TREEIFY_THRESHOLD), reducing search from O(N) to O(log N).",
                    "Mention hashCode(), equals(), and load factor 0.75.",
                    javaCat, Difficulty.ADVANCED
            ));
        }

        if (sqlCat != null) {
            interviewRepository.save(new InterviewQuestion(
                    "What are ACID properties in Relational Database Management Systems?",
                    "Atomicity guarantees all operations in a transaction succeed or all rollback. Consistency ensures integrity constraints are preserved. Isolation separates concurrent transactions. Durability ensures committed data is saved permanently.",
                    "Discuss write-ahead logging (WAL) and crash recovery.",
                    sqlCat, Difficulty.BEGINNER
            ));
        }

        if (osCat != null) {
            interviewRepository.save(new InterviewQuestion(
                    "What is Deadlock and how can it be prevented?",
                    "Deadlock happens when processes cannot proceed because each holds a resource and waits for another. Prevention requires breaking at least one Coffman condition: Mutual Exclusion, Hold and Wait, No Preemption, Circular Wait.",
                    "Explain Banker's algorithm and resource ordering.",
                    osCat, Difficulty.INTERMEDIATE
            ));
        }

        if (hrCat != null) {
            interviewRepository.save(new InterviewQuestion(
                    "Tell me about a time you resolved a major disagreement within your project team (STAR).",
                    "Situation: During our capstone, two members disagreed on SQL vs NoSQL. Task: As lead backend dev, I needed to keep the schedule intact. Action: Structured an evaluation matrix testing ACID requirements. Result: We agreed on MySQL, delivered the module 4 days early with zero data inconsistencies.",
                    "Focus on objective decision making, empathy, and positive team dynamics.",
                    hrCat, Difficulty.BEGINNER
            ));
        }
    }
}
