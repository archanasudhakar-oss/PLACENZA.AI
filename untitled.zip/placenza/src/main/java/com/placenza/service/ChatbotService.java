package com.placenza.service;

import com.placenza.dto.ChatResponseDto;
import org.springframework.stereotype.Service;

import java.util.*;

@Service
public class ChatbotService {

    private record KnowledgeEntry(List<String> keywords, String topic, String response, List<String> suggestions) {}

    private final List<KnowledgeEntry> knowledgeBase = new ArrayList<>();

    public ChatbotService() {
        initKnowledgeBase();
    }

    private void initKnowledgeBase() {
        // 1. Java & OOP
        knowledgeBase.add(new KnowledgeEntry(
                List.of("java", "jvm", "jdk", "jre", "garbage collection", "string pool"),
                "Java Fundamentals",
                "Java is a statically-typed, object-oriented, platform-independent language running on the JVM. Key JVM areas include the Young Generation (Eden, S0, S1), Old Generation, and Metaspace. Strings in Java are immutable and interned in the String Constant Pool to optimize memory footprint.",
                List.of("Explain OOP concepts in Java", "Difference between HashMap and ConcurrentHashMap", "How does Garbage Collection work?")
        ));

        knowledgeBase.add(new KnowledgeEntry(
                List.of("oop", "oops", "polymorphism", "inheritance", "encapsulation", "abstraction"),
                "Object-Oriented Programming",
                "The 4 foundational pillars of OOP in Java are:\n" +
                "1. Encapsulation: Binding data and methods into a class and protecting internal state via private fields and public accessors.\n" +
                "2. Abstraction: Hiding internal implementation complexities using interfaces and abstract classes.\n" +
                "3. Inheritance: Reusing code where a child class acquires fields and methods of a parent class (using 'extends').\n" +
                "4. Polymorphism: Compile-time (Method Overloading) and Runtime (Method Overriding using dynamic method dispatch).",
                List.of("How to handle exceptions in Java?", "What is an abstract class vs interface?", "Explain method overriding")
        ));

        // 2. Collections & Concurrency
        knowledgeBase.add(new KnowledgeEntry(
                List.of("hashmap", "concurrenthashmap", "collections", "arraylist", "linkedlist", "set"),
                "Java Collections",
                "Java Collections Framework hierarchy:\n" +
                "- List: Ordered collection allowing duplicates (ArrayList for O(1) random access, LinkedList for frequent insertions).\n" +
                "- Set: Unordered collection with unique elements (HashSet using hash table, TreeSet for sorted order).\n" +
                "- Map: Key-value pairs (HashMap non-synchronized with 16 capacity and 0.75 load factor; ConcurrentHashMap uses bucket locks for high-throughput thread safety).",
                List.of("Difference between fail-fast and fail-safe iterators", "Explain Hash collision resolution", "When to use TreeMap?")
        ));

        // 3. SQL & DBMS
        knowledgeBase.add(new KnowledgeEntry(
                List.of("sql", "query", "join", "group by", "having", "subquery", "index"),
                "SQL Queries",
                "SQL (Structured Query Language) operates on relational tables. Important rules:\n" +
                "- INNER JOIN: Returns records with matching keys in both tables.\n" +
                "- LEFT JOIN: Returns all records from the left table and matched rows from the right table (NULL when unmatched).\n" +
                "- WHERE filters rows before aggregation; HAVING filters groups after GROUP BY.\n" +
                "- Indexes use B+ Trees to accelerate SELECT lookups at the expense of slight INSERT/UPDATE overhead.",
                List.of("Explain database normalization 1NF to 3NF", "What are ACID properties?", "How does B+ Tree indexing work?")
        ));

        knowledgeBase.add(new KnowledgeEntry(
                List.of("dbms", "acid", "normalization", "1nf", "2nf", "3nf", "transaction", "deadlock"),
                "Database Management Systems",
                "DBMS core principles:\n" +
                "- ACID Properties: Atomicity (all or nothing), Consistency (preserves integrity rules), Isolation (concurrency levels), Durability (committed data survives crashes).\n" +
                "- Normalization: 1NF (atomic columns), 2NF (1NF + no partial dependency on composite key), 3NF (2NF + no transitive dependencies).\n" +
                "- Transaction Isolation levels: Read Uncommitted, Read Committed, Repeatable Read, Serializable.",
                List.of("What is an ER Diagram?", "Explain Primary vs Foreign Key", "How does write-ahead logging work?")
        ));

        // 4. Data Structures & Algorithms
        knowledgeBase.add(new KnowledgeEntry(
                List.of("dsa", "data structures", "algorithm", "big o", "complexity", "time complexity"),
                "DSA Fundamentals",
                "Big-O measures asymptotic growth:\n" +
                "- O(1): Constant time (Hash map lookup, array index lookup).\n" +
                "- O(log N): Logarithmic time (Binary Search, balanced BST operations).\n" +
                "- O(N): Linear scan (Linear search, single traversal).\n" +
                "- O(N log N): Optimal comparison sorting (MergeSort, HeapSort, QuickSort average).\n" +
                "- O(N^2): Quadratic time (Bubble, Selection, Insertion sorts).",
                List.of("How to prepare DSA for product companies?", "Explain Two-Pointer technique", "Difference between BFS and DFS")
        ));

        knowledgeBase.add(new KnowledgeEntry(
                List.of("tree", "graph", "bfs", "dfs", "binary search tree", "dynamic programming", "dp"),
                "Advanced DSA",
                "Common interview problem patterns:\n" +
                "- BFS: Shortest path in unweighted graphs using FIFO Queue.\n" +
                "- DFS: Exhaustive search, topological sorting, and cycle detection using Recursion or LIFO Stack.\n" +
                "- BST: Left child < Root < Right child; Inorder traversal yields sorted elements.\n" +
                "- Dynamic Programming: Identify overlapping subproblems and optimal substructure; choose Memoization (Top-Down) or Tabulation (Bottom-Up).",
                List.of("How to detect cycles in a graph?", "What is Dijkstra algorithm?", "How to approach 0/1 Knapsack?")
        ));

        // 5. Aptitude & Reasoning
        knowledgeBase.add(new KnowledgeEntry(
                List.of("aptitude", "quantitative", "reasoning", "percentage", "profit", "loss", "work", "time"),
                "Aptitude Preparation",
                "High-frequency placement aptitude topics:\n" +
                "1. Time & Work: Total work = Efficiency x Time. If A takes x days and B takes y days, together they take (x*y)/(x+y) days.\n" +
                "2. Speed, Time & Distance: Speed = Distance / Time; km/h to m/s = multiply by 5/18.\n" +
                "3. Percentages & Profit/Loss: Profit % = (Profit / Cost Price) x 100.\n" +
                "4. Syllogisms & Venn Diagrams: Always test validity across all possible diagram interpretations.",
                List.of("Tips for solving time-speed-distance", "How to calculate permutations and combinations?", "Take Aptitude Assessment")
        ));

        // 6. Resume & HR Interviews
        knowledgeBase.add(new KnowledgeEntry(
                List.of("resume", "cv", "ats", "projects", "bullet points"),
                "Resume Preparation",
                "ATS-Friendly Resume Guidelines:\n" +
                "- Use the Google 'X-Y-Z' formula: Accomplished [X], as measured by [Y], by doing [Z].\n" +
                "- Include specific technologies (e.g., 'Spring Boot 3, Java 21, MySQL, Hibernate, Thymeleaf').\n" +
                "- Keep to 1 page for freshers; clean single-column format with standard headings (Education, Skills, Experience, Projects).\n" +
                "- Avoid tables, multi-column text boxes, and graphics that disrupt automated ATS parsing.",
                List.of("How to prepare for HR interview?", "Sample STAR story example", "How to showcase final year project?")
        ));

        knowledgeBase.add(new KnowledgeEntry(
                List.of("hr", "interview", "behavioral", "star", "strengths", "weakness", "tell me about yourself"),
                "HR Behavioral Interviews",
                "The STAR Method for Behavioral Questions:\n" +
                "- Situation: Set the context (company, academic semester, or team project).\n" +
                "- Task: What challenge or objective were you responsible for?\n" +
                "- Action: The specific steps YOU took (e.g., 'I researched query profiling and indexed foreign keys').\n" +
                "- Result: The quantifiable outcome (e.g., 'Reduced response latency by 65% and delivered 2 days early').",
                List.of("How to answer 'Why should we hire you?'", "Common HR questions for freshers", "How to negotiate salary?")
        ));

        // 7. Platform Navigation & Readiness Score
        knowledgeBase.add(new KnowledgeEntry(
                List.of("readiness", "score", "placement score", "provisional", "weights", "how is score calculated"),
                "Placement Readiness Score",
                "Placenza AI calculates your placement readiness transparently using weighted metrics:\n" +
                "- Technical Assessments: 40%\n" +
                "- Aptitude Assessments: 20%\n" +
                "- Interview Question Practice: 20%\n" +
                "- Learning Roadmap Completion: 10%\n" +
                "- Profile & Career Details: 10%\n\n" +
                "Note: A 'Provisional' tag indicates that required assessment categories (Technical or Aptitude) have not yet been attempted.",
                List.of("How to improve my readiness score?", "Where to take assessments?", "View my personalized roadmap")
        ));

        knowledgeBase.add(new KnowledgeEntry(
                List.of("roadmap", "tasks", "curriculum", "learning plan", "regenerate"),
                "Personalized Roadmap",
                "Your learning roadmap is dynamically generated from your target career role (e.g., Java Full-Stack Developer) and your identified skill gaps from diagnostic assessments.\n" +
                "You can check off completed tasks on your Roadmap page to track progress and boost your readiness score.",
                List.of("Go to My Roadmap", "How to analyze skill gaps?", "What roles are supported?")
        ));

        knowledgeBase.add(new KnowledgeEntry(
                List.of("help", "features", "navigation", "start", "placenza"),
                "Placenza Platform Navigation",
                "Welcome to PLACENZA AI! Key sections to explore:\n" +
                "1. Student Dashboard: Overview of your placement readiness score, profile completion, and recent attempts.\n" +
                "2. Skill Assessments: Diagnostic MCQs across Java, SQL, DSA, and Aptitude.\n" +
                "3. Personalized Roadmap: Step-by-step preparation milestones.\n" +
                "4. Interview Practice: Curated technical and HR questions with reference answers.\n" +
                "5. Feedback & Ratings: Share your feedback to improve the platform.",
                List.of("How is readiness score calculated?", "Start an assessment", "Practice interview questions")
        ));
    }

    public ChatResponseDto processMessage(String userInput) {
        if (userInput == null || userInput.trim().isEmpty()) {
            return new ChatResponseDto(
                    "Please type a question or choose one of the suggested topics below.",
                    "General",
                    List.of("Tell me about Java OOP", "How is the readiness score calculated?", "What is the STAR method?")
            );
        }

        String inputLower = userInput.toLowerCase().trim();

        // Match against knowledge base entries
        KnowledgeEntry bestMatch = null;
        int maxKeywordHits = 0;

        for (KnowledgeEntry entry : knowledgeBase) {
            int hits = 0;
            for (String kw : entry.keywords) {
                if (inputLower.contains(kw)) {
                    hits++;
                }
            }
            if (hits > maxKeywordHits) {
                maxKeywordHits = hits;
                bestMatch = entry;
            }
        }

        if (bestMatch != null && maxKeywordHits > 0) {
            return new ChatResponseDto(bestMatch.response, bestMatch.topic, bestMatch.suggestions);
        }

        // Helpful fallback response for unsupported questions
        return new ChatResponseDto(
                "I don't have a specific rule-based article for that exact phrase yet. I can assist with Java, OOP, SQL, DBMS, DSA, Aptitude, HR interviews, Resume optimization, and Platform navigation.\n\n" +
                "Try selecting one of the suggested placement topics below:",
                "Fallback Assistance",
                List.of(
                        "Explain OOP concepts in Java",
                        "Difference between INNER and LEFT JOIN",
                        "How is my readiness score calculated?",
                        "STAR method for HR interviews",
                        "ATS friendly resume tips"
                )
        );
    }
}
