package com.placenza.service;

import com.placenza.dto.SkillGapDto;
import com.placenza.entity.*;
import com.placenza.repository.AssessmentAttemptRepository;
import com.placenza.repository.CategoryRepository;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.*;

@Service
public class SkillGapAnalysisService {

    private final CategoryRepository categoryRepository;
    private final AssessmentAttemptRepository attemptRepository;

    public SkillGapAnalysisService(CategoryRepository categoryRepository,
                                   AssessmentAttemptRepository attemptRepository) {
        this.categoryRepository = categoryRepository;
        this.attemptRepository = attemptRepository;
    }

    @Transactional(readOnly = true)
    public List<SkillGapDto> analyzeUserSkillGaps(Long userId) {
        List<Category> allCategories = categoryRepository.findAllByOrderByDisplayOrderAsc();
        List<AssessmentAttempt> attempts = attemptRepository.findByUserIdOrderByCompletedAtDesc(userId);

        Map<Long, List<Double>> scoresByCategory = new HashMap<>();
        for (AssessmentAttempt attempt : attempts) {
            Long catId = attempt.getAssessment().getCategory().getId();
            scoresByCategory.computeIfAbsent(catId, k -> new ArrayList<>()).add(attempt.getScorePercentage());
        }

        List<SkillGapDto> gaps = new ArrayList<>();

        for (Category cat : allCategories) {
            List<Double> scores = scoresByCategory.get(cat.getId());

            if (scores == null || scores.isEmpty()) {
                gaps.add(new SkillGapDto(
                        cat.getName() + " Competency",
                        cat.getName(),
                        "Not Assessed",
                        null,
                        "Take the " + cat.getName() + " diagnostic assessment to evaluate your current baseline.",
                        "bg-secondary"
                ));
            } else {
                double avg = scores.stream().mapToDouble(Double::doubleValue).average().orElse(0.0);
                avg = Math.round(avg * 10.0) / 10.0;

                String status;
                String badge;
                String rec;

                if (avg >= 75.0) {
                    status = "Strong";
                    badge = "bg-success";
                    rec = "Excellent mastery! Ready for live mock technical interviews and architecture walkthroughs.";
                } else if (avg >= 50.0) {
                    status = "Developing";
                    badge = "bg-warning text-dark";
                    rec = generateCategoryRecommendation(cat.getSlug(), false);
                } else {
                    status = "Needs Improvement";
                    badge = "bg-danger";
                    rec = generateCategoryRecommendation(cat.getSlug(), true);
                }

                gaps.add(new SkillGapDto(
                        cat.getName() + " Competency",
                        cat.getName(),
                        status,
                        avg,
                        rec,
                        badge
                ));
            }
        }

        return gaps;
    }

    private String generateCategoryRecommendation(String categorySlug, boolean isCritical) {
        switch (categorySlug) {
            case "java-programming":
                return isCritical
                        ? "Priority Gap: Focus on Core OOP (Inheritance, Polymorphism), Java Collections (HashMap vs ConcurrentHashMap), and Exception handling mechanics."
                        : "Focus on Java 8+ Streams API, Concurrency (CompletableFuture), and JVM memory layout (Heap vs Metaspace).";
            case "sql":
            case "dbms":
                return isCritical
                        ? "Priority Gap: Revise 1NF/2NF/3NF Normalization, Multi-table JOIN mechanics (INNER/LEFT), and ACID transaction guarantees."
                        : "Practice B+ Tree index optimization, query execution plan reading (EXPLAIN), and window functions.";
            case "dsa":
                return isCritical
                        ? "Priority Gap: Master Two-Pointer techniques, Binary Search on sorted ranges, and Stack/Queue recursion patterns."
                        : "Focus on Tree traversals (BFS/DFS), Dynamic Programming memoization, and Graph shortest-path algorithms.";
            case "aptitude":
                return isCritical
                        ? "Priority Gap: Practice speed drills in Percentages, Profit & Loss, Work-Rate, and Syllogisms."
                        : "Work on Data Interpretation sets and advanced Probability/Permutation problems.";
            case "operating-systems":
                return "Review CPU scheduling algorithms, Deadlock prevention (Coffman conditions), and Paging vs Segmentation.";
            case "computer-networks":
                return "Study TCP 3-way handshakes, DNS resolution stages, HTTP status codes, and TLS handshake flows.";
            default:
                return "Review curated questions and practice solving interactive mock challenges in this category.";
        }
    }
}
