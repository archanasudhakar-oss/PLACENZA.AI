package com.placenza.service;

import com.placenza.dto.RoadmapTaskDto;
import com.placenza.dto.SkillGapDto;
import com.placenza.entity.*;
import com.placenza.exception.ResourceNotFoundException;
import com.placenza.exception.UnauthorizedAccessException;
import com.placenza.repository.RoadmapRepository;
import com.placenza.repository.RoadmapTaskRepository;
import org.springframework.context.annotation.Lazy;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.*;
import java.util.stream.Collectors;

@Service
public class RoadmapService {

    private final RoadmapRepository roadmapRepository;
    private final RoadmapTaskRepository taskRepository;
    private final SkillGapAnalysisService gapAnalysisService;
    private final ReadinessScoreService readinessScoreService;

    public RoadmapService(RoadmapRepository roadmapRepository,
                          RoadmapTaskRepository taskRepository,
                          @Lazy SkillGapAnalysisService gapAnalysisService,
                          @Lazy ReadinessScoreService readinessScoreService) {
        this.roadmapRepository = roadmapRepository;
        this.taskRepository = taskRepository;
        this.gapAnalysisService = gapAnalysisService;
        this.readinessScoreService = readinessScoreService;
    }

    @Transactional
    public Roadmap getOrCreateRoadmap(User user, String preferredRole) {
        return roadmapRepository.findByUserId(user.getId())
                .orElseGet(() -> generateRoadmapForUser(user, preferredRole));
    }

    @Transactional
    public Roadmap generateRoadmapForUser(User user, String preferredRole) {
        String role = (preferredRole != null && !preferredRole.isBlank()) ? preferredRole.trim() : "Java Full-Stack Developer";

        Roadmap roadmap = roadmapRepository.findByUserId(user.getId())
                .orElse(new Roadmap(user, role));
        roadmap.setTargetRole(role);
        Roadmap savedRoadmap = roadmapRepository.save(roadmap);

        // Fetch existing task titles to avoid creating duplicate tasks
        Set<String> existingTitles = taskRepository.findByRoadmapIdOrderBySortOrderAsc(savedRoadmap.getId())
                .stream()
                .map(RoadmapTask::getTitle)
                .collect(Collectors.toSet());

        List<RoadmapTask> newTasks = new ArrayList<>();
        int order = existingTitles.size() + 1;

        // Base curriculum tasks tailored to career tracks
        List<RoadmapTemplate> templates = getCurriculumForRole(role);
        for (RoadmapTemplate t : templates) {
            if (!existingTitles.contains(t.title)) {
                newTasks.add(new RoadmapTask(savedRoadmap, t.title, t.description, t.skill, t.priority, t.hours, order++));
                existingTitles.add(t.title);
            }
        }

        // Add targeted tasks based on real skill gaps
        List<SkillGapDto> gaps = gapAnalysisService.analyzeUserSkillGaps(user.getId());
        for (SkillGapDto gap : gaps) {
            if ("Needs Improvement".equalsIgnoreCase(gap.getStatus()) || "Not Assessed".equalsIgnoreCase(gap.getStatus())) {
                String gapTaskTitle = "Strengthen " + gap.getCategoryName() + " Fundamentals";
                if (!existingTitles.contains(gapTaskTitle)) {
                    newTasks.add(new RoadmapTask(
                            savedRoadmap,
                            gapTaskTitle,
                            gap.getRecommendation(),
                            gap.getCategoryName(),
                            Priority.HIGH,
                            6,
                            order++
                    ));
                    existingTitles.add(gapTaskTitle);
                }
            }
        }

        if (!newTasks.isEmpty()) {
            taskRepository.saveAll(newTasks);
        }

        savedRoadmap.recalculateProgress();
        return roadmapRepository.save(savedRoadmap);
    }

    @Transactional
    public RoadmapTask toggleTaskCompletion(Long taskId, Long userId) {
        RoadmapTask task = taskRepository.findById(taskId)
                .orElseThrow(() -> new ResourceNotFoundException("Roadmap task not found with id: " + taskId));

        // CRITICAL OWNERSHIP CHECK
        if (!task.getRoadmap().getUser().getId().equals(userId)) {
            throw new UnauthorizedAccessException("You are not authorized to modify another student's roadmap task.");
        }

        if (task.getStatus() == TaskStatus.COMPLETED) {
            task.markPending();
        } else {
            task.markCompleted();
        }

        RoadmapTask saved = taskRepository.save(task);

        // Recalculate roadmap progress
        Roadmap roadmap = task.getRoadmap();
        roadmap.recalculateProgress();
        roadmapRepository.save(roadmap);

        // Recalculate readiness score
        readinessScoreService.recalculateUserReadiness(roadmap.getUser());

        return saved;
    }

    @Transactional(readOnly = true)
    public List<RoadmapTaskDto> getTasksForUser(Long userId) {
        Roadmap roadmap = roadmapRepository.findByUserId(userId).orElse(null);
        if (roadmap == null) return Collections.emptyList();

        return taskRepository.findByRoadmapIdOrderBySortOrderAsc(roadmap.getId()).stream()
                .map(t -> new RoadmapTaskDto(
                        t.getId(),
                        t.getTitle(),
                        t.getDescription(),
                        t.getRelatedSkill(),
                        t.getPriority(),
                        t.getEstimatedHours(),
                        t.getStatus(),
                        t.getSortOrder(),
                        t.getCompletedAt()
                ))
                .collect(Collectors.toList());
    }

    private record RoadmapTemplate(String title, String description, String skill, Priority priority, int hours) {}

    private List<RoadmapTemplate> getCurriculumForRole(String role) {
        List<RoadmapTemplate> list = new ArrayList<>();
        list.add(new RoadmapTemplate(
                "Core OOP & Java Language Mastery",
                "Deep dive into Polymorphism, Inheritance, Exception handling hierarchy, and String pool semantics.",
                "Java Programming", Priority.HIGH, 6));
        list.add(new RoadmapTemplate(
                "Relational Schema Design & SQL Mastery",
                "Construct complex JOINs, GROUP BY aggregation, Subqueries, and 3NF database normalization.",
                "SQL & DBMS", Priority.HIGH, 5));
        list.add(new RoadmapTemplate(
                "DSA Fundamentals: Two Pointers & HashMaps",
                "Solve 20+ algorithmic problems on arrays, frequency maps, sliding window, and binary search.",
                "DSA", Priority.HIGH, 8));
        list.add(new RoadmapTemplate(
                "Spring Boot Architecture & RESTful APIs",
                "Implement Spring MVC, Dependency Injection, Spring Data JPA repositories, and secure endpoints.",
                "Spring Boot", Priority.MEDIUM, 7));
        list.add(new RoadmapTemplate(
                "Aptitude & Quantitative Speed Drills",
                "Practice time and work, percentages, profit-loss, and analytical logical deductions.",
                "Aptitude", Priority.MEDIUM, 4));
        list.add(new RoadmapTemplate(
                "HR Behavioral Prep & STAR Framing",
                "Draft concise STAR stories for conflict resolution, leadership moments, and technical challenges.",
                "HR Interviews", Priority.LOW, 3));
        list.add(new RoadmapTemplate(
                "Resume ATS Optimization & Impact Bullet Points",
                "Format projects with clear action verbs, tech stacks, and quantifiable outcomes.",
                "Resume Preparation", Priority.MEDIUM, 3));
        return list;
    }
}
