package com.placenza.service;

import com.placenza.dto.*;
import com.placenza.entity.*;
import com.placenza.exception.ResourceNotFoundException;
import com.placenza.exception.ValidationException;
import com.placenza.repository.*;
import org.springframework.context.annotation.Lazy;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDateTime;
import java.util.*;
import java.util.stream.Collectors;

@Service
public class AssessmentService {

    private final AssessmentRepository assessmentRepository;
    private final QuestionRepository questionRepository;
    private final AssessmentAttemptRepository attemptRepository;
    private final AssessmentAnswerRepository answerRepository;
    private final UserService userService;
    private final ReadinessScoreService readinessScoreService;

    public AssessmentService(AssessmentRepository assessmentRepository,
                             QuestionRepository questionRepository,
                             AssessmentAttemptRepository attemptRepository,
                             AssessmentAnswerRepository answerRepository,
                             UserService userService,
                             @Lazy ReadinessScoreService readinessScoreService) {
        this.assessmentRepository = assessmentRepository;
        this.questionRepository = questionRepository;
        this.attemptRepository = attemptRepository;
        this.answerRepository = answerRepository;
        this.userService = userService;
        this.readinessScoreService = readinessScoreService;
    }

    @Transactional(readOnly = true)
    public List<Assessment> getAllAssessments() {
        return assessmentRepository.findAll();
    }

    @Transactional(readOnly = true)
    public Assessment getAssessmentById(Long id) {
        return assessmentRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Assessment not found with id: " + id));
    }

    /**
     * Prepares exam paper for student.
     * EXCLUDES correct answer and explanation to prevent inspect-element cheating!
     */
    @Transactional(readOnly = true)
    public AssessmentDetailDto getAssessmentForTaking(Long assessmentId) {
        Assessment assessment = getAssessmentById(assessmentId);

        List<AssessmentQuestionDto> questionDtos = assessment.getQuestions().stream()
                .map(q -> new AssessmentQuestionDto(
                        q.getId(),
                        q.getQuestionText(),
                        q.getOptionA(),
                        q.getOptionB(),
                        q.getOptionC(),
                        q.getOptionD(),
                        q.getDifficulty(),
                        q.getMarks()
                ))
                .collect(Collectors.toList());

        AssessmentDetailDto detail = new AssessmentDetailDto();
        detail.setId(assessment.getId());
        detail.setTitle(assessment.getTitle());
        detail.setDescription(assessment.getDescription());
        detail.setCategoryName(assessment.getCategory().getName());
        detail.setDurationMinutes(assessment.getDurationMinutes());
        detail.setTotalMarks(assessment.getTotalMarks());
        detail.setQuestions(questionDtos);

        return detail;
    }

    @Transactional
    public AssessmentResultDto submitAssessment(User user, AssessmentSubmissionDto submission) {
        Assessment assessment = getAssessmentById(submission.getAssessmentId());

        Map<Long, Question> examQuestionsMap = assessment.getQuestions().stream()
                .collect(Collectors.toMap(Question::getId, q -> q));

        if (examQuestionsMap.isEmpty()) {
            throw new ValidationException("Assessment has no questions configured.");
        }

        Map<Long, String> candidateAnswersMap = new HashMap<>();
        if (submission.getAnswers() != null) {
            for (AnswerSubmissionDto ans : submission.getAnswers()) {
                if (ans.getQuestionId() != null) {
                    // Security check: ensure question belongs to this assessment
                    if (!examQuestionsMap.containsKey(ans.getQuestionId())) {
                        throw new ValidationException("Submitted question does not belong to this assessment.");
                    }
                    candidateAnswersMap.put(ans.getQuestionId(), ans.getSelectedOption() != null ? ans.getSelectedOption().toUpperCase().trim() : null);
                }
            }
        }

        int totalQuestions = examQuestionsMap.size();
        int correctCount = 0;
        List<AnswerReviewDto> reviewList = new ArrayList<>();
        List<AssessmentAnswer> answerEntities = new ArrayList<>();

        for (Question q : assessment.getQuestions()) {
            String selected = candidateAnswersMap.get(q.getId());
            boolean isCorrect = selected != null && selected.equalsIgnoreCase(q.getCorrectOption().trim());
            if (isCorrect) {
                correctCount++;
            }

            reviewList.add(new AnswerReviewDto(
                    q.getId(),
                    q.getQuestionText(),
                    q.getOptionA(),
                    q.getOptionB(),
                    q.getOptionC(),
                    q.getOptionD(),
                    selected,
                    q.getCorrectOption(),
                    isCorrect,
                    q.getExplanation()
            ));
        }

        double scorePercentage = Math.round(((double) correctCount / totalQuestions) * 100.0 * 10.0) / 10.0;
        boolean passed = scorePercentage >= assessment.getPassingScore();

        AssessmentAttempt attempt = new AssessmentAttempt(
                user,
                assessment,
                totalQuestions,
                correctCount,
                scorePercentage,
                passed
        );

        AssessmentAttempt savedAttempt = attemptRepository.save(attempt);

        for (Question q : assessment.getQuestions()) {
            String selected = candidateAnswersMap.get(q.getId());
            boolean isCorrect = selected != null && selected.equalsIgnoreCase(q.getCorrectOption().trim());
            AssessmentAnswer ansEntity = new AssessmentAnswer(savedAttempt, q, selected, isCorrect);
            answerEntities.add(ansEntity);
        }
        answerRepository.saveAll(answerEntities);

        // Update user's readiness score in profile
        readinessScoreService.recalculateUserReadiness(user);

        // Record user activity
        userService.recordActivity(user, "ASSESSMENT_COMPLETED",
                "Completed '" + assessment.getTitle() + "' with score: " + scorePercentage + "% (" + (passed ? "Passed" : "Needs Review") + ")");

        // Generate tailored recommendations
        List<String> recommendations = new ArrayList<>();
        if (scorePercentage < 60.0) {
            recommendations.add("Review core fundamentals in " + assessment.getCategory().getName() + ".");
            recommendations.add("Practice with medium difficulty questions before retaking.");
        } else if (scorePercentage < 80.0) {
            recommendations.add("Solid baseline in " + assessment.getCategory().getName() + ". Strengthen advanced problem patterns.");
        } else {
            recommendations.add("Outstanding mastery! Recommended to proceed with live interview practice.");
        }

        AssessmentResultDto result = new AssessmentResultDto();
        result.setAttemptId(savedAttempt.getId());
        result.setAssessmentId(assessment.getId());
        result.setAssessmentTitle(assessment.getTitle());
        result.setCategoryName(assessment.getCategory().getName());
        result.setTotalQuestions(totalQuestions);
        result.setCorrectAnswers(correctCount);
        result.setScorePercentage(scorePercentage);
        result.setPassed(passed);
        result.setCompletedAt(savedAttempt.getCompletedAt());
        result.setAnswerReviews(reviewList);
        result.setRecommendations(recommendations);

        return result;
    }

    @Transactional(readOnly = true)
    public AssessmentResultDto getAttemptReview(Long attemptId, Long userId) {
        AssessmentAttempt attempt = attemptRepository.findById(attemptId)
                .orElseThrow(() -> new ResourceNotFoundException("Assessment attempt not found: " + attemptId));

        // Ownership enforcement
        if (!attempt.getUser().getId().equals(userId)) {
            throw new ValidationException("You are not authorized to view this attempt result.");
        }

        List<AssessmentAnswer> answers = answerRepository.findByAttemptId(attemptId);
        List<AnswerReviewDto> reviewList = answers.stream().map(a -> new AnswerReviewDto(
                a.getQuestion().getId(),
                a.getQuestion().getQuestionText(),
                a.getQuestion().getOptionA(),
                a.getQuestion().getOptionB(),
                a.getQuestion().getOptionC(),
                a.getQuestion().getOptionD(),
                a.getSelectedOption(),
                a.getQuestion().getCorrectOption(),
                a.isCorrect(),
                a.getQuestion().getExplanation()
        )).collect(Collectors.toList());

        AssessmentResultDto result = new AssessmentResultDto();
        result.setAttemptId(attempt.getId());
        result.setAssessmentId(attempt.getAssessment().getId());
        result.setAssessmentTitle(attempt.getAssessment().getTitle());
        result.setCategoryName(attempt.getAssessment().getCategory().getName());
        result.setTotalQuestions(attempt.getTotalQuestions());
        result.setCorrectAnswers(attempt.getCorrectAnswers());
        result.setScorePercentage(attempt.getScorePercentage());
        result.setPassed(attempt.isPassed());
        result.setCompletedAt(attempt.getCompletedAt());
        result.setAnswerReviews(reviewList);

        return result;
    }

    @Transactional(readOnly = true)
    public List<AssessmentAttempt> getUserAttempts(Long userId) {
        return attemptRepository.findByUserIdOrderByCompletedAtDesc(userId);
    }
}
