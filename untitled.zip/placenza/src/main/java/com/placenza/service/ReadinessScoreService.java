package com.placenza.service;

import com.placenza.dto.ReadinessScoreDto;
import com.placenza.entity.*;
import com.placenza.repository.*;
import org.springframework.context.annotation.Lazy;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.ArrayList;
import java.util.List;

@Service
public class ReadinessScoreService {

    private final AssessmentAttemptRepository attemptRepository;
    private final InterviewPracticeRecordRepository practiceRepository;
    private final RoadmapRepository roadmapRepository;
    private final UserProfileRepository profileRepository;

    public ReadinessScoreService(AssessmentAttemptRepository attemptRepository,
                                 InterviewPracticeRecordRepository practiceRepository,
                                 RoadmapRepository roadmapRepository,
                                 UserProfileRepository profileRepository) {
        this.attemptRepository = attemptRepository;
        this.practiceRepository = practiceRepository;
        this.roadmapRepository = roadmapRepository;
        this.profileRepository = profileRepository;
    }

    @Transactional(readOnly = true)
    public ReadinessScoreDto calculateReadiness(Long userId) {
        ReadinessScoreDto dto = new ReadinessScoreDto();
        List<String> factors = new ArrayList<>();
        List<String> missingRequirements = new ArrayList<>();

        // 1. Technical Assessments Component (40% Weight)
        List<AssessmentAttempt> attempts = attemptRepository.findByUserIdOrderByCompletedAtDesc(userId);
        List<AssessmentAttempt> techAttempts = attempts.stream()
                .filter(a -> !a.getAssessment().getCategory().getName().equalsIgnoreCase("Aptitude"))
                .toList();

        double rawTechScore = 0.0;
        boolean hasTechnicalAssessment = !techAttempts.isEmpty();
        if (hasTechnicalAssessment) {
            rawTechScore = techAttempts.stream().mapToDouble(AssessmentAttempt::getScorePercentage).average().orElse(0.0);
            factors.add(String.format("Technical Assessments: %.1f%% average across %d attempt(s) (Contributes %.1f / 40.0 pts)",
                    rawTechScore, techAttempts.size(), (rawTechScore * 0.40)));
        } else {
            missingRequirements.add("No Technical Skill Assessments completed yet");
        }

        // 2. Aptitude Component (20% Weight)
        List<AssessmentAttempt> aptitudeAttempts = attempts.stream()
                .filter(a -> a.getAssessment().getCategory().getName().equalsIgnoreCase("Aptitude"))
                .toList();

        double rawAptitudeScore = 0.0;
        boolean hasAptitudeAssessment = !aptitudeAttempts.isEmpty();
        if (hasAptitudeAssessment) {
            rawAptitudeScore = aptitudeAttempts.stream().mapToDouble(AssessmentAttempt::getScorePercentage).average().orElse(0.0);
            factors.add(String.format("Aptitude & Reasoning: %.1f%% score (Contributes %.1f / 20.0 pts)",
                    rawAptitudeScore, (rawAptitudeScore * 0.20)));
        } else {
            missingRequirements.add("Aptitude & Quantitative Assessment not yet taken");
        }

        // 3. Interview Practice Component (20% Weight)
        long practicedCount = practiceRepository.countByUserId(userId);
        // Benchmark: 10 practiced questions = 100% of interview target
        double rawInterviewScore = Math.min(100.0, (practicedCount / 10.0) * 100.0);
        factors.add(String.format("Interview Practice: %d questions answered (Score: %.1f%%, Contributes %.1f / 20.0 pts)",
                practicedCount, rawInterviewScore, (rawInterviewScore * 0.20)));

        // 4. Roadmap Completion Component (10% Weight)
        double rawRoadmapScore = 0.0;
        Roadmap roadmap = roadmapRepository.findByUserId(userId).orElse(null);
        if (roadmap != null && roadmap.getOverallProgress() != null) {
            rawRoadmapScore = roadmap.getOverallProgress();
            factors.add(String.format("Roadmap Tasks: %.1f%% completed (Contributes %.1f / 10.0 pts)",
                    rawRoadmapScore, (rawRoadmapScore * 0.10)));
        } else {
            factors.add("Roadmap Tasks: 0.0% completed (Contributes 0.0 / 10.0 pts)");
        }

        // 5. Profile & Career Preparation (10% Weight)
        UserProfile profile = profileRepository.findByUserId(userId).orElse(null);
        double rawProfileScore = (profile != null) ? profile.getProfileCompletionPercentage() : 0.0;
        factors.add(String.format("Profile Completion: %.1f%% filled (Contributes %.1f / 10.0 pts)",
                rawProfileScore, (rawProfileScore * 0.10)));

        // Weighting Calculations
        double techComponent = rawTechScore * 0.40;
        double aptComponent = rawAptitudeScore * 0.20;
        double interviewComponent = rawInterviewScore * 0.20;
        double roadmapComponent = rawRoadmapScore * 0.10;
        double profileComponent = rawProfileScore * 0.10;

        double overallScore = Math.round((techComponent + aptComponent + interviewComponent + roadmapComponent + profileComponent) * 10.0) / 10.0;

        boolean isProvisional = !hasTechnicalAssessment || !hasAptitudeAssessment;

        dto.setOverallScore(overallScore);
        dto.setProvisional(isProvisional);
        dto.setTechnicalComponent(Math.round(techComponent * 10.0) / 10.0);
        dto.setAptitudeComponent(Math.round(aptComponent * 10.0) / 10.0);
        dto.setInterviewComponent(Math.round(interviewComponent * 10.0) / 10.0);
        dto.setRoadmapComponent(Math.round(roadmapComponent * 10.0) / 10.0);
        dto.setProfileComponent(Math.round(profileComponent * 10.0) / 10.0);

        dto.setTechnicalScoreRaw(Math.round(rawTechScore * 10.0) / 10.0);
        dto.setAptitudeScoreRaw(Math.round(rawAptitudeScore * 10.0) / 10.0);
        dto.setInterviewScoreRaw(Math.round(rawInterviewScore * 10.0) / 10.0);
        dto.setRoadmapScoreRaw(Math.round(rawRoadmapScore * 10.0) / 10.0);
        dto.setProfileScoreRaw(Math.round(rawProfileScore * 10.0) / 10.0);

        if (isProvisional) {
            dto.setProvisionalReason("Provisional: " + String.join(", ", missingRequirements) + ".");
            dto.setReadinessBand("Provisional Baseline");
            dto.setSummaryText("Your placement score is marked provisional until at least one technical and one aptitude assessment are completed.");
        } else if (overallScore >= 80.0) {
            dto.setReadinessBand("Placement Ready");
            dto.setSummaryText("Excellent preparation! You demonstrate strong competency across technical concepts, aptitude, and interview fundamentals.");
        } else if (overallScore >= 60.0) {
            dto.setReadinessBand("Advancing Well");
            dto.setSummaryText("Solid progress. Focus on your weaker roadmap tasks and practice more interview scenarios to boost your standing.");
        } else if (overallScore >= 40.0) {
            dto.setReadinessBand("Developing");
            dto.setSummaryText("Foundational progress detected. Allocate study time to technical assessments and complete pending roadmap milestones.");
        } else {
            dto.setReadinessBand("Early Stage");
            dto.setSummaryText("Early preparation phase. Complete initial assessments and start practising interview questions.");
        }

        dto.setContributingFactors(factors);
        return dto;
    }

    @Transactional
    public void recalculateUserReadiness(User user) {
        ReadinessScoreDto scoreDto = calculateReadiness(user.getId());
        UserProfile profile = profileRepository.findByUserId(user.getId())
                .orElseGet(() -> new UserProfile(user));
        profile.setReadinessScore(scoreDto.getOverallScore());
        profile.setProvisional(scoreDto.isProvisional());
        profileRepository.save(profile);
    }
}
