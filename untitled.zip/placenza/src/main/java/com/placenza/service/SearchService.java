package com.placenza.service;

import com.placenza.dto.SearchResultDto;
import com.placenza.entity.*;
import com.placenza.repository.*;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.ArrayList;
import java.util.List;

@Service
public class SearchService {

    private final CategoryRepository categoryRepository;
    private final AssessmentRepository assessmentRepository;
    private final InterviewQuestionRepository interviewRepository;
    private final QuestionRepository questionRepository;
    private final RoadmapTaskRepository roadmapTaskRepository;

    public SearchService(CategoryRepository categoryRepository,
                         AssessmentRepository assessmentRepository,
                         InterviewQuestionRepository interviewRepository,
                         QuestionRepository questionRepository,
                         RoadmapTaskRepository roadmapTaskRepository) {
        this.categoryRepository = categoryRepository;
        this.assessmentRepository = assessmentRepository;
        this.interviewRepository = interviewRepository;
        this.questionRepository = questionRepository;
        this.roadmapTaskRepository = roadmapTaskRepository;
    }

    @Transactional(readOnly = true)
    public List<SearchResultDto> executeSearch(String keyword, String typeFilter, Long userId) {
        if (keyword == null || keyword.trim().isEmpty()) {
            return List.of();
        }

        String sanitized = keyword.trim();
        List<SearchResultDto> results = new ArrayList<>();
        Pageable pageable = PageRequest.of(0, 15);

        // 1. Search Categories
        if (typeFilter == null || typeFilter.isBlank() || "CATEGORY".equalsIgnoreCase(typeFilter)) {
            Page<Category> categories = categoryRepository.searchCategories(sanitized, pageable);
            for (Category c : categories) {
                results.add(new SearchResultDto(
                        "CATEGORY",
                        c.getId(),
                        c.getName(),
                        c.getDescription(),
                        c.getName(),
                        null,
                        "/categories/" + c.getSlug()
                ));
            }
        }

        // 2. Search Assessments
        if (typeFilter == null || typeFilter.isBlank() || "ASSESSMENT".equalsIgnoreCase(typeFilter)) {
            Page<Assessment> assessments = assessmentRepository.searchAssessments(sanitized, pageable);
            for (Assessment a : assessments) {
                results.add(new SearchResultDto(
                        "ASSESSMENT",
                        a.getId(),
                        a.getTitle(),
                        a.getDescription(),
                        a.getCategory().getName(),
                        null,
                        "/assessments/" + a.getId() + "/take"
                ));
            }
        }

        // 3. Search Interview Questions
        if (typeFilter == null || typeFilter.isBlank() || "INTERVIEW".equalsIgnoreCase(typeFilter)) {
            Page<InterviewQuestion> interviews = interviewRepository.searchInterviewQuestions(sanitized, pageable);
            for (InterviewQuestion iq : interviews) {
                results.add(new SearchResultDto(
                        "INTERVIEW",
                        iq.getId(),
                        iq.getQuestionText(),
                        iq.getReferenceAnswer().substring(0, Math.min(120, iq.getReferenceAnswer().length())) + "...",
                        iq.getCategory().getName(),
                        iq.getDifficulty().name(),
                        "/interviews/practice?category=" + iq.getCategory().getId()
                ));
            }
        }

        // 4. Search User's Roadmap Tasks (if logged in)
        if (userId != null && (typeFilter == null || typeFilter.isBlank() || "ROADMAP".equalsIgnoreCase(typeFilter))) {
            Page<RoadmapTask> tasks = roadmapTaskRepository.searchUserRoadmapTasks(userId, sanitized, pageable);
            for (RoadmapTask t : tasks) {
                results.add(new SearchResultDto(
                        "ROADMAP",
                        t.getId(),
                        t.getTitle(),
                        t.getDescription(),
                        t.getRelatedSkill(),
                        t.getPriority().name(),
                        "/roadmap"
                ));
            }
        }

        return results;
    }
}
