package com.placenza.service;

import com.placenza.dto.RegistrationDto;
import com.placenza.dto.UserProfileDto;
import com.placenza.entity.*;
import com.placenza.exception.ResourceNotFoundException;
import com.placenza.exception.ValidationException;
import com.placenza.repository.ActivityRecordRepository;
import com.placenza.repository.UserProfileRepository;
import com.placenza.repository.UserRepository;
import org.springframework.context.annotation.Lazy;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.Optional;

@Service
public class UserService {

    private final UserRepository userRepository;
    private final UserProfileRepository profileRepository;
    private final ActivityRecordRepository activityRepository;
    private final PasswordEncoder passwordEncoder;
    private final RoadmapService roadmapService;

    public UserService(UserRepository userRepository,
                       UserProfileRepository profileRepository,
                       ActivityRecordRepository activityRepository,
                       PasswordEncoder passwordEncoder,
                       @Lazy RoadmapService roadmapService) {
        this.userRepository = userRepository;
        this.profileRepository = profileRepository;
        this.activityRepository = activityRepository;
        this.passwordEncoder = passwordEncoder;
        this.roadmapService = roadmapService;
    }

    @Transactional
    public User register(RegistrationDto dto) {
        if (!dto.isPasswordConfirmed()) {
            throw new ValidationException("Passwords do not match");
        }

        if (userRepository.existsByEmail(dto.getEmail().toLowerCase().trim())) {
            throw new ValidationException("An account with this email address already exists");
        }

        User user = new User();
        user.setEmail(dto.getEmail().toLowerCase().trim());
        user.setFullName(dto.getFullName().trim());
        user.setPasswordHash(passwordEncoder.encode(dto.getPassword()));
        user.setRole(Role.ROLE_STUDENT);
        user.setEnabled(true);
        user.setTwoFactorEnabled(true);

        User savedUser = userRepository.save(user);

        // Create profile
        UserProfile profile = new UserProfile(savedUser);
        profile.setCollege(dto.getCollege().trim());
        profile.setDegree(dto.getDegree().trim());
        profile.setGraduationYear(dto.getGraduationYear());
        profile.setCareerRole(dto.getPreferredCareerRole().trim());
        profile.setReadinessScore(0.0);
        profile.setProvisional(true);
        profileRepository.save(profile);

        // Record initial activity
        recordActivity(savedUser, "ACCOUNT_REGISTRATION", "Account registered with career track: " + dto.getPreferredCareerRole());

        // Automatically initialize initial learning roadmap
        roadmapService.generateRoadmapForUser(savedUser, dto.getPreferredCareerRole());

        return savedUser;
    }

    @Transactional(readOnly = true)
    public User findByEmail(String email) {
        return userRepository.findByEmail(email)
                .orElseThrow(() -> new ResourceNotFoundException("User not found with email: " + email));
    }

    @Transactional(readOnly = true)
    public Optional<User> findOptionalByEmail(String email) {
        return userRepository.findByEmail(email);
    }

    @Transactional(readOnly = true)
    public User findById(Long id) {
        return userRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("User not found with id: " + id));
    }

    @Transactional(readOnly = true)
    public UserProfileDto getUserProfileDto(Long userId) {
        User user = findById(userId);
        UserProfile profile = profileRepository.findByUserId(userId)
                .orElseGet(() -> profileRepository.save(new UserProfile(user)));

        UserProfileDto dto = new UserProfileDto();
        dto.setUserId(user.getId());
        dto.setFullName(user.getFullName());
        dto.setEmail(user.getEmail());
        dto.setCollege(profile.getCollege());
        dto.setDegree(profile.getDegree());
        dto.setGraduationYear(profile.getGraduationYear());
        dto.setCareerRole(profile.getCareerRole());
        dto.setPhone(profile.getPhone());
        dto.setBio(profile.getBio());
        dto.setTargetCompanies(profile.getTargetCompanies());
        dto.setReadinessScore(profile.getReadinessScore());
        dto.setProvisional(profile.isProvisional());
        dto.setProfileCompletionPercentage(profile.getProfileCompletionPercentage());

        return dto;
    }

    @Transactional
    public void updateProfile(Long userId, UserProfileDto dto) {
        User user = findById(userId);
        if (dto.getFullName() != null && !dto.getFullName().isBlank()) {
            user.setFullName(dto.getFullName().trim());
            userRepository.save(user);
        }

        UserProfile profile = profileRepository.findByUserId(userId)
                .orElseGet(() -> new UserProfile(user));

        profile.setCollege(dto.getCollege());
        profile.setDegree(dto.getDegree());
        profile.setGraduationYear(dto.getGraduationYear());
        profile.setCareerRole(dto.getCareerRole());
        profile.setPhone(dto.getPhone());
        profile.setBio(dto.getBio());
        profile.setTargetCompanies(dto.getTargetCompanies());
        profileRepository.save(profile);

        recordActivity(user, "PROFILE_UPDATE", "Updated profile details and target companies");
    }

    @Transactional
    public void recordActivity(User user, String type, String description) {
        ActivityRecord record = new ActivityRecord(user, type, description);
        activityRepository.save(record);
    }
}
