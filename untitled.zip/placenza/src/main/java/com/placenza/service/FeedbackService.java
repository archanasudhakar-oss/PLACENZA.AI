package com.placenza.service;

import com.placenza.dto.FeedbackDto;
import com.placenza.entity.Feedback;
import com.placenza.entity.User;
import com.placenza.exception.ValidationException;
import com.placenza.repository.FeedbackRepository;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Service
public class FeedbackService {

    private final FeedbackRepository feedbackRepository;
    private final UserService userService;

    public FeedbackService(FeedbackRepository feedbackRepository, UserService userService) {
        this.feedbackRepository = feedbackRepository;
        this.userService = userService;
    }

    @Transactional
    public Feedback submitUserFeedback(User user, FeedbackDto dto) {
        validateFeedbackDto(dto);
        Feedback feedback = new Feedback(user, dto.getRating(), dto.getCategory().trim(), dto.getComment().trim());
        Feedback saved = feedbackRepository.save(feedback);
        userService.recordActivity(user, "FEEDBACK_SUBMITTED", "Submitted " + dto.getRating() + "-star feedback for " + dto.getCategory());
        return saved;
    }

    @Transactional
    public Feedback submitGuestFeedback(FeedbackDto dto) {
        validateFeedbackDto(dto);
        if (dto.getGuestName() == null || dto.getGuestName().isBlank()) {
            throw new ValidationException("Guest name is required for public feedback.");
        }
        Feedback feedback = new Feedback(
                dto.getGuestName().trim(),
                dto.getGuestEmail() != null ? dto.getGuestEmail().trim() : null,
                dto.getRating(),
                dto.getCategory().trim(),
                dto.getComment().trim()
        );
        return feedbackRepository.save(feedback);
    }

    private void validateFeedbackDto(FeedbackDto dto) {
        if (dto.getRating() == null || dto.getRating() < 1 || dto.getRating() > 5) {
            throw new ValidationException("Rating must be between 1 and 5 stars.");
        }
        if (dto.getComment() == null || dto.getComment().trim().length() < 5) {
            throw new ValidationException("Feedback comment must be at least 5 characters long.");
        }
    }

    @Transactional(readOnly = true)
    public List<Feedback> getUserFeedbacks(Long userId) {
        return feedbackRepository.findByUserIdOrderBySubmittedAtDesc(userId);
    }

    @Transactional(readOnly = true)
    public Page<Feedback> getAllFeedbacks(int page, int size) {
        return feedbackRepository.findAllByOrderBySubmittedAtDesc(PageRequest.of(page, size));
    }

    @Transactional(readOnly = true)
    public Map<String, Object> getFeedbackSummary() {
        Map<String, Object> summary = new HashMap<>();
        Double avg = feedbackRepository.calculateAverageRating();
        summary.put("averageRating", avg != null ? Math.round(avg * 10.0) / 10.0 : 0.0);
        summary.put("totalCount", feedbackRepository.count());

        Map<Integer, Long> breakdown = new HashMap<>();
        for (int star = 1; star <= 5; star++) {
            breakdown.put(star, feedbackRepository.countByRating(star));
        }
        summary.put("breakdown", breakdown);
        return summary;
    }
}
