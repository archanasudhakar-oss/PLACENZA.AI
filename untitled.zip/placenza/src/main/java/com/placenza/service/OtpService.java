package com.placenza.service;

import com.placenza.entity.OtpVerification;
import com.placenza.entity.User;
import com.placenza.repository.OtpVerificationRepository;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.security.SecureRandom;
import java.time.LocalDateTime;
import java.util.Optional;

@Service
public class OtpService {

    private static final Logger log = LoggerFactory.getLogger(OtpService.class);
    private static final SecureRandom SECURE_RANDOM = new SecureRandom();

    private final OtpVerificationRepository otpRepository;
    private final PasswordEncoder passwordEncoder;

    @Value("${placenza.otp.enabled:true}")
    private boolean otpEnabled;

    @Value("${placenza.otp.delivery-mode:local-log}")
    private String deliveryMode;

    public OtpService(OtpVerificationRepository otpRepository, PasswordEncoder passwordEncoder) {
        this.otpRepository = otpRepository;
        this.passwordEncoder = passwordEncoder;
    }

    public boolean isOtpEnabled() {
        return otpEnabled;
    }

    @Transactional
    public String generateAndSendOtp(User user) {
        // Generate a 6-digit cryptographically secure code
        int codeInt = 100000 + SECURE_RANDOM.nextInt(900000);
        String rawCode = String.valueOf(codeInt);

        // Hash the code before storing in the database
        String codeHash = passwordEncoder.encode(rawCode);
        LocalDateTime expiresAt = LocalDateTime.now().plusMinutes(5);

        // Save OTP record
        OtpVerification otp = new OtpVerification(user, codeHash, expiresAt);
        otpRepository.save(otp);

        // Modular delivery adapter
        deliverOtp(user, rawCode);

        return rawCode;
    }

    private void deliverOtp(User user, String rawCode) {
        if ("smtp".equalsIgnoreCase(deliveryMode)) {
            // Production SMTP mailer adapter placeholder
            log.info("[OTP SMTP ADAPTER] Sending email with OTP to: {}", user.getEmail());
            // When real mail credentials are configured, JavaMailSender will dispatch the message
        } else {
            // Local Development & Capstone Demonstration Mode:
            // Output clearly to server log for controlled testing without exposing to public clients
            log.info("==========================================================");
            log.info("[LOCAL CAPSTONE OTP CHALLENGE] User: {} | Code: {}", user.getEmail(), rawCode);
            log.info("This is valid for 5 minutes. Enter this code on the verification screen.");
            log.info("==========================================================");
        }
    }

    @Transactional
    public boolean verifyOtp(User user, String rawCode) {
        Optional<OtpVerification> optOtp = otpRepository.findTopByUserIdAndConsumedFalseOrderByCreatedAtDesc(user.getId());
        if (optOtp.isEmpty()) {
            log.warn("No active OTP challenge found for user: {}", user.getEmail());
            return false;
        }

        OtpVerification otp = optOtp.get();

        if (otp.isExpired()) {
            log.warn("OTP expired for user: {}", user.getEmail());
            return false;
        }

        if (otp.hasExceededAttempts()) {
            log.warn("OTP exceeded maximum attempts for user: {}", user.getEmail());
            return false;
        }

        otp.incrementAttempt();

        boolean matches = passwordEncoder.matches(rawCode, otp.getCodeHash());
        if (matches) {
            otp.markConsumed();
            otpRepository.save(otp);
            log.info("OTP verified successfully for user: {}", user.getEmail());
            return true;
        } else {
            otpRepository.save(otp);
            log.warn("Invalid OTP entered for user: {}. Attempt {}/{}", user.getEmail(), otp.getAttemptCount(), otp.getMaxAttempts());
            return false;
        }
    }
}
