package com.placenza.service;

import com.placenza.dto.DemoPaymentRequestDto;
import com.placenza.dto.TransactionResponseDto;
import com.placenza.entity.*;
import com.placenza.exception.ResourceNotFoundException;
import com.placenza.exception.ValidationException;
import com.placenza.repository.PaymentTransactionRepository;
import com.placenza.repository.PurchaseRepository;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.*;

@Service
public class PaymentService {

    public record ServiceOffering(String key, String title, String description, BigDecimal price, String currency) {}

    private final Map<String, ServiceOffering> catalog = new LinkedHashMap<>();

    private final PurchaseRepository purchaseRepository;
    private final PaymentTransactionRepository transactionRepository;
    private final UserService userService;

    @Value("${placenza.payment.demo-mode:true}")
    private boolean demoMode;

    public PaymentService(PurchaseRepository purchaseRepository,
                          PaymentTransactionRepository transactionRepository,
                          UserService userService) {
        this.purchaseRepository = purchaseRepository;
        this.transactionRepository = transactionRepository;
        this.userService = userService;
        initializeCatalog();
    }

    private void initializeCatalog() {
        catalog.put("MOCK_INTERVIEW_PRO", new ServiceOffering(
                "MOCK_INTERVIEW_PRO",
                "1-on-1 Mock Interview Pro Session",
                "Simulated 60-minute technical interview covering live coding, architecture design, and comprehensive rubric evaluation.",
                new BigDecimal("499.00"),
                "INR"
        ));
        catalog.put("DSA_ADVANCED_PACK", new ServiceOffering(
                "DSA_ADVANCED_PACK",
                "DSA Advanced Mastery Question Pack",
                "Curated collection of 150+ high-frequency company interview questions with deep dive architectural breakdowns.",
                new BigDecimal("299.00"),
                "INR"
        ));
        catalog.put("PREMIUM_CAREER_ROADMAP", new ServiceOffering(
                "PREMIUM_CAREER_ROADMAP",
                "Full-Stack Career Accelerate Pass",
                "Unlimited diagnostic assessments, personalized learning roadmap generation, and priority resume ATS check.",
                new BigDecimal("899.00"),
                "INR"
        ));
    }

    public List<ServiceOffering> getServiceCatalog() {
        return new ArrayList<>(catalog.values());
    }

    public ServiceOffering getOffering(String key) {
        ServiceOffering offering = catalog.get(key);
        if (offering == null) {
            throw new ValidationException("Unknown service offering: " + key);
        }
        return offering;
    }

    @Transactional
    public TransactionResponseDto initiateDemoPurchase(User user, DemoPaymentRequestDto request) {
        ServiceOffering offering = getOffering(request.getOfferingKey());

        // Server generates authoritative purchase and transaction references
        String purchaseRef = "PUR-" + UUID.randomUUID().toString().substring(0, 8).toUpperCase();
        String txnRef = "TXN-DEMO-" + UUID.randomUUID().toString().substring(0, 8).toUpperCase();

        // Security requirement: use authoritative price from server catalog, never client input!
        BigDecimal authoritativePrice = offering.price();

        Purchase purchase = new Purchase(
                purchaseRef,
                user,
                offering.title(),
                authoritativePrice,
                offering.currency(),
                "DEMO_SIMULATION"
        );
        purchase.setStatus(TransactionStatus.SUCCESSFUL); // Automatically successful under demo mode
        Purchase savedPurchase = purchaseRepository.save(purchase);

        PaymentTransaction transaction = new PaymentTransaction(
                txnRef,
                savedPurchase,
                authoritativePrice,
                TransactionStatus.SUCCESSFUL,
                true, // DEMO SIMULATION FLAG
                "DEMO_SIMULATION",
                request.getNotes() != null ? request.getNotes() : "Demo simulation test transaction for capstone evaluation"
        );
        transaction.setConfirmedAt(LocalDateTime.now());
        PaymentTransaction savedTxn = transactionRepository.save(transaction);

        userService.recordActivity(user, "SERVICE_PURCHASE",
                "Purchased '" + offering.title() + "' (" + purchaseRef + ") [DEMO MODE]");

        return mapToDto(savedPurchase, savedTxn);
    }

    @Transactional(readOnly = true)
    public List<Purchase> getUserPurchases(Long userId) {
        return purchaseRepository.findByUserIdOrderByCreatedAtDesc(userId);
    }

    @Transactional(readOnly = true)
    public Page<PaymentTransaction> getAllTransactions(int page, int size) {
        return transactionRepository.findAllByOrderByCreatedAtDesc(PageRequest.of(page, size));
    }

    @Transactional(readOnly = true)
    public Purchase getPurchaseByReference(String reference, Long userId, boolean isAdmin) {
        Purchase purchase = purchaseRepository.findByPurchaseReference(reference)
                .orElseThrow(() -> new ResourceNotFoundException("Purchase not found with reference: " + reference));

        if (!isAdmin && !purchase.getUser().getId().equals(userId)) {
            throw new ValidationException("You are not authorized to view this transaction.");
        }
        return purchase;
    }

    private TransactionResponseDto mapToDto(Purchase p, PaymentTransaction t) {
        TransactionResponseDto dto = new TransactionResponseDto();
        dto.setPurchaseReference(p.getPurchaseReference());
        dto.setTransactionReference(t.getTransactionReference());
        dto.setServiceOffering(p.getServiceOffering());
        dto.setAmount(p.getAmount());
        dto.setCurrency(p.getCurrency());
        dto.setStatus(t.getStatus());
        dto.setDemo(t.isDemo());
        dto.setPaymentMode(t.getPaymentMode());
        dto.setNotes(t.getNotes());
        dto.setCreatedAt(t.getCreatedAt());
        dto.setConfirmedAt(t.getConfirmedAt());
        return dto;
    }
}
