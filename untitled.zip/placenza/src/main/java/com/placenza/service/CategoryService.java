package com.placenza.service;

import com.placenza.entity.Category;
import com.placenza.exception.ResourceNotFoundException;
import com.placenza.exception.ValidationException;
import com.placenza.repository.AssessmentRepository;
import com.placenza.repository.CategoryRepository;
import com.placenza.repository.InterviewQuestionRepository;
import com.placenza.repository.QuestionRepository;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Service
public class CategoryService {

    private final CategoryRepository categoryRepository;
    private final QuestionRepository questionRepository;
    private final AssessmentRepository assessmentRepository;
    private final InterviewQuestionRepository interviewQuestionRepository;

    public CategoryService(CategoryRepository categoryRepository,
                           QuestionRepository questionRepository,
                           AssessmentRepository assessmentRepository,
                           InterviewQuestionRepository interviewQuestionRepository) {
        this.categoryRepository = categoryRepository;
        this.questionRepository = questionRepository;
        this.assessmentRepository = assessmentRepository;
        this.interviewQuestionRepository = interviewQuestionRepository;
    }

    @Transactional(readOnly = true)
    public List<Category> getAllCategories() {
        return categoryRepository.findAllByOrderByDisplayOrderAsc();
    }

    @Transactional(readOnly = true)
    public Category getCategoryById(Long id) {
        return categoryRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Category not found with id: " + id));
    }

    @Transactional(readOnly = true)
    public Category getCategoryBySlug(String slug) {
        return categoryRepository.findBySlug(slug)
                .orElseThrow(() -> new ResourceNotFoundException("Category not found with slug: " + slug));
    }

    @Transactional
    public Category createCategory(Category category) {
        if (category.getSlug() == null || category.getSlug().isBlank()) {
            category.setSlug(category.getName().toLowerCase().replaceAll("[^a-z0-9]+", "-"));
        }
        return categoryRepository.save(category);
    }

    @Transactional
    public Category updateCategory(Long id, Category updated) {
        Category existing = getCategoryById(id);
        existing.setName(updated.getName());
        existing.setDescription(updated.getDescription());
        existing.setIcon(updated.getIcon());
        existing.setDisplayOrder(updated.getDisplayOrder());
        return categoryRepository.save(existing);
    }

    @Transactional
    public void deleteCategory(Long id) {
        Category existing = getCategoryById(id);
        if (!questionRepository.findByCategoryId(id).isEmpty()) {
            throw new ValidationException("Cannot delete category containing active assessment questions.");
        }
        if (!assessmentRepository.findByCategoryId(id).isEmpty()) {
            throw new ValidationException("Cannot delete category referenced by active assessments.");
        }
        if (!interviewQuestionRepository.findByCategoryId(id).isEmpty()) {
            throw new ValidationException("Cannot delete category containing active interview questions.");
        }
        categoryRepository.delete(existing);
    }
}
