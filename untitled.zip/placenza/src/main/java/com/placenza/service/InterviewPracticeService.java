package com.placenza.service;

import com.placenza.entity.*;
import com.placenza.exception.ResourceNotFoundException;
import com.placenza.repository.InterviewPracticeRecordRepository;
import com.placenza.repository.InterviewQuestionRepository;
import org.springframework.context.annotation.Lazy;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.Optional;

@Service
public class InterviewPracticeService {

    private final InterviewQuestionRepository questionRepository;
    private final InterviewPracticeRecordRepository practiceRepository;
    private final ReadinessScoreService readinessScoreService;
    private final UserService userService;

    public InterviewPracticeService(InterviewQuestionRepository questionRepository,
                                  InterviewPracticeRecordRepository practiceRepository,
                                  @Lazy ReadinessScoreService readinessScoreService,
                                  UserService userService) {
        this.questionRepository = questionRepository;
        this.practiceRepository = practiceRepository;
        this.readinessScoreService = readinessScoreService;
        this.userService = userService;
    }

    @Transactional(readOnly = true)
    public List<InterviewQuestion> getQuestions(Long categoryId, Difficulty difficulty) {
        if (categoryId != null && difficulty != null) {
            return questionRepository.findByCategoryIdAndDifficulty(categoryId, difficulty);
        } else if (categoryId != null) {
            return questionRepository.findByCategoryId(categoryId);
        } else if (difficulty != null) {
            return questionRepository.findByDifficulty(difficulty);
        }
        return questionRepository.findAll();
    }

    @Transactional(readOnly = true)
    public InterviewQuestion getQuestionById(Long id) {
        return questionRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Interview question not found with id: " + id));
    }

    @Transactional
    public InterviewPracticeRecord recordPractice(User user, Long questionId, String notes, Integer selfRating) {
        InterviewQuestion question = getQuestionById(questionId);

        Optional<InterviewPracticeRecord> existing = practiceRepository.findByUserIdAndInterviewQuestionId(user.getId(), questionId);
        InterviewPracticeRecord record;
        if (existing.isPresent()) {
            record = existing.get();
            record.setNotes(notes);
            record.setSelfRating(selfRating != null ? selfRating : 5);
        } else {
            record = new InterviewPracticeRecord(user, question, notes, selfRating);
        }

        InterviewPracticeRecord saved = practiceRepository.save(record);

        // Recalculate user readiness (interview practice component)
        readinessScoreService.recalculateUserReadiness(user);

        userService.recordActivity(user, "INTERVIEW_PRACTICE", "Practised question: " + question.getQuestionText().substring(0, Math.min(60, question.getQuestionText().length())) + "...");

        return saved;
    }

    @Transactional(readOnly = true)
    public List<InterviewPracticeRecord> getUserPracticeHistory(Long userId) {
        return practiceRepository.findByUserIdOrderByPracticedAtDesc(userId);
    }

    @Transactional(readOnly = true)
    public boolean hasPracticed(Long userId, Long questionId) {
        return practiceRepository.existsByUserIdAndInterviewQuestionId(userId, questionId);
    }
}
