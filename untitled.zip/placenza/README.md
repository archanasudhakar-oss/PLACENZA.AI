# PLACENZA AI: Intelligent Placement Readiness and Career Development Platform

> **Tagline:** *"Your Potential. Your Preparation. Your Placement."*  
> **Academic Scope:** Complete, secure, responsive, multi-user Java Full-Stack web application designed for strict college Capstone evaluation.

---

## 1. Technology Compliance Matrix

| Tier | Component | Technology Used | Version |
|---|---|---|---|
| **Backend Runtime** | Java Development Kit | OpenJDK / Oracle JDK | Java 21 (or 17+) |
| **Framework** | Spring Boot | Spring MVC, Spring Security, Spring Data JPA | 3.3.4 |
| **ORM** | Hibernate | Jakarta Persistence | 6.x |
| **Database** | MySQL | MySQL Community Server & Connector/J | 8.x |
| **Frontend Templates** | Thymeleaf | Thymeleaf Spring Security 6 Integration | 3.1.x |
| **UI Styling** | Bootstrap 5 + Custom CSS | Design tokens (#0B1020, #8B5CF6, #22D3EE) | 5.3.3 |
| **Client Scripting** | Vanilla JavaScript | Custom event-driven script (`placenza.js`) | ES6+ |
| **Build System** | Apache Maven | Maven Wrapper (`mvnw.cmd` / `mvnw`) | 3.9.x |

*Strictly zero React, Angular, Vue, Node.js, Express, Python, MongoDB, Firebase, or external AI APIs used in the application.*

---

## 2. Windows Prerequisites & Installation

### Step 2.1: Install Java 21
1. Download OpenJDK 21 or Eclipse Temurin 21 from [https://adoptium.net/](https://adoptium.net/).
2. Run the installer and ensure **"Add to PATH"** and **"Set JAVA_HOME variable"** are checked.
3. Verify in Windows PowerShell:
   ```powershell
   java -version
   ```
   *Expected output: `openjdk version "21.x.x"`*

### Step 2.2: Install and Start MySQL 8
1. Download **MySQL Community Server 8.x** or install via XAMPP.
2. Start the MySQL service:
   ```powershell
   net start MySQL80
   ```
3. Open MySQL Command Line or PowerShell:
   ```powershell
   mysql -u root -p
   ```
4. Create the application database:
   ```sql
   CREATE DATABASE IF NOT EXISTS placenza_db CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
   SHOW DATABASES;
   EXIT;
   ```

---

## 3. Configuration & Credentials

The application uses standard Spring configuration in `src/main/resources/application.properties`. You can override settings using environment variables or a local `.env` file.

Default local configuration:
```properties
server.port=8080
spring.datasource.url=jdbc:mysql://localhost:3306/placenza_db?createDatabaseIfNotExist=true&useSSL=false&allowPublicKeyRetrieval=true&serverTimezone=UTC
spring.datasource.username=root
spring.datasource.password=
```

If your MySQL root user has a password:
```powershell
# Set in PowerShell before running:
$env:DB_PASSWORD="your_password_here"
```

---

## 4. Running the Application on Windows

Navigate into the `placenza` directory and run using Maven Wrapper:

```powershell
# In PowerShell:
cd placenza
.\mvnw.cmd clean spring-boot:run
```

Or using an installed Maven binary:
```powershell
mvn clean spring-boot:run
```

When Spring Boot finishes bootstrapping, you will see:
```
INFO [main] com.placenza.PlacenzaApplication : Started PlacenzaApplication in X.XXX seconds
```

Open your browser and navigate to:
```
http://localhost:8080
```

---

## 5. Default Accounts & Testing Workflows

### 5.1 System Administrator Account (Pre-configured Bootstrap)
- **URL:** `http://localhost:8080/login`
- **Email:** `admin@placenza.ai`
- **Password:** `Admin@Placenza2026!`
- **Capabilities:**
  - View comprehensive platform metrics (total users, active attempts, average rating).
  - Manage and add skill categories.
  - Review candidate feedback and star rating breakdown.
  - Audit demo payment simulation transactions.

### 5.2 Student Registration & Authentication
1. Click **"Get Started"** on the landing page or visit `http://localhost:8080/register`.
2. Fill in your details (e.g., Name: Archana Sudhakar, College: NIT, Degree: B.Tech CSE, Graduation: 2026, Target Track: Java Full-Stack Developer).
3. The platform will automatically initialize your private profile and generate a customized roadmap!
4. Sign in with your new email and password.

---

## 6. Core Modules & Evaluation Features

1. **Skill Diagnostic Assessments (`/assessments`):**
   - Timed multiple-choice exams in Java, SQL, DSA, and Aptitude.
   - Correct options are omitted from the client pre-submission to prevent cheating.
   - Immediate server-side scoring, percentage calculation, and detailed review.

2. **Personalized Learning Roadmap (`/roadmap`):**
   - Automatically builds tasks based on selected track and diagnosed skill gaps.
   - Task completion toggling with strict student-level ownership isolation.

3. **Transparent Placement Readiness Score (`/dashboard`):**
   - Technical Assessments: **40% weight**
   - Aptitude & Quantitative: **20% weight**
   - Interview Practice: **20% weight**
   - Learning Roadmap: **10% weight**
   - Profile Completion: **10% weight**
   - Clearly flagged as *Provisional* if required assessment categories have not been attempted.

4. **Rule-Based Placement Chatbot (`/chatbot`):**
   - Java rule-matching engine covering Java OOP, Collections, SQL, DBMS, DSA, Aptitude, STAR framework, and platform navigation.
   - Completely offline with zero third-party AI keys.

5. **Demo Payment Module (`/pricing`, `/payments/history`):**
   - Authoritative pricing catalog enforced on the backend.
   - Explicitly marked `DEMO_SIMULATION` mode for capstone evaluation.

---

## 7. Running Automated Tests

To execute the test suite (uses embedded in-memory H2 database with MySQL compatibility mode so it runs without needing an active MySQL connection):

```powershell
.\mvnw.cmd test
```

Test coverage includes:
- `PlacenzaApplicationTests`: Spring Boot context initialization
- `AuthServiceTest`: Candidate registration, duplicate email rejection, BCrypt hashing
- `ReadinessScoreServiceTest`: Weighted calculation (40/20/20/10/10) and provisional flags
- `RoadmapServiceTest`: Dynamic task generation, duplicate prevention, and cross-student ownership isolation
- `AssessmentServiceTest`: Pre-submission answer withholding and server-side evaluation
- `FeedbackServiceTest`: 1–5 rating validation and transactional persistence
- `PaymentServiceTest`: Authoritative catalog pricing and demo status transitions
- `ChatbotServiceTest`: Knowledge base keyword matching and fallback handling
- `SearchServiceTest`: Multi-entity keyword querying

---

## 8. Windows Troubleshooting Guide

| Issue | Root Cause | Solution |
|---|---|---|
| `'java' is not recognized` | Java is not in your Windows `PATH` | Set `JAVA_HOME` to `C:\Program Files\Eclipse Adoptium\jdk-21...` and append `%JAVA_HOME%\bin` to system `Path`. |
| `Communications link failure` | MySQL is not running or wrong password | Run `net start MySQL80` or verify `$env:DB_PASSWORD="your_password"`. |
| `Port 8080 already in use` | Another program (Tomcat, Jenkins) is using port 8080 | Change `server.port=8081` in `application.properties`. |
| `Access Denied for user 'root'@'localhost'` | MySQL password mismatch | Reset MySQL root password or configure correct password in `.env`. |

---

## 9. Production Deployment Guide

To package into an executable standalone `.jar`:
```powershell
.\mvnw.cmd clean package -DskipTests
```
Run as a production service:
```powershell
java -jar target/placenza-platform-1.0.0.jar --server.port=8080
```
