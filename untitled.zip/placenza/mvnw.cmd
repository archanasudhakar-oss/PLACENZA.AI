@REM ----------------------------------------------------------------------------
@REM Maven Start Up Batch script for Placenza AI
@REM ----------------------------------------------------------------------------
@echo off
@setlocal

set ERROR_CODE=0

@REM Check JAVA_HOME
if "%JAVA_HOME%"=="" (
  echo Error: JAVA_HOME is not set and no 'java' command could be found in your PATH.
  echo Please set the JAVA_HOME variable in your environment to match the
  echo location of your Java installation.
  goto error
)

set MAVEN_PROJECTBASEDIR=%~dp0
set MAVEN_CMD_LINE_ARGS=%*

if exist "%MAVEN_PROJECTBASEDIR%\.mvn\wrapper\maven-wrapper.jar" (
  "%JAVA_HOME%\bin\java.exe" -jar "%MAVEN_PROJECTBASEDIR%\.mvn\wrapper\maven-wrapper.jar" %MAVEN_CMD_LINE_ARGS%
  goto end
) else (
  echo Maven wrapper jar not found. Attempting to use system maven...
  mvn %MAVEN_CMD_LINE_ARGS%
  goto end
)

:error
set ERROR_CODE=1

:end
@endlocal & set ERROR_CODE=%ERROR_CODE%
exit /B %ERROR_CODE%
