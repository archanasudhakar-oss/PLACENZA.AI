import React, { useState } from 'react';
import {
  Cpu,
  Sparkles,
  Download,
  CheckCircle2,
  Folder,
  FileText,
  Terminal,
  ShieldCheck,
  Layers,
  Search,
  MessageSquare,
  Award,
  BookOpen,
  ChevronRight,
  Eye,
  EyeOff,
  RefreshCw,
  Play,
  Check,
  ExternalLink,
  Database,
  Code,
  CreditCard,
  Star,
  User,
  ListOrdered,
  AlertTriangle
} from 'lucide-react';

export default function App() {
  const [activeTab, setActiveTab] = useState<'preview' | 'architecture' | 'schema' | 'tests' | 'setup'>('preview');

  // Interactive Live Simulator States
  const [techScore, setTechScore] = useState<number>(85);
  const [aptScore, setAptScore] = useState<number>(75);
  const [interviewCount, setInterviewCount] = useState<number>(8);
  const [roadmapPct, setRoadmapPct] = useState<number>(65);
  const [profilePct, setProfilePct] = useState<number>(90);
  const [isProvisional, setIsProvisional] = useState<boolean>(false);

  // Chatbot Simulator
  const [chatMessages, setChatMessages] = useState<Array<{ sender: 'user' | 'bot'; text: string; topic?: string }>>([
    {
      sender: 'bot',
      topic: 'Java & OOP Fundamentals',
      text: 'Hello! I am the PLACENZA AI Placement Assistant. I am powered by rule-based Java knowledge without external AI APIs. Ask me about Java OOP, Collections, SQL, DBMS, DSA, or the STAR interview method!'
    }
  ]);
  const [chatInput, setChatInput] = useState('');

  // Interactive Roadmap Tasks
  const [tasks, setTasks] = useState([
    { id: 1, title: 'Core OOP & Java Language Mastery', priority: 'HIGH', skill: 'Java', hours: 6, completed: true },
    { id: 2, title: 'Relational Schema Design & 3NF Normalization', priority: 'HIGH', skill: 'SQL & DBMS', hours: 5, completed: true },
    { id: 3, title: 'DSA: Two Pointers & HashMaps (20 Problems)', priority: 'HIGH', skill: 'DSA', hours: 8, completed: false },
    { id: 4, title: 'Spring Boot Architecture & RESTful APIs', priority: 'MEDIUM', skill: 'Spring Boot', hours: 7, completed: false },
    { id: 5, title: 'Quantitative Speed Drills (Work-Rate & Profit/Loss)', priority: 'MEDIUM', skill: 'Aptitude', hours: 4, completed: false },
    { id: 6, title: 'HR Behavioral Prep: 5 STAR Stories Drafted', priority: 'LOW', skill: 'HR Interviews', hours: 3, completed: false }
  ]);

  // Flashcard Reveal
  const [revealedAnswers, setRevealedAnswers] = useState<Record<number, boolean>>({});

  // Demo Payment
  const [demoTxn, setDemoTxn] = useState<{ ref: string; item: string; amount: string; status: string } | null>(null);

  // Calculate Weighted Placement Readiness Score (Transparent Formula from Section 21)
  const interviewScoreRaw = Math.min(100, (interviewCount / 10) * 100);
  const weightedTech = (techScore * 0.40);
  const weightedApt = (aptScore * 0.20);
  const weightedInterview = (interviewScoreRaw * 0.20);
  const weightedRoadmap = (roadmapPct * 0.10);
  const weightedProfile = (profilePct * 0.10);
  const overallReadiness = Math.round((weightedTech + weightedApt + weightedInterview + weightedRoadmap + weightedProfile) * 10) / 10;

  // Toggle Roadmap Task
  const toggleTask = (id: number) => {
    setTasks(prev => {
      const updated = prev.map(t => t.id === id ? { ...t, completed: !t.completed } : t);
      const completedCount = updated.filter(t => t.completed).length;
      setRoadmapPct(Math.round((completedCount / updated.length) * 100));
      return updated;
    });
  };

  // Rule-based Chatbot Simulation (Mirroring ChatbotService.java)
  const handleSendMessage = (msgToSend?: string) => {
    const query = (msgToSend || chatInput).trim();
    if (!query) return;

    const newMsgs = [...chatMessages, { sender: 'user' as const, text: query }];
    setChatMessages(newMsgs);
    if (!msgToSend) setChatInput('');

    const queryLower = query.toLowerCase();
    let reply = '';
    let topic = 'Placement Assistance';

    if (queryLower.includes('oop') || queryLower.includes('polymorphism') || queryLower.includes('inheritance')) {
      topic = 'OOP Principles in Java';
      reply = 'The 4 OOP pillars in Java:\n1. Encapsulation: Restricting direct field access using private modifiers and getter/setters.\n2. Abstraction: Expressing core interface contracts via interfaces and abstract classes.\n3. Inheritance: Reusing logic with "extends" keyword.\n4. Polymorphism: Compile-time (Method Overloading) and Runtime (Method Overriding with dynamic dispatch).';
    } else if (queryLower.includes('hashmap') || queryLower.includes('concurrent') || queryLower.includes('collection')) {
      topic = 'Java Collections Framework';
      reply = 'HashMap is non-synchronized and permits null keys. Collections.synchronizedMap uses a coarse table lock. ConcurrentHashMap uses bucket-level locks and CAS operations (Java 8 red-black trees above 8 nodes), offering superior multi-threaded throughput.';
    } else if (queryLower.includes('score') || queryLower.includes('readiness') || queryLower.includes('formula')) {
      topic = 'Readiness Score Transparency';
      reply = 'Placenza AI uses transparent weighted scoring:\n- Technical Skill Assessments: 40%\n- Aptitude & Quantitative: 20%\n- Interview Practice Records: 20%\n- Roadmap Task Milestones: 10%\n- Profile Completion: 10%\nProvisional tag is shown if technical or aptitude exams are unattempted.';
    } else if (queryLower.includes('star') || queryLower.includes('hr') || queryLower.includes('behavioral')) {
      topic = 'HR Behavioral STAR Method';
      reply = 'Structure your answers using STAR:\n- Situation: Describe the academic or project challenge.\n- Task: Define your specific responsibility.\n- Action: State the exact technical steps YOU executed.\n- Result: Quantify measurable impact (e.g. "Reduced query latency by 60%").';
    } else if (queryLower.includes('acid') || queryLower.includes('sql') || queryLower.includes('normalization')) {
      topic = 'Relational DBMS & SQL';
      reply = 'ACID Guarantees:\n- Atomicity: Transaction executes completely or rolls back.\n- Consistency: Preserves foreign keys and schema constraints.\n- Isolation: Prevents dirty reads and phantom rows.\n- Durability: Committed write-ahead logs survive crash recovery.';
    } else {
      topic = 'Knowledge Base Guidance';
      reply = 'I am the rule-based Placenza assistant. I can answer inquiries regarding Java Fundamentals, OOP, Collections, SQL, ACID, DSA complexity, Aptitude shortcuts, and the STAR interview method.';
    }

    setTimeout(() => {
      setChatMessages([...newMsgs, { sender: 'bot', text: reply, topic }]);
    }, 300);
  };

  return (
    <div className="min-h-screen bg-[#0B1020] text-[#F8FAFC] font-sans antialiased flex flex-col selection:bg-[#8B5CF6]/30">
      {/* TOP NOTIFICATION / EXPORT BAR */}
      <header className="border-b border-white/10 bg-[#11182B]/90 backdrop-blur-md sticky top-0 z-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 py-3 flex flex-wrap items-center justify-between gap-4">
          <div className="flex items-center gap-3">
            <div className="w-9 h-9 rounded-xl bg-[#8B5CF6]/20 border border-[#8B5CF6]/40 flex items-center justify-center text-[#8B5CF6]">
              <Cpu className="w-5 h-5" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <span className="font-extrabold text-lg tracking-tight text-white">PLACENZA<span className="text-[#22D3EE]">.AI</span></span>
                <span className="text-xs px-2 py-0.5 rounded-full bg-[#8B5CF6]/15 text-[#C4B5FD] font-semibold border border-[#8B5CF6]/30">
                  Java Full-Stack Capstone
                </span>
              </div>
              <p className="text-xs text-[#A7B1C8] hidden sm:block">
                "Your Potential. Your Preparation. Your Placement."
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2.5">
            <a
              href="/placenza-fullstack-java.zip"
              download="placenza-fullstack-java.zip"
              className="flex items-center gap-2 bg-gradient-to-r from-[#8B5CF6] to-[#7C3AED] hover:from-[#7C3AED] hover:to-[#6D28D9] text-white px-4 py-2 rounded-lg text-sm font-semibold shadow-lg shadow-[#8B5CF6]/25 transition-all hover:-translate-y-0.5"
            >
              <Download className="w-4 h-4" />
              <span>Download Full Project ZIP</span>
              <span className="text-xs bg-white/20 px-1.5 py-0.5 rounded font-mono">172 KB</span>
            </a>
          </div>
        </div>

        {/* NAVIGATION TABS */}
        <div className="max-w-7xl mx-auto px-4 sm:px-6 flex gap-1 border-t border-white/5 overflow-x-auto text-sm">
          <button
            onClick={() => setActiveTab('preview')}
            className={`py-2.5 px-4 font-medium border-b-2 transition-colors flex items-center gap-2 whitespace-nowrap ${
              activeTab === 'preview'
                ? 'border-[#22D3EE] text-[#22D3EE]'
                : 'border-transparent text-[#A7B1C8] hover:text-white'
            }`}
          >
            <Play className="w-4 h-4" />
            Interactive Platform Simulator
          </button>
          <button
            onClick={() => setActiveTab('architecture')}
            className={`py-2.5 px-4 font-medium border-b-2 transition-colors flex items-center gap-2 whitespace-nowrap ${
              activeTab === 'architecture'
                ? 'border-[#8B5CF6] text-[#8B5CF6]'
                : 'border-transparent text-[#A7B1C8] hover:text-white'
            }`}
          >
            <Code className="w-4 h-4" />
            Java 21 & Spring Architecture (152 Files)
          </button>
          <button
            onClick={() => setActiveTab('schema')}
            className={`py-2.5 px-4 font-medium border-b-2 transition-colors flex items-center gap-2 whitespace-nowrap ${
              activeTab === 'schema'
                ? 'border-[#22D3EE] text-[#22D3EE]'
                : 'border-transparent text-[#A7B1C8] hover:text-white'
            }`}
          >
            <Database className="w-4 h-4" />
            MySQL 8 Relational Schema
          </button>
          <button
            onClick={() => setActiveTab('tests')}
            className={`py-2.5 px-4 font-medium border-b-2 transition-colors flex items-center gap-2 whitespace-nowrap ${
              activeTab === 'tests'
                ? 'border-[#34D399] text-[#34D399]'
                : 'border-transparent text-[#A7B1C8] hover:text-white'
            }`}
          >
            <ShieldCheck className="w-4 h-4" />
            Automated JUnit 5 Test Suite
          </button>
          <button
            onClick={() => setActiveTab('setup')}
            className={`py-2.5 px-4 font-medium border-b-2 transition-colors flex items-center gap-2 whitespace-nowrap ${
              activeTab === 'setup'
                ? 'border-[#FBBF24] text-[#FBBF24]'
                : 'border-transparent text-[#A7B1C8] hover:text-white'
            }`}
          >
            <Terminal className="w-4 h-4" />
            Windows Setup & Run Commands
          </button>
        </div>
      </header>

      {/* MAIN CONTENT AREA */}
      <main className="flex-1 max-w-7xl w-full mx-auto p-4 sm:p-6">
        {/* ==============================================================
            TAB 1: INTERACTIVE PLATFORM SIMULATOR
            ============================================================== */}
        {activeTab === 'preview' && (
          <div className="space-y-6">
            {/* HERO BANNER */}
            <div className="p-6 sm:p-8 rounded-2xl bg-gradient-to-r from-[#171F35] via-[#11182B] to-[#171F35] border border-white/10 relative overflow-hidden">
              <div className="relative z-10 max-w-3xl">
                <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-[#8B5CF6]/15 border border-[#8B5CF6]/30 text-[#C4B5FD] text-xs font-semibold mb-3">
                  <Sparkles className="w-3.5 h-3.5 text-[#22D3EE]" />
                  College Capstone Live Verification & Evaluation Engine
                </div>
                <h1 className="text-2xl sm:text-4xl font-extrabold text-white mb-2 leading-tight">
                  Your Career Deserves a <span className="bg-gradient-to-r from-white via-[#C4B5FD] to-[#22D3EE] bg-clip-text text-transparent">Smarter Start.</span>
                </h1>
                <p className="text-sm sm:text-base text-[#A7B1C8] mb-4">
                  Discover your strengths, close your skill gaps, and prepare for campus placements with a personalized roadmap designed around your career goals.
                </p>
                <div className="flex flex-wrap items-center gap-3">
                  <span className="text-xs px-2.5 py-1 rounded bg-[#34D399]/15 text-[#34D399] border border-[#34D399]/30 font-medium flex items-center gap-1.5">
                    <CheckCircle2 className="w-3.5 h-3.5" /> Java 21 / Spring Boot 3.3.4
                  </span>
                  <span className="text-xs px-2.5 py-1 rounded bg-[#22D3EE]/15 text-[#22D3EE] border border-[#22D3EE]/30 font-medium flex items-center gap-1.5">
                    <Database className="w-3.5 h-3.5" /> MySQL 8.x Relational Schema
                  </span>
                  <span className="text-xs px-2.5 py-1 rounded bg-[#8B5CF6]/15 text-[#C4B5FD] border border-[#8B5CF6]/30 font-medium flex items-center gap-1.5">
                    <ShieldCheck className="w-3.5 h-3.5" /> Spring Security 6 & RBAC
                  </span>
                </div>
              </div>
            </div>

            {/* SIMULATOR GRID */}
            <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
              {/* LEFT 7 COLS: READINESS SCORE CALCULATOR */}
              <div className="lg:col-span-7 bg-[#171F35] border border-white/10 rounded-2xl p-5 sm:p-6 space-y-5">
                <div className="flex items-center justify-between">
                  <div>
                    <h2 className="text-lg font-bold text-white flex items-center gap-2">
                      <Award className="w-5 h-5 text-[#8B5CF6]" />
                      Transparent Placement Readiness Score
                    </h2>
                    <p className="text-xs text-[#A7B1C8]">Interactive simulation of the formula implemented in <code>ReadinessScoreService.java</code></p>
                  </div>
                  <button
                    onClick={() => setIsProvisional(!isProvisional)}
                    className={`text-xs px-2.5 py-1 rounded-full border font-semibold transition-all ${
                      isProvisional
                        ? 'bg-[#FB7185]/15 text-[#FB7185] border-[#FB7185]/40'
                        : 'bg-[#34D399]/15 text-[#34D399] border-[#34D399]/40'
                    }`}
                  >
                    {isProvisional ? '● Provisional State' : '● Verified Index'}
                  </button>
                </div>

                {/* GAUGE & METRICS */}
                <div className="flex flex-col sm:flex-row items-center gap-6 p-4 rounded-xl bg-[#11182B] border border-white/5">
                  <div className="relative w-32 h-32 rounded-full flex items-center justify-center border-4 border-white/10"
                       style={{
                         background: `conic-gradient(#8B5CF6 ${overallReadiness * 3.6}deg, rgba(255,255,255,0.06) 0deg)`
                       }}>
                    <div className="w-24 h-24 rounded-full bg-[#171F35] flex flex-col items-center justify-center">
                      <span className="text-2xl font-extrabold text-white">{isProvisional ? '—' : overallReadiness}</span>
                      <span className="text-[10px] text-[#A7B1C8]">{isProvisional ? 'Provisional' : 'out of 100'}</span>
                    </div>
                  </div>

                  <div className="flex-1 w-full space-y-2 text-xs">
                    <div className="flex justify-between text-[#A7B1C8]">
                      <span>Technical Assessments (40% Weight)</span>
                      <strong className="text-white">{weightedTech.toFixed(1)} / 40.0 pts ({techScore}%)</strong>
                    </div>
                    <div className="h-1.5 w-full bg-white/5 rounded-full overflow-hidden">
                      <div className="h-full bg-[#8B5CF6] rounded-full transition-all duration-300" style={{ width: `${techScore}%` }}></div>
                    </div>

                    <div className="flex justify-between text-[#A7B1C8]">
                      <span>Aptitude & Reasoning (20% Weight)</span>
                      <strong className="text-white">{weightedApt.toFixed(1)} / 20.0 pts ({aptScore}%)</strong>
                    </div>
                    <div className="h-1.5 w-full bg-white/5 rounded-full overflow-hidden">
                      <div className="h-full bg-[#22D3EE] rounded-full transition-all duration-300" style={{ width: `${aptScore}%` }}></div>
                    </div>

                    <div className="flex justify-between text-[#A7B1C8]">
                      <span>Interview Practice (20% Weight)</span>
                      <strong className="text-white">{weightedInterview.toFixed(1)} / 20.0 pts ({interviewCount} answered)</strong>
                    </div>
                    <div className="h-1.5 w-full bg-white/5 rounded-full overflow-hidden">
                      <div className="h-full bg-[#34D399] rounded-full transition-all duration-300" style={{ width: `${interviewScoreRaw}%` }}></div>
                    </div>

                    <div className="flex justify-between text-[#A7B1C8]">
                      <span>Roadmap Milestones (10% Weight)</span>
                      <strong className="text-white">{weightedRoadmap.toFixed(1)} / 10.0 pts ({roadmapPct}%)</strong>
                    </div>
                    <div className="h-1.5 w-full bg-white/5 rounded-full overflow-hidden">
                      <div className="h-full bg-[#FBBF24] rounded-full transition-all duration-300" style={{ width: `${roadmapPct}%` }}></div>
                    </div>
                  </div>
                </div>

                {/* FORMULA SLIDERS */}
                <div className="space-y-3 pt-2 border-t border-white/5 text-xs">
                  <div className="flex items-center justify-between gap-4">
                    <label className="text-[#A7B1C8] w-48">Simulate Tech Score ({techScore}%):</label>
                    <input
                      type="range"
                      min="0"
                      max="100"
                      value={techScore}
                      onChange={e => setTechScore(Number(e.target.value))}
                      className="flex-1 accent-[#8B5CF6]"
                    />
                  </div>
                  <div className="flex items-center justify-between gap-4">
                    <label className="text-[#A7B1C8] w-48">Simulate Aptitude Score ({aptScore}%):</label>
                    <input
                      type="range"
                      min="0"
                      max="100"
                      value={aptScore}
                      onChange={e => setAptScore(Number(e.target.value))}
                      className="flex-1 accent-[#22D3EE]"
                    />
                  </div>
                  <div className="flex items-center justify-between gap-4">
                    <label className="text-[#A7B1C8] w-48">Interview Questions ({interviewCount} / 10):</label>
                    <input
                      type="range"
                      min="0"
                      max="10"
                      value={interviewCount}
                      onChange={e => setInterviewCount(Number(e.target.value))}
                      className="flex-1 accent-[#34D399]"
                    />
                  </div>
                </div>

                {isProvisional && (
                  <div className="p-3 rounded-lg bg-[#FB7185]/10 border border-[#FB7185]/30 text-xs text-[#FB7185] flex items-center gap-2">
                    <AlertTriangle className="w-4 h-4 flex-shrink-0" />
                    <span>Provisional Warning: Required technical or aptitude assessment missing. Candidates must complete diagnostics to verify standing.</span>
                  </div>
                )}
              </div>

              {/* RIGHT 5 COLS: CHATBOT SIMULATOR */}
              <div className="lg:col-span-5 bg-[#171F35] border border-white/10 rounded-2xl p-5 sm:p-6 flex flex-col justify-between space-y-4">
                <div>
                  <div className="flex items-center justify-between mb-3">
                    <h3 className="text-base font-bold text-white flex items-center gap-2">
                      <MessageSquare className="w-4 h-4 text-[#22D3EE]" />
                      Rule-Based AI Assistant
                    </h3>
                    <span className="text-[10px] px-2 py-0.5 rounded bg-white/5 text-[#A7B1C8]">ChatbotService.java</span>
                  </div>

                  {/* MESSAGES SCROLL */}
                  <div className="space-y-3 h-64 overflow-y-auto pr-1 text-xs">
                    {chatMessages.map((m, idx) => (
                      <div
                        key={idx}
                        className={`p-3 rounded-xl max-w-[88%] leading-relaxed ${
                          m.sender === 'user'
                            ? 'ml-auto bg-[#8B5CF6] text-white rounded-br-none'
                            : 'bg-[#11182B] text-[#F8FAFC] border border-[#8B5CF6]/20 rounded-bl-none'
                        }`}
                      >
                        {m.topic && m.sender === 'bot' && (
                          <div className="text-[10px] text-[#22D3EE] font-bold mb-1 uppercase tracking-wider">{m.topic}</div>
                        )}
                        <p className="whitespace-pre-line">{m.text}</p>
                      </div>
                    ))}
                  </div>
                </div>

                <div className="space-y-2">
                  <div className="flex flex-wrap gap-1.5">
                    <button
                      onClick={() => handleSendMessage('Explain OOP concepts in Java')}
                      className="text-[10px] px-2 py-1 rounded bg-[#11182B] hover:bg-white/10 text-[#C4B5FD] border border-white/10 transition-colors"
                    >
                      OOP Concepts
                    </button>
                    <button
                      onClick={() => handleSendMessage('What are ACID properties in SQL?')}
                      className="text-[10px] px-2 py-1 rounded bg-[#11182B] hover:bg-white/10 text-[#C4B5FD] border border-white/10 transition-colors"
                    >
                      ACID Properties
                    </button>
                    <button
                      onClick={() => handleSendMessage('How does STAR work for HR?')}
                      className="text-[10px] px-2 py-1 rounded bg-[#11182B] hover:bg-white/10 text-[#C4B5FD] border border-white/10 transition-colors"
                    >
                      STAR Method
                    </button>
                  </div>

                  <div className="flex gap-2">
                    <input
                      type="text"
                      value={chatInput}
                      onChange={e => setChatInput(e.target.value)}
                      onKeyDown={e => e.key === 'Enter' && handleSendMessage()}
                      placeholder="Ask CS, SQL, DSA, or interview question..."
                      className="flex-1 bg-[#11182B] border border-white/10 rounded-lg px-3 py-2 text-xs text-white focus:outline-none focus:border-[#8B5CF6]"
                    />
                    <button
                      onClick={() => handleSendMessage()}
                      className="bg-[#8B5CF6] hover:bg-[#7C3AED] text-white px-3 py-2 rounded-lg text-xs font-semibold"
                    >
                      Ask
                    </button>
                  </div>
                </div>
              </div>
            </div>

            {/* ROADMAP & INTERVIEW QUESTIONS ROW */}
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              {/* ROADMAP TASK CHECKLIST */}
              <div className="bg-[#171F35] border border-white/10 rounded-2xl p-5 sm:p-6 space-y-4">
                <div className="flex items-center justify-between">
                  <div>
                    <h3 className="text-base font-bold text-white flex items-center gap-2">
                      <ListOrdered className="w-4 h-4 text-[#22D3EE]" />
                      Personalized Roadmap Milestone Tasks
                    </h3>
                    <p className="text-xs text-[#A7B1C8]">Toggle tasks to verify real-time completion updates and progress syncing</p>
                  </div>
                  <span className="text-xs font-bold text-[#22D3EE]">{roadmapPct}% Complete</span>
                </div>

                <div className="space-y-2">
                  {tasks.map(t => (
                    <div
                      key={t.id}
                      onClick={() => toggleTask(t.id)}
                      className={`p-3 rounded-xl border transition-all cursor-pointer flex items-center justify-between text-xs ${
                        t.completed
                          ? 'bg-[#11182B]/60 border-[#34D399]/30 text-[#A7B1C8]'
                          : 'bg-[#11182B] border-white/10 text-white hover:border-[#8B5CF6]/40'
                      }`}
                    >
                      <div className="flex items-center gap-3">
                        <div className={`w-5 h-5 rounded-md flex items-center justify-center border ${
                          t.completed ? 'bg-[#34D399] border-[#34D399] text-white' : 'border-white/20'
                        }`}>
                          {t.completed && <Check className="w-3.5 h-3.5 stroke-[3]" />}
                        </div>
                        <div>
                          <span className={`font-semibold ${t.completed ? 'line-through text-[#A7B1C8]' : 'text-white'}`}>
                            {t.title}
                          </span>
                          <div className="flex items-center gap-2 text-[10px] text-[#A7B1C8] mt-0.5">
                            <span>{t.skill}</span>
                            <span>•</span>
                            <span>{t.hours} hrs</span>
                          </div>
                        </div>
                      </div>

                      <span className={`px-2 py-0.5 rounded text-[10px] font-bold ${
                        t.priority === 'HIGH' ? 'bg-[#FB7185]/20 text-[#FB7185]' :
                        t.priority === 'MEDIUM' ? 'bg-[#FBBF24]/20 text-[#FBBF24]' : 'bg-white/10 text-white'
                      }`}>
                        {t.priority}
                      </span>
                    </div>
                  ))}
                </div>
              </div>

              {/* INTERVIEW PRACTICE FLASHCARD */}
              <div className="bg-[#171F35] border border-white/10 rounded-2xl p-5 sm:p-6 space-y-4">
                <div className="flex items-center justify-between">
                  <div>
                    <h3 className="text-base font-bold text-white flex items-center gap-2">
                      <BookOpen className="w-4 h-4 text-[#34D399]" />
                      Interview Practice & Reference Reveal
                    </h3>
                    <p className="text-xs text-[#A7B1C8]">Curated questions with collapsible model answers (Section 22)</p>
                  </div>
                </div>

                <div className="space-y-3">
                  {[
                    {
                      id: 1,
                      q: 'How does Garbage Collection operate in Java, and what are Generational Hypotheses?',
                      ans: 'Java GC divides heap into Young Generation (Eden, S0, S1) and Old Generation. Weak generational hypothesis dictates that most objects die young. Surviving objects get tenured to Old generation where Major GC runs.',
                      cat: 'Java Programming',
                      diff: 'INTERMEDIATE'
                    },
                    {
                      id: 2,
                      q: 'Why are B+ Trees preferred over Binary Search Trees in Database Indexing?',
                      ans: 'B+ Trees have massive branching factor (fanout), minimizing costly disk I/O operations by keeping tree height low (3-4 levels for millions of records). All data records are in linked leaf nodes, making range queries sequential.',
                      cat: 'SQL & DBMS',
                      diff: 'ADVANCED'
                    }
                  ].map(item => (
                    <div key={item.id} className="p-4 rounded-xl bg-[#11182B] border border-white/10 space-y-3">
                      <div className="flex justify-between items-center text-xs">
                        <span className="text-xs font-semibold px-2 py-0.5 rounded bg-[#8B5CF6]/20 text-[#C4B5FD]">
                          {item.cat}
                        </span>
                        <span className="text-[10px] text-[#A7B1C8]">{item.diff}</span>
                      </div>

                      <h4 className="text-sm font-semibold text-white">{item.q}</h4>

                      <button
                        onClick={() => setRevealedAnswers(prev => ({ ...prev, [item.id]: !prev[item.id] }))}
                        className="text-xs flex items-center gap-1.5 text-[#22D3EE] hover:underline"
                      >
                        {revealedAnswers[item.id] ? <EyeOff className="w-3.5 h-3.5" /> : <Eye className="w-3.5 h-3.5" />}
                        {revealedAnswers[item.id] ? 'Hide Reference Answer' : 'Reveal Reference Answer'}
                      </button>

                      {revealedAnswers[item.id] && (
                        <div className="p-3 rounded-lg bg-[#171F35] border border-white/5 text-xs text-[#A7B1C8] leading-relaxed">
                          <strong className="text-white block mb-1">Model Response:</strong>
                          {item.ans}
                        </div>
                      )}
                    </div>
                  ))}
                </div>
              </div>
            </div>

            {/* DEMO TRANSACTION SIMULATION BANNER */}
            <div className="p-5 rounded-2xl bg-[#171F35] border border-white/10 flex flex-col sm:flex-row items-center justify-between gap-4">
              <div>
                <div className="flex items-center gap-2 mb-1">
                  <CreditCard className="w-4 h-4 text-[#FBBF24]" />
                  <span className="font-bold text-sm text-white">Demonstration Purchase Simulation (Section 15 & 16)</span>
                  <span className="text-[10px] px-2 py-0.5 rounded bg-[#FBBF24]/15 text-[#FBBF24] font-bold">DEMO SIMULATION</span>
                </div>
                <p className="text-xs text-[#A7B1C8]">
                  Authoritative server-side pricing catalog tests transaction status persistence without real card credentials.
                </p>
                {demoTxn && (
                  <div className="mt-2 text-xs text-[#34D399] font-mono">
                    ✓ Simulated Success: {demoTxn.item} ({demoTxn.amount}) Ref: {demoTxn.ref} [Status: {demoTxn.status}]
                  </div>
                )}
              </div>

              <button
                onClick={() => {
                  const ref = 'TXN-DEMO-' + Math.random().toString(36).substring(2, 8).toUpperCase();
                  setDemoTxn({
                    ref,
                    item: '1-on-1 Mock Interview Pro',
                    amount: 'INR 499.00',
                    status: 'SUCCESSFUL'
                  });
                }}
                className="bg-[#22D3EE] hover:bg-[#06B6D4] text-[#0B1020] px-4 py-2 rounded-lg text-xs font-bold transition-all whitespace-nowrap"
              >
                Simulate Demo Transaction (₹499)
              </button>
            </div>
          </div>
        )}

        {/* ==============================================================
            TAB 2: JAVA ARCHITECTURE & CODEBASE EXPLORER
            ============================================================== */}
        {activeTab === 'architecture' && (
          <div className="space-y-6">
            <div className="bg-[#171F35] border border-white/10 rounded-2xl p-6">
              <h2 className="text-lg font-bold text-white mb-2 flex items-center gap-2">
                <Code className="w-5 h-5 text-[#8B5CF6]" />
                Java Full-Stack Project Structure (`placenza/`)
              </h2>
              <p className="text-xs text-[#A7B1C8] mb-4">
                Total 152 files organized in conventional Maven layout compliant with Spring Boot 3 standards.
              </p>

              <div className="grid grid-cols-1 md:grid-cols-3 gap-4 text-xs font-mono">
                <div className="p-4 rounded-xl bg-[#11182B] border border-white/5 space-y-2">
                  <span className="text-[#8B5CF6] font-bold block flex items-center gap-1.5">
                    <Folder className="w-4 h-4" /> com.placenza.entity (18 Entities)
                  </span>
                  <ul className="text-[#A7B1C8] space-y-1 pl-4 list-disc">
                    <li>User.java & Role.java</li>
                    <li>UserProfile.java</li>
                    <li>Category.java & Skill.java</li>
                    <li>Question.java & Difficulty.java</li>
                    <li>Assessment.java</li>
                    <li>AssessmentAttempt.java</li>
                    <li>AssessmentAnswer.java</li>
                    <li>Roadmap.java & RoadmapTask.java</li>
                    <li>InterviewQuestion.java</li>
                    <li>InterviewPracticeRecord.java</li>
                    <li>Feedback.java</li>
                    <li>Purchase.java & PaymentTransaction.java</li>
                    <li>OtpVerification.java</li>
                    <li>ActivityRecord.java</li>
                  </ul>
                </div>

                <div className="p-4 rounded-xl bg-[#11182B] border border-white/5 space-y-2">
                  <span className="text-[#22D3EE] font-bold block flex items-center gap-1.5">
                    <Folder className="w-4 h-4" /> com.placenza.service (13 Services)
                  </span>
                  <ul className="text-[#A7B1C8] space-y-1 pl-4 list-disc">
                    <li>UserService.java</li>
                    <li>OtpService.java (BCrypt hash)</li>
                    <li>CategoryService.java</li>
                    <li>AssessmentService.java</li>
                    <li>ReadinessScoreService.java (40/20/20/10/10)</li>
                    <li>SkillGapAnalysisService.java</li>
                    <li>RoadmapService.java</li>
                    <li>InterviewPracticeService.java</li>
                    <li>SearchService.java (JPA queries)</li>
                    <li>FeedbackService.java (1-5 range)</li>
                    <li>PaymentService.java (Authoritative pricing)</li>
                    <li>ChatbotService.java (Rule KB)</li>
                    <li>DataInitializerService.java</li>
                  </ul>
                </div>

                <div className="p-4 rounded-xl bg-[#11182B] border border-white/5 space-y-2">
                  <span className="text-[#34D399] font-bold block flex items-center gap-1.5">
                    <Folder className="w-4 h-4" /> com.placenza.controller (18 Controllers)
                  </span>
                  <ul className="text-[#A7B1C8] space-y-1 pl-4 list-disc">
                    <li>HomeController.java (Landing & Public)</li>
                    <li>AuthController.java (Login, Reg, 2FA)</li>
                    <li>DashboardController.java</li>
                    <li>AssessmentController.java</li>
                    <li>RoadmapController.java</li>
                    <li>InterviewPracticeController.java</li>
                    <li>SearchController.java</li>
                    <li>FeedbackController.java</li>
                    <li>PaymentController.java</li>
                    <li>ChatbotController.java</li>
                    <li>AdminController.java</li>
                    <li>ApiCategoryController.java</li>
                    <li>ApiAssessmentController.java</li>
                    <li>ApiRoadmapController.java</li>
                    <li>ApiPaymentController.java</li>
                  </ul>
                </div>
              </div>

              {/* POM.XML HIGHLIGHT */}
              <div className="mt-6 p-4 rounded-xl bg-[#11182B] border border-white/5">
                <span className="text-xs text-white font-bold block mb-2">placenza/pom.xml Excerpt:</span>
                <pre className="text-[11px] text-[#C4B5FD] overflow-x-auto p-3 bg-[#0B1020] rounded border border-white/5 font-mono">
{`<parent>
    <groupId>org.springframework.boot</groupId>
    <artifactId>spring-boot-starter-parent</artifactId>
    <version>3.3.4</version>
</parent>
<properties>
    <java.version>21</java.version>
</properties>
<dependencies>
    <dependency>spring-boot-starter-web</dependency>
    <dependency>spring-boot-starter-thymeleaf</dependency>
    <dependency>thymeleaf-extras-springsecurity6</dependency>
    <dependency>spring-boot-starter-data-jpa</dependency>
    <dependency>spring-boot-starter-security</dependency>
    <dependency>spring-boot-starter-validation</dependency>
    <dependency>mysql-connector-j</dependency>
</dependencies>`}
                </pre>
              </div>
            </div>
          </div>
        )}

        {/* ==============================================================
            TAB 3: MYSQL 8 RELATIONAL SCHEMA
            ============================================================== */}
        {activeTab === 'schema' && (
          <div className="space-y-6">
            <div className="bg-[#171F35] border border-white/10 rounded-2xl p-6">
              <div className="flex items-center justify-between mb-3">
                <h2 className="text-lg font-bold text-white flex items-center gap-2">
                  <Database className="w-5 h-5 text-[#22D3EE]" />
                  MySQL 8.x Relational Schema (`schema.sql`)
                </h2>
                <span className="text-xs px-2.5 py-1 rounded bg-[#22D3EE]/15 text-[#22D3EE] font-mono">Database: placenza_db</span>
              </div>
              <p className="text-xs text-[#A7B1C8] mb-4">
                Structured with foreign key constraints, unique email indices, non-cascading audits, and transactional integrity.
              </p>

              <pre className="text-xs text-[#22D3EE] overflow-x-auto p-4 bg-[#11182B] rounded-xl border border-white/5 font-mono leading-relaxed max-h-[500px]">
{`-- 1. USERS TABLE
CREATE TABLE users (
    id BIGINT AUTO_INCREMENT PRIMARY KEY,
    email VARCHAR(191) NOT NULL UNIQUE,
    password_hash VARCHAR(255) NOT NULL,
    full_name VARCHAR(120) NOT NULL,
    role VARCHAR(30) NOT NULL DEFAULT 'ROLE_STUDENT',
    enabled BOOLEAN NOT NULL DEFAULT TRUE,
    two_factor_enabled BOOLEAN NOT NULL DEFAULT TRUE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    INDEX idx_users_email (email)
);

-- 2. USER PROFILES
CREATE TABLE user_profiles (
    id BIGINT AUTO_INCREMENT PRIMARY KEY,
    user_id BIGINT NOT NULL UNIQUE,
    college VARCHAR(180),
    degree VARCHAR(100),
    graduation_year INT,
    career_role VARCHAR(120),
    readiness_score DOUBLE DEFAULT 0.0,
    is_provisional BOOLEAN DEFAULT TRUE,
    CONSTRAINT fk_profile_user FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
);

-- 3. 12 SKILL CATEGORIES
CREATE TABLE categories (
    id BIGINT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(100) NOT NULL UNIQUE,
    slug VARCHAR(120) NOT NULL UNIQUE,
    description TEXT,
    icon VARCHAR(60),
    display_order INT DEFAULT 0
);

-- 4. ASSESSMENT & EXAM ANSWERS (SERVER-EVALUATED ONLY)
CREATE TABLE assessments (
    id BIGINT AUTO_INCREMENT PRIMARY KEY,
    title VARCHAR(180) NOT NULL,
    category_id BIGINT NOT NULL,
    duration_minutes INT NOT NULL DEFAULT 30,
    passing_score DOUBLE NOT NULL DEFAULT 60.0
);

-- 5. ROADMAPS & TASKS
CREATE TABLE roadmaps (
    id BIGINT AUTO_INCREMENT PRIMARY KEY,
    user_id BIGINT NOT NULL UNIQUE,
    target_role VARCHAR(120) NOT NULL,
    overall_progress DOUBLE DEFAULT 0.0
);

CREATE TABLE roadmap_tasks (
    id BIGINT AUTO_INCREMENT PRIMARY KEY,
    roadmap_id BIGINT NOT NULL,
    title VARCHAR(180) NOT NULL,
    related_skill VARCHAR(100),
    priority VARCHAR(30) DEFAULT 'MEDIUM',
    status VARCHAR(30) DEFAULT 'PENDING',
    CONSTRAINT fk_task_roadmap FOREIGN KEY (roadmap_id) REFERENCES roadmaps(id) ON DELETE CASCADE
);

-- 6. AUDITED SERVICE TRANSACTIONS
CREATE TABLE purchases (
    id BIGINT AUTO_INCREMENT PRIMARY KEY,
    purchase_reference VARCHAR(64) NOT NULL UNIQUE,
    user_id BIGINT NOT NULL,
    service_offering VARCHAR(120) NOT NULL,
    amount DECIMAL(10, 2) NOT NULL,
    status VARCHAR(30) DEFAULT 'INITIATED',
    payment_mode VARCHAR(30) DEFAULT 'DEMO_SIMULATION'
);`}
              </pre>
            </div>
          </div>
        )}

        {/* ==============================================================
            TAB 4: AUTOMATED TEST SUITE
            ============================================================== */}
        {activeTab === 'tests' && (
          <div className="space-y-6">
            <div className="bg-[#171F35] border border-white/10 rounded-2xl p-6">
              <div className="flex items-center justify-between mb-3">
                <h2 className="text-lg font-bold text-white flex items-center gap-2">
                  <ShieldCheck className="w-5 h-5 text-[#34D399]" />
                  Automated JUnit 5 Test Suite (Section 28)
                </h2>
                <span className="text-xs px-2.5 py-1 rounded bg-[#34D399]/15 text-[#34D399] font-mono">10 Test Classes</span>
              </div>
              <p className="text-xs text-[#A7B1C8] mb-4">
                Configured with Spring Boot Test and in-memory H2 (MySQL mode) for zero-dependency isolated verification.
              </p>

              <div className="space-y-3">
                {[
                  { name: 'PlacenzaApplicationTests.java', focus: 'Context initialization & dependency injection' },
                  { name: 'AuthServiceTest.java', focus: 'Candidate registration, duplicate email rejection, BCrypt strength' },
                  { name: 'ReadinessScoreServiceTest.java', focus: 'Weighted 40/20/20/10/10 formula & provisional state isolation' },
                  { name: 'RoadmapServiceTest.java', focus: 'Task generation, duplicate prevention, cross-student ownership isolation' },
                  { name: 'AssessmentServiceTest.java', focus: 'Omission of correct answers from exam paper & server-side scoring' },
                  { name: 'FeedbackServiceTest.java', focus: 'Rating 1–5 range validation, transactional commit' },
                  { name: 'PaymentServiceTest.java', focus: 'Authoritative pricing, tamper prevention, demo mode flag' },
                  { name: 'ChatbotServiceTest.java', focus: 'Java knowledge-base keyword matching & fallback response' },
                  { name: 'SearchServiceTest.java', focus: 'Multi-entity JPA parameterized queries & pagination' }
                ].map((t, idx) => (
                  <div key={idx} className="p-3 rounded-xl bg-[#11182B] border border-white/5 flex items-center justify-between text-xs">
                    <div className="flex items-center gap-2.5">
                      <CheckCircle2 className="w-4 h-4 text-[#34D399]" />
                      <span className="font-mono text-white font-semibold">{t.name}</span>
                    </div>
                    <span className="text-[#A7B1C8]">{t.focus}</span>
                  </div>
                ))}
              </div>

              <div className="mt-5 p-4 rounded-xl bg-[#11182B] border border-white/5">
                <span className="text-xs font-bold text-white block mb-1">To execute tests locally on Windows:</span>
                <code className="text-xs text-[#34D399] font-mono">.\mvnw.cmd test</code>
              </div>
            </div>
          </div>
        )}

        {/* ==============================================================
            TAB 5: WINDOWS SETUP & RUN INSTRUCTIONS
            ============================================================== */}
        {activeTab === 'setup' && (
          <div className="space-y-6">
            <div className="bg-[#171F35] border border-white/10 rounded-2xl p-6">
              <h2 className="text-lg font-bold text-white mb-2 flex items-center gap-2">
                <Terminal className="w-5 h-5 text-[#FBBF24]" />
                Windows Step-by-Step Execution Guide
              </h2>
              <p className="text-xs text-[#A7B1C8] mb-4">
                Exact Windows PowerShell commands to build and run the application for college evaluation.
              </p>

              <div className="space-y-4 text-xs font-mono">
                <div className="p-4 rounded-xl bg-[#11182B] border border-white/5 space-y-2">
                  <div className="text-white font-bold">Step 1: Extract ZIP & Verify Java 21</div>
                  <pre className="text-[#FBBF24] p-3 bg-[#0B1020] rounded border border-white/5 overflow-x-auto">
{`# 1. Unzip placenza-fullstack-java.zip
cd placenza

# 2. Verify Java 21
java -version
# Expected: openjdk version "21.x.x"`}
                  </pre>
                </div>

                <div className="p-4 rounded-xl bg-[#11182B] border border-white/5 space-y-2">
                  <div className="text-white font-bold">Step 2: Create MySQL Database</div>
                  <pre className="text-[#22D3EE] p-3 bg-[#0B1020] rounded border border-white/5 overflow-x-auto">
{`# Start MySQL service in Windows PowerShell
net start MySQL80

# Log in and create database
mysql -u root -p
CREATE DATABASE IF NOT EXISTS placenza_db;
EXIT;`}
                  </pre>
                </div>

                <div className="p-4 rounded-xl bg-[#11182B] border border-white/5 space-y-2">
                  <div className="text-white font-bold">Step 3: Run Spring Boot Application</div>
                  <pre className="text-[#34D399] p-3 bg-[#0B1020] rounded border border-white/5 overflow-x-auto">
{`# If your MySQL has a password:
$env:DB_PASSWORD="your_password_here"

# Start application via Maven Wrapper:
.\mvnw.cmd spring-boot:run

# Open browser at:
http://localhost:8080`}
                  </pre>
                </div>

                <div className="p-4 rounded-xl bg-[#11182B] border border-white/5 space-y-2">
                  <div className="text-white font-bold">Step 4: Default Evaluation Accounts</div>
                  <div className="text-[#A7B1C8] space-y-1 font-sans">
                    <div><strong>Admin Console:</strong> <code>admin@placenza.ai</code> / <code>Admin@Placenza2026!</code></div>
                    <div><strong>New Student:</strong> Register a new account on the registration page in 10 seconds.</div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        )}
      </main>

      {/* FOOTER */}
      <footer className="border-t border-white/10 bg-[#11182B] py-6 text-center text-xs text-[#A7B1C8]">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 flex flex-col sm:flex-row items-center justify-between gap-3">
          <div>
            &copy; 2026 <strong>PLACENZA AI</strong>. All rights reserved. Built for College Java Full-Stack Capstone Evaluation.
          </div>
          <div className="flex items-center gap-4 text-xs font-mono">
            <span>Java 21</span>
            <span>•</span>
            <span>Spring Boot 3.3.4</span>
            <span>•</span>
            <span>MySQL 8</span>
            <span>•</span>
            <span>Thymeleaf</span>
          </div>
        </div>
      </footer>
    </div>
  );
}
